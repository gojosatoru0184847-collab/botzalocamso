# -*- coding: utf-8 -*-
from telethon import TelegramClient
import json
import asyncio
import os

async def main():
    try:
        with open("seting.json", "r", encoding="utf-8") as f:
            config = json.load(f)["telegram"]

        api_id = int(config["api_id"])
        api_hash = config["api_hash"]
        phone = config["phone"]

        # Đảm bảo thư mục data tồn tại
        os.makedirs("data", exist_ok=True)

        # Sử dụng session 'data/tele_fixed' thống nhất với bot chính
        client = TelegramClient("data/tele_fixed", api_id, api_hash)

        print("\n--- ĐĂNG NHẬP TELEGRAM ---")
        await client.start(phone=phone)

        if await client.is_user_authorized():
            print("\n=== ĐĂNG NHẬP THÀNH CÔNG ===")
            print("Bây giờ bạn có thể tắt cửa sổ này và gõ: pm2 restart zalo-bot")
        else:
            print("\n❌ Đăng nhập thất bại. Vui lòng kiểm tra lại mã xác nhận.")

        await client.disconnect()
    except Exception as e:
        print(f"\n❌ Lỗi: {e}")

if __name__ == "__main__":
    asyncio.run(main())
