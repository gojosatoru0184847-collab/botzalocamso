# cmd_zingmp3.py
# Lệnh: .zingmp3 <tên bài hát>
#
# BẢN NÂNG CẤP: thay vì hardcode apiKey/secretKey (dễ chết khi ZingMP3 đổi),
# script này TỰ ĐỘNG lấy key mới nhất mỗi lần chạy bằng cách đọc thẳng từ
# bundle JS chính thức của zingmp3.vn — cùng cách mà thư viện zingmp3py
# (github.com/thedtvn/zingmp3py) làm. Vì vậy code này không bao giờ "chết"
# vì key cũ, miễn là zingmp3.vn không đổi hẳn cấu trúc trang.
#
# Thuật toán chữ ký (đã verify từ mã nguồn mở, không phải đoán):
#   sig = HMAC_SHA512(path + SHA256(f"ctime={ctime}[id={id}]version={version}"), secretKey)

import os
import re
import time
import hmac
import hashlib
import requests

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "zingmp3")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

BASE_URL = "https://zingmp3.vn"
VERSION = "1.13.6"  # version hiện tại của web player, có thể cần update nếu ZingMP3 nâng cấp

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Referer": "https://zingmp3.vn/",
}

_KEY_CACHE = {"apiKey": None, "secretKey": None, "fetched_at": 0}
_KEY_TTL_SECONDS = 3600  # cache key 1 tiếng, tránh phải fetch trang chủ mỗi request


def _fetch_keys(session: requests.Session) -> tuple[str, str]:
    """Lấy apiKey + secretKey mới nhất bằng cách đọc JS bundle chính thức của ZingMP3."""
    now = time.time()
    if _KEY_CACHE["apiKey"] and (now - _KEY_CACHE["fetched_at"] < _KEY_TTL_SECONDS):
        return _KEY_CACHE["apiKey"], _KEY_CACHE["secretKey"]

    resp = session.get(BASE_URL + "/", headers=HEADERS, timeout=15)
    resp.raise_for_status()
    html = resp.text

    # tìm script main.min.js của zmp3-desktop (cấu trúc build hiện tại của ZingMP3)
    matches = re.findall(
        r'src="(https://zjs\.zmdcdn\.me/zmp3-desktop/releases/[^"]*?/static/js/main\.[^"]*?\.js)"',
        html,
    )
    if not matches:
        # fallback: thử tìm bất kỳ file main*.js nào được load
        matches = re.findall(r'src="(https://zjs\.zmdcdn\.me/[^"]*?main[^"]*?\.js)"', html)
    if not matches:
        raise RuntimeError("Không tìm thấy bundle JS của ZingMP3 (có thể họ đã đổi cấu trúc trang).")

    js_resp = session.get(matches[0], headers=HEADERS, timeout=15)
    js_resp.raise_for_status()
    js_data = js_resp.text

    # apiKey/secretKey là 2 chuỗi hex 32 ký tự nằm gần nhau trong bundle
    keys = re.findall(r'"([a-fA-F0-9]{32})"', js_data)
    if len(keys) < 2:
        raise RuntimeError("Không trích được apiKey/secretKey từ bundle JS (cấu trúc có thể đã đổi).")

    api_key, secret_key = keys[0], keys[1]
    _KEY_CACHE.update({"apiKey": api_key, "secretKey": secret_key, "fetched_at": now})
    return api_key, secret_key


def _get_hash256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()


def _get_hmac512(data: str, key: str) -> str:
    return hmac.new(key.encode("utf-8"), data.encode("utf-8"), hashlib.sha512).hexdigest()


def _sign(path: str, secret_key: str, ctime: int, extra_param: str = "") -> str:
    str_hash = f"ctime={ctime}{extra_param}"
    h1 = _get_hash256(str_hash)
    return _get_hmac512(path + h1, secret_key)


def _request(session: requests.Session, path: str, qs: dict, extra_param: str = "") -> dict:
    api_key, secret_key = _fetch_keys(session)
    ctime = int(time.time())
    sig = _sign(path, secret_key, ctime, extra_param)

    params = dict(qs)
    params.update({"ctime": ctime, "version": VERSION, "apiKey": api_key, "sig": sig})

    resp = session.get(BASE_URL + path, params=params, headers=HEADERS, timeout=15)
    resp.raise_for_status()
    return resp.json()


def search_song(session: requests.Session, query: str) -> dict:
    data = _request(session, "/api/v2/search/multi", {"q": query}, extra_param=f"q={query}")
    if data.get("err"):
        return {"ok": False, "error": data.get("msg", "Lỗi tìm kiếm ZingMP3")}

    songs = (data.get("data") or {}).get("song", {}).get("items", [])
    if not songs:
        return {"ok": False, "error": "Không tìm thấy bài hát nào."}

    top = songs[0]
    return {
        "ok": True,
        "encode_id": top.get("encodeId"),
        "title": top.get("title"),
        "artist": top.get("artistsNames"),
    }


def get_streaming_url(session: requests.Session, encode_id: str) -> dict:
    data = _request(session, "/api/v2/song/get/streaming", {"id": encode_id}, extra_param=f"id={encode_id}")
    if data.get("err"):
        return {"ok": False, "error": data.get("msg", "Lỗi lấy link streaming")}

    quality = data.get("data") or {}
    for key in ("128", "320"):
        if quality.get(key):
            return {"ok": True, "url": quality[key]}

    return {"ok": False, "error": "Bài hát yêu cầu VIP hoặc không có link phát công khai."}


def download(query: str) -> dict:
    if not query or not query.strip():
        return {"ok": False, "path": None, "title": None, "error": "Thiếu tên bài hát. Dùng: .zingmp3 <tên bài>"}

    try:
        with requests.Session() as session:
            found = search_song(session, query.strip())
            if not found["ok"]:
                return {"ok": False, "path": None, "title": None, "error": found["error"]}

            stream = get_streaming_url(session, found["encode_id"])
            if not stream["ok"]:
                return {"ok": False, "path": None, "title": None, "error": stream["error"]}

            title = f"{found['title']} - {found['artist']}"
            safe_name = re.sub(r'[\\/*?:"<>|]', "", title)[:80] or "zingmp3"
            path = os.path.join(DOWNLOAD_DIR, f"{safe_name}.mp3")

            with session.get(stream["url"], stream=True, timeout=30) as r:
                r.raise_for_status()
                with open(path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

            return {"ok": True, "path": path, "title": title, "error": None}

    except Exception as e:
        return {"ok": False, "path": None, "title": None, "error": str(e)}


def run(args: str, message=None) -> dict:
    result = download(args)
    if not result["ok"]:
        return {"type": "text", "content": f"❌ Lỗi ZingMP3: {result['error']}"}

    return {
        "type": "file",
        "path": result["path"],
        "caption": f"🎶 {result['title']}",
        "content": f"🎶 {result['title']}"
    }


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or "test"
    print(run(q))
