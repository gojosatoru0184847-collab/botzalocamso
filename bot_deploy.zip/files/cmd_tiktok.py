# cmd_tiktok.py
# Lệnh: .tiktok <link tiktok>
#
# BẢN NÂNG CẤP: ưu tiên yt-dlp (bản 2026.7.4 trở lên, active maintain,
# tự lấy video HD không logo) làm phương án chính; nếu lỗi thì fallback
# qua API public tikwm.com. Hai lớp bảo hiểm cho nhau, ít khi cả hai cùng đứt.
#
# Cập nhật yt-dlp định kỳ để giữ tương thích với TikTok:
#   pip install -U yt-dlp --break-system-packages

import os
import re
import requests
import yt_dlp

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "tiktok")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

TIKWM_API = "https://www.tikwm.com/api/"
TIKTOK_URL_RE = re.compile(r"(https?://)?(www\.|vm\.|vt\.)?tiktok\.com/\S+")


def extract_tiktok_url(text: str) -> str | None:
    match = TIKTOK_URL_RE.search(text or "")
    return match.group(0) if match else None


def _download_via_ytdlp(url: str) -> dict:
    ydl_opts = {
        "format": "best[ext=mp4]/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "outtmpl": os.path.join(DOWNLOAD_DIR, "%(id)s.%(ext)s"),
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        video_id = info.get("id")
        title = info.get("title", "TikTok video")
        ext = info.get("ext", "mp4")
        path = os.path.join(DOWNLOAD_DIR, f"{video_id}.{ext}")
        if not os.path.exists(path):
            candidates = [f for f in os.listdir(DOWNLOAD_DIR)]
            if not candidates:
                raise RuntimeError("yt-dlp tải xong nhưng không thấy file.")
            candidates.sort(key=lambda f: os.path.getmtime(os.path.join(DOWNLOAD_DIR, f)), reverse=True)
            path = os.path.join(DOWNLOAD_DIR, candidates[0])
        return {"ok": True, "path": path, "title": title, "author": info.get("uploader", "")}


def _download_via_tikwm(url: str) -> dict:
    resp = requests.post(TIKWM_API, data={"url": url, "hd": 1}, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    if data.get("code") != 0:
        raise RuntimeError(data.get("msg", "tikwm.com không lấy được dữ liệu video"))

    d = data["data"]
    play_url = d.get("hdplay") or d.get("play")
    if not play_url:
        raise RuntimeError("tikwm.com không trả về link video (có thể video private).")

    title = d.get("title", "TikTok video")
    safe_name = re.sub(r'[\\/*?:"<>|]', "", title)[:50] or "tiktok"
    path = os.path.join(DOWNLOAD_DIR, f"{safe_name}.mp4")

    with requests.get(play_url, stream=True, timeout=30) as r:
        r.raise_for_status()
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

    return {"ok": True, "path": path, "title": title, "author": d.get("author", {}).get("nickname", "")}


def download(url: str) -> dict:
    errors = []
    for method in (_download_via_ytdlp, _download_via_tikwm):
        try:
            return method(url)
        except Exception as e:
            errors.append(f"{method.__name__}: {e}")
    return {"ok": False, "error": " | ".join(errors)}


def run(args: str, message=None) -> dict:
    url = extract_tiktok_url(args)
    if not url:
        return {"type": "text", "content": "Thiếu link TikTok hợp lệ. Dùng: .tiktok <link>"}

    result = download(url)
    if not result.get("ok"):
        return {"type": "text", "content": f"❌ Không tải được video (cả 2 phương án đều lỗi): {result.get('error')}"}

    caption = f"🎬 {result['title']}"
    if result.get("author"):
        caption += f"\n👤 {result['author']}"

    return {
        "type": "file",
        "path": result["path"],
        "caption": caption,
        "content": caption
    }


if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else ""
    print(run(url))
