# cmd_soda.py
# Lệnh: .qishui <tên bài hát hoặc link chia sẻ 汽水音乐/Qishui Music>
#
# BẢN NÂNG CẤP: dùng thư viện "musicdl" (github.com/CharlesPikachu/musicdl,
# 4.7k star, cập nhật đều — bản mới nhất tính đến giờ là 05/2026), có sẵn
# SodaMusicClient dành riêng cho 汽水音乐 (Soda Music). Thư viện này KHÔNG
# cần ffmpeg/thêm binary gì cho Soda (khác với SoundCloud/Apple Music),
# nên chạy tốt trên Termux.
#
# Cài: pip install musicdl --break-system-packages

import os
import re
from musicdl.modules.sources import SodaMusicClient

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "qishui")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

QISHUI_URL_RE = re.compile(r"https?://(www\.)?qishui\.douyin\.com/\S+")


def _is_url(text: str) -> bool:
    return bool(QISHUI_URL_RE.search(text or ""))


def _client() -> SodaMusicClient:
    return SodaMusicClient(work_dir=DOWNLOAD_DIR)


def download(query: str) -> dict:
    if not query or not query.strip():
        return {"ok": False, "path": None, "title": None, "error": "Thiếu tên bài hát hoặc link. Dùng: .qishui <tên bài / link>"}

    query = query.strip()
    client = _client()

    try:
        if _is_url(query):
            song_infos = client.parseplaylist(query)
        else:
            song_infos = client.search(keyword=query)

        if not song_infos:
            return {"ok": False, "path": None, "title": None, "error": "Không tìm thấy bài hát nào trên 汽水音乐."}

        # chỉ lấy bài đầu tiên để gửi (nếu là playlist sẽ có nhiều bài)
        target = song_infos[:1]
        downloaded = client.download(song_infos=target)

        if not downloaded:
            return {"ok": False, "path": None, "title": None, "error": "Tìm thấy bài hát nhưng tải thất bại (có thể do VIP-only hoặc link hỏng)."}

        song = downloaded[0]
        title = f"{song.song_name} - {song.singers}" if song.singers else song.song_name
        extra_note = ""
        if len(song_infos) > 1:
            extra_note = f" (playlist có {len(song_infos)} bài, đã tải bài đầu)"

        return {"ok": True, "path": song.save_path, "title": title + extra_note, "error": None}

    except Exception as e:
        return {"ok": False, "path": None, "title": None, "error": str(e)}


def run(args: str, message=None) -> dict:
    result = download(args)
    if not result["ok"]:
        return {"type": "text", "content": f"❌ Lỗi 汽水音乐: {result['error']}"}

    return {
        "type": "file",
        "path": result["path"],
        "caption": f"🎶 {result['title']}",
        "content": f"🎶 {result['title']}"
    }


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or ""
    print(run(q))
