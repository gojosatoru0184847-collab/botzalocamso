# cmd_fb.py
# Lệnh: .fb <link facebook video/reel>
# Tải video Facebook (public) bằng yt-dlp.
# Lưu ý: video private/friends-only cần cookie đăng nhập (cookiefile),
# xem phần cuối file để bật nếu cần.

import os
import re
import yt_dlp

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "fb")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

FB_URL_RE = re.compile(r"(https?://)?(www\.|web\.|m\.)?(facebook\.com|fb\.watch)/\S+")

# Nếu cần tải video private/friends-only: xuất cookie facebook.com dạng
# Netscape cookie file (dùng extension "Get cookies.txt" trên trình duyệt)
# rồi set đường dẫn ở đây.
COOKIE_FILE = None  # vd: os.path.join(os.path.dirname(__file__), "fb_cookies.txt")


def extract_fb_url(text: str) -> str | None:
    match = FB_URL_RE.search(text or "")
    return match.group(0) if match else None


def download(url: str) -> dict:
    ydl_opts = {
        "format": "best[ext=mp4]/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "outtmpl": os.path.join(DOWNLOAD_DIR, "%(id)s.%(ext)s"),
    }
    if COOKIE_FILE and os.path.exists(COOKIE_FILE):
        ydl_opts["cookiefile"] = COOKIE_FILE

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            video_id = info.get("id")
            title = info.get("title", "Facebook video")
            ext = info.get("ext", "mp4")
            path = os.path.join(DOWNLOAD_DIR, f"{video_id}.{ext}")

            if not os.path.exists(path):
                candidates = [f for f in os.listdir(DOWNLOAD_DIR)]
                if not candidates:
                    return {"ok": False, "path": None, "title": None, "error": "Tải xong nhưng không thấy file."}
                candidates.sort(key=lambda f: os.path.getmtime(os.path.join(DOWNLOAD_DIR, f)), reverse=True)
                path = os.path.join(DOWNLOAD_DIR, candidates[0])

            return {"ok": True, "path": path, "title": title, "error": None}

    except Exception as e:
        err = str(e)
        if "login" in err.lower() or "private" in err.lower():
            err += "\n(Video có thể là private/friends-only, cần cookie đăng nhập — xem COOKIE_FILE trong cmd_fb.py)"
        return {"ok": False, "path": None, "title": None, "error": err}


def run(args: str, message=None) -> dict:
    url = extract_fb_url(args)
    if not url:
        return {"type": "text", "content": "Thiếu link Facebook hợp lệ. Dùng: .fb <link>"}

    result = download(url)
    if not result["ok"]:
        return {"type": "text", "content": f"❌ Lỗi tải Facebook: {result['error']}"}

    return {
        "type": "file",
        "path": result["path"],
        "caption": f"🎬 {result['title']}",
        "content": f"🎬 {result['title']}"
    }


if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else ""
    print(run(url))
