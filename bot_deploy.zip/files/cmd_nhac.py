# cmd_nhac.py
# Lệnh: /nhac <tên bài hát>
# Tìm bài hát trên YouTube và tải về dạng mp3 để gửi qua Zalo.
#
# Yêu cầu: pip install yt-dlp
# Termux cần thêm: pkg install ffmpeg  (để convert sang mp3)

import os
import re
import yt_dlp

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "nhac")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)


def _safe_filename(name: str) -> str:
    name = re.sub(r'[\\/*?:"<>|]', "", name)
    return name.strip()[:80] or "audio"


def search_and_download(query: str) -> dict:
    """
    Tìm bài hát theo tên trên YouTube, tải về mp3.
    Trả về dict: {"ok": bool, "path": str|None, "title": str|None, "error": str|None}
    """
    if not query or not query.strip():
        return {"ok": False, "path": None, "title": None, "error": "Thiếu tên bài hát. Dùng: /nhac <tên bài>"}

    ydl_opts = {
        "format": "bestaudio/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "default_search": "ytsearch1",
        "outtmpl": os.path.join(DOWNLOAD_DIR, "%(id)s.%(ext)s"),
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
        "postprocessor_args": ["-ar", "44100"],
        "prefer_ffmpeg": True,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(query, download=True)
            # extract_info với ytsearch trả về 'entries'
            if "entries" in info:
                if not info["entries"]:
                    return {"ok": False, "path": None, "title": None, "error": "Không tìm thấy bài hát nào."}
                entry = info["entries"][0]
            else:
                entry = info

            video_id = entry.get("id")
            title = entry.get("title", query)
            mp3_path = os.path.join(DOWNLOAD_DIR, f"{video_id}.mp3")

            if not os.path.exists(mp3_path):
                # yt-dlp đôi khi giữ nguyên tên khác, tìm file mp3 mới nhất trong thư mục
                candidates = [f for f in os.listdir(DOWNLOAD_DIR) if f.endswith(".mp3")]
                if not candidates:
                    return {"ok": False, "path": None, "title": None, "error": "Tải xong nhưng không thấy file mp3."}
                candidates.sort(key=lambda f: os.path.getmtime(os.path.join(DOWNLOAD_DIR, f)), reverse=True)
                mp3_path = os.path.join(DOWNLOAD_DIR, candidates[0])

            return {"ok": True, "path": mp3_path, "title": title, "error": None}

    except Exception as e:
        return {"ok": False, "path": None, "title": None, "error": str(e)}


def run(args: str, message=None) -> dict:
    """
    Hàm chuẩn để gắn vào command router của bot.
    args: phần text sau lệnh, vd "/nhac Chúng ta của hiện tại" -> args = "Chúng ta của hiện tại"
    Trả về dict {"type": "file"/"text", "content": ...}
    """
    result = search_and_download(args)
    if not result["ok"]:
        return {"type": "text", "content": f"❌ Lỗi tìm nhạc: {result['error']}"}

    return {
        "type": "file",
        "path": result["path"],
        "caption": f"🎵 {result['title']}",
        "content": f"🎵 Đã tìm thấy: {result['title']}"
    }


if __name__ == "__main__":
    # test nhanh khi chạy trực tiếp: python cmd_nhac.py "tên bài hát"
    import sys
    q = " ".join(sys.argv[1:]) or "test song"
    print(run(q))
