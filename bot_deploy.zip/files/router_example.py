# router_example.py
# Gắn toàn bộ lệnh vào command dispatcher hiện có của bot.
# Đổi phần send_text / send_file cho khớp API thật của lib Zalo bot m đang dùng.

from cmd_nhac import run as run_nhac
from cmd_gg import run as run_gg
from cmd_tiktok import run as run_tiktok
from cmd_scl import run as run_scl
from cmd_zingmp3 import run as run_zingmp3
from cmd_soda import run as run_soda
from cmd_fb import run as run_fb
from cmd_dl import run as run_dl

COMMANDS = {
    "/nhac": run_nhac,
    "/gg": run_gg,
    ".tiktok": run_tiktok,
    ".scl": run_scl,
    ".zingmp3": run_zingmp3,
    ".qishui": run_soda,      # 汽水音乐
    ".fb": run_fb,
    ".dl": run_dl,
}


def handle_message(text: str, message=None, send_text=None, send_file=None):
    text = text.strip()
    for cmd, handler in COMMANDS.items():
        if text == cmd or text.startswith(cmd + " "):
            args = text[len(cmd):].strip()
            result = handler(args, message=message)

            if result["type"] == "text":
                if send_text:
                    send_text(result["content"])
            elif result["type"] == "file":
                if send_file:
                    send_file(result["path"], result.get("caption", ""))
                elif send_text:
                    send_text(result["content"] + f"\n(file: {result['path']})")
            return True
    return False


# ---- Cách gắn vào bot hiện tại ----
# from router_example import handle_message
#
# def on_message(message):
#     text = message.get("text", "")
#     handled = handle_message(
#         text,
#         message=message,
#         send_text=lambda content: bot.send_message(thread_id, content),
#         send_file=lambda path, caption: bot.send_file(thread_id, path, caption=caption),
#     )
#     if handled:
#         return
#     # ...xử lý các lệnh khác của bot như cũ...
