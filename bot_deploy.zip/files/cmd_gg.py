# cmd_gg.py
# Lệnh: /gg <từ khóa>
# Tìm kiếm Google, trả về top kết quả (tiêu đề + link + mô tả ngắn).
#
# Lưu ý: đây là scrape HTML của Google (không dùng API chính thức),
# nên có thể bị chặn/đổi cấu trúc theo thời gian. Nếu bị lỗi liên tục,
# nên đổi qua API chính thức (Google Custom Search API, cần API key + CSE id).

import requests
from bs4 import BeautifulSoup
from urllib.parse import quote, urlparse, parse_qs

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    )
}


def _clean_google_link(href: str) -> str:
    """Google bọc link kiểu /url?q=<real_url>&sa=..., bóc ra link thật."""
    if href.startswith("/url?"):
        qs = parse_qs(urlparse(href).query)
        return qs.get("q", [href])[0]
    return href


def search_google(query: str, num_results: int = 5) -> list:
    if not query or not query.strip():
        return []

    url = f"https://www.google.com/search?q={quote(query)}&num={num_results + 5}&hl=vi"
    resp = requests.get(url, headers=HEADERS, timeout=10)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "html.parser")
    results = []

    for block in soup.select("div.g"):
        title_tag = block.select_one("h3")
        link_tag = block.select_one("a")
        desc_tag = block.select_one("div.VwiC3b, span.aCOpRe, div[data-sncf]")

        if not title_tag or not link_tag:
            continue

        href = link_tag.get("href", "")
        link = _clean_google_link(href)
        if not link.startswith("http"):
            continue

        results.append({
            "title": title_tag.get_text(strip=True),
            "link": link,
            "desc": desc_tag.get_text(strip=True) if desc_tag else ""
        })

        if len(results) >= num_results:
            break

    return results


def run(args: str, message=None) -> dict:
    """
    args: từ khóa tìm kiếm, vd "/gg cách nấu phở bò" -> args = "cách nấu phở bò"
    """
    if not args or not args.strip():
        return {"type": "text", "content": "Thiếu từ khóa. Dùng: /gg <từ khóa>"}

    try:
        results = search_google(args, num_results=5)
    except Exception as e:
        return {"type": "text", "content": f"❌ Lỗi tìm kiếm Google: {e}"}

    if not results:
        return {"type": "text", "content": f"Không tìm thấy kết quả nào cho: {args}"}

    lines = [f"🔎 Kết quả tìm kiếm cho \"{args}\":\n"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}\n{r['link']}")
        if r["desc"]:
            desc = r["desc"]
            if len(desc) > 120:
                desc = desc[:120] + "..."
            lines.append(f"   {desc}")
        lines.append("")

    return {"type": "text", "content": "\n".join(lines).strip()}


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or "python là gì"
    print(run(q)["content"])
