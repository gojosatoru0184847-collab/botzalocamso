# cmd_dl.py
# Lệnh: .dl <link bất kỳ>
# Tự nhận diện nền tảng (TikTok, Facebook, YouTube, Instagram, Twitter/X,
# SoundCloud, v.v.) qua yt-dlp và tải video/audio về gửi lên Zalo.
# Đây là lệnh "gộp" nhanh, không cần biết trước link thuộc nền tảng nào.

import os
import re
import yt_dlp

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "dl")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

URL_RE = re.compile(r"https?://\S+")


def extract_url(text: str) -> str | None:
    match = URL_RE.search(text or "")
    return match.group(0) if match else None


def download(url: str) -> dict:
    ydl_opts = {
        "format": "best[ext=mp4]/bestvideo+bestaudio/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "outtmpl": os.path.join(DOWNLOAD_DIR, "%(id)s.%(ext)s"),
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            video_id = info.get("id")
            title = info.get("title", "video")
            ext = info.get("ext", "mp4")
            path = os.path.join(DOWNLOAD_DIR, f"{video_id}.{ext}")

            if not os.path.exists(path):
                candidates = [f for f in os.listdir(DOWNLOAD_DIR)]
                if not candidates:
                    return {"ok": False, "path": None, "title": None, "error": "Tải xong nhưng không thấy file."}
                candidates.sort(key=lambda f: os.path.getmtime(os.path.join(DOWNLOAD_DIR, f)), reverse=True)
                path = os.path.join(DOWNLOAD_DIR, candidates[0])

            extractor = info.get("extractor_key", "?")
            return {"ok": True, "path": path, "title": title, "source": extractor, "error": None}

    except Exception as e:
        return {"ok": False, "path": None, "title": None, "source": None, "error": str(e)}


def run(args: str, message=None) -> dict:
    url = extract_url(args)
    if not url:
        return {"type": "text", "content": "Thiếu link. Dùng: .dl <link tiktok/fb/youtube/scl/...>"}

    result = download(url)
    if not result["ok"]:
        return {"type": "text", "content": f"❌ Không tải được: {result['error']}"}

    return {
        "type": "file",
        "path": result["path"],
        "caption": f"📥 [{result['source']}] {result['title']}",
        "content": f"📥 [{result['source']}] {result['title']}"
    }


if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else ""
    print(run(url))
