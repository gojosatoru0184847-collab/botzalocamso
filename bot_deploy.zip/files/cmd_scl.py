# cmd_scl.py
# Lệnh: .scl <link soundcloud hoặc tên bài hát>
# Tải nhạc từ SoundCloud (yt-dlp hỗ trợ SoundCloud native, khá ổn định).

import os
import re
import yt_dlp

DOWNLOAD_DIR = os.path.join(os.path.dirname(__file__), "downloads", "scl")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

SCL_URL_RE = re.compile(r"(https?://)?(www\.)?(soundcloud\.com|on\.soundcloud\.com)/\S+")


def _is_url(text: str) -> bool:
    return bool(SCL_URL_RE.match(text.strip()))


def download(query: str) -> dict:
    if not query or not query.strip():
        return {"ok": False, "path": None, "title": None, "error": "Thiếu link hoặc tên bài hát."}

    is_url = _is_url(query)
    source = query.strip() if is_url else f"scsearch1:{query.strip()}"

    ydl_opts = {
        "format": "bestaudio/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "outtmpl": os.path.join(DOWNLOAD_DIR, "%(id)s.%(ext)s"),
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "192",
        }],
        "prefer_ffmpeg": True,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(source, download=True)
            if "entries" in info:
                if not info["entries"]:
                    return {"ok": False, "path": None, "title": None, "error": "Không tìm thấy bài hát nào trên SoundCloud."}
                entry = info["entries"][0]
            else:
                entry = info

            video_id = entry.get("id")
            title = entry.get("uploader", "") and f"{entry.get('title')} - {entry.get('uploader')}" or entry.get("title", query)
            mp3_path = os.path.join(DOWNLOAD_DIR, f"{video_id}.mp3")

            if not os.path.exists(mp3_path):
                candidates = [f for f in os.listdir(DOWNLOAD_DIR) if f.endswith(".mp3")]
                if not candidates:
                    return {"ok": False, "path": None, "title": None, "error": "Tải xong nhưng không thấy file mp3."}
                candidates.sort(key=lambda f: os.path.getmtime(os.path.join(DOWNLOAD_DIR, f)), reverse=True)
                mp3_path = os.path.join(DOWNLOAD_DIR, candidates[0])

            return {"ok": True, "path": mp3_path, "title": title, "error": None}

    except Exception as e:
        return {"ok": False, "path": None, "title": None, "error": str(e)}


def run(args: str, message=None) -> dict:
    result = download(args)
    if not result["ok"]:
        return {"type": "text", "content": f"❌ Lỗi SoundCloud: {result['error']}"}

    return {
        "type": "file",
        "path": result["path"],
        "caption": f"🎧 {result['title']}",
        "content": f"🎧 {result['title']}"
    }


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or "test"
    print(run(q))
