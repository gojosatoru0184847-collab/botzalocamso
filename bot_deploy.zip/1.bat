@echo off
set "PYTHON_EXE=%LocalAppData%\Programs\Python\Python312\python.exe"
echo [1/2] Dang cai thu vien...
"%PYTHON_EXE%" -m pip install -r requirements.txt
echo.
echo [2/2] Dang khoi dong Bot...
"%PYTHON_EXE%" main.py
pause