import json

def read_setting_value(key):
    try:
        with open('seting.json', 'r', encoding='utf-8') as f:
            settings = json.load(f)
        return settings.get(key)
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy file seting.json. Dùng giá trị mặc định cho {key}.")
        return None
    except json.JSONDecodeError:
        print(f"Lỗi: File seting.json không hợp lệ. Dùng giá trị mặc định cho {key}.")
        return None

def read_prefix():
    p = read_setting_value('prefix')
    if p is None: return "."
    return p

def read_admin():
    return read_setting_value('admin') or "YOUR_ADMIN_UID_HERE"

# ==============================
# CẤU HÌNH - ĐIỀN VÀO ĐÂY
# ==============================
IMEI           = read_setting_value('imei') or "YOUR_IMEI_HERE"
SESSION_COOKIES = read_setting_value('session_cookies') or {}
API_KEY        = read_setting_value('api_key') or "api_key"
SECRET_KEY     = read_setting_value('secret_key') or "secret_key"
PREFIX         = read_prefix()
ADMIN          = read_admin()
