#!/bin/bash

# ======================================================
#           ULTRA BOT SYSTEM - TERMUX SETUP
# ======================================================

echo -e "\e[1;36m[INFO] Đang bắt đầu quá trình cài đặt Ultra Bot trên Termux...\e[0m"

# 1. Cập nhật hệ thống
echo -e "\e[1;33m[1/4] Cập nhật gói hệ thống...\e[0m"
pkg update -y && pkg upgrade -y

# 2. Cài đặt các gói cần thiết
echo -e "\e[1;33m[2/4] Cài đặt Python và các thư viện hệ thống...\e[0m"
pkg install python python-pip git libjpeg-turbo libpng -y

# 3. Cài đặt thư viện Python
echo -e "\e[1;33m[3/4] Đang cài đặt thư viện bot (việc này có thể mất vài phút)...\e[0m"
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
else
    echo -e "\e[1;31m[LỖI] Không tìm thấy file requirements.txt!\e[0m"
fi

# Cài đặt thêm các thư viện xử lý ảnh cho Termux
pip install Pillow requests

# 4. Tạo file chạy nhanh
echo -e "\e[1;33m[4/4] Hoàn tất cài đặt!\e[0m"

echo -e "\e[1;32m======================================================\e[0m"
echo -e "\e[1;32m      CÀI ĐẶT THÀNH CÔNG! ĐỆ CÓ THỂ CHẠY BOT BẰNG:\e[0m"
echo -e "\e[1;37m             python main.py\e[0m"
echo -e "\e[1;32m======================================================\e[0m"

# Tự động chạy bot luôn sau khi setup xong
echo -e "\e[1;36m[BOT] Đang khởi động bot...\e[0m"
python main.py
