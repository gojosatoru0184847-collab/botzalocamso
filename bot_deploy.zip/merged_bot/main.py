# -*- coding: utf-8 -*-
import json, os, time, sys, random, re, io, threading, logging, urllib.parse, queue, signal
from concurrent.futures import ThreadPoolExecutor
import requests
from colorama import Fore, Style, init

# Ép mã hóa UTF-8 toàn diện
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

from zlapi import ZaloAPI
from zlapi.models import *
from config import API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES, ADMIN, PREFIX
from PTA import CommandHandler
from logging_utils import Logging
from event.event import handleGroupEvent

# VERSION SIÊU TỐC - SOLO ACC v9.4.0
VERSION = "9.4.0"

# Import handlers
from modules.autojoin import AutoJoinHandler, process_message_for_autojoin
from modules.bot import BotStatusHandler
from commands.bcmd import BcmdHandler
from commands.lockbot import LockBotHandler
from commands.whitelist import WhitelistHandler
from modules import scl, yt
from modules.menu import handle_menu as handle_menu_commands
from modules.getfile import process_incoming_files as process_mod_files
from modules.tele_getfile import run_tele_thread as start_tele_bot
from modules.auto_acc import startup_auto_acc
from modules.blacklist import load_blacklist

init(autoreset=True)
logger = Logging()

# PHÂN LUỒNG SIÊU TỐC
cmd_executor = ThreadPoolExecutor(max_workers=50)
bg_executor = ThreadPoolExecutor(max_workers=20)

# Silent Mode
logging.getLogger('telethon').setLevel(logging.CRITICAL)
logging.getLogger('urllib3').setLevel(logging.CRITICAL)
logging.getLogger('requests').setLevel(logging.CRITICAL)

class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        self.uid = "0"
        self.prefix = PREFIX
        self.settings = self.load_settings() or {}
        self.ADMIN = str(self.settings.get("admin") or ADMIN)
        self.ADM = [str(uid) for uid in self.settings.get("adm", [])]
        self.duyetbox_data = self.load_duyetbox_data() or []
        self.duyetbox_cache = set(str(gid) for gid in self.duyetbox_data)

        # 1. ĐĂNG NHẬP
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)

        # 2. LẤY UID CHÍNH XÁC
        try:
            info = self.fetchAccountInfo()
            if info and hasattr(info, 'profile'):
                self.uid = str(info.profile.get('userId', '0'))
            if not self.ADMIN or self.ADMIN == "YOUR_ADMIN_UID_HERE":
                self.ADMIN = self.uid
            print(Fore.GREEN + f"🚀 Bot Solo SIÊU TỐC Online! UID: {self.uid}", flush=True)
        except: pass

        # 3. KHỞI TẠO HANDLER
        self.bcmd_handler = BcmdHandler(self)
        self.lockbot_handler = LockBotHandler(self)
        self.whitelist_handler = WhitelistHandler(self)
        self.autojoin_handler = AutoJoinHandler(self)
        self.bot_status_handler = BotStatusHandler(self)
        self.command_handler = CommandHandler(self)
        self.scl_user_states = {}
        self.yt_user_states = {}

    def load_duyetbox_data(self):
        try:
            path = "modules/cache/duyetboxdata.json"
            if os.path.exists(path):
                with open(path, "r") as f: return json.load(f)
        except: return []

    def load_settings(self):
        try:
            with open("seting.json", "r", encoding='utf-8') as f: return json.load(f)
        except: return {}

    def is_super_admin(self, author_id):
        aid = str(author_id)
        return aid == self.uid or aid == self.ADMIN or aid in self.ADM or aid == "None"

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        if not author_id or str(author_id) in ["None", "0"]: author_id = self.uid

        msg_text = message.text if isinstance(message, Message) else str(message)
        if not msg_text: return

        # Kiểm tra Prefix nhanh
        is_cmd = msg_text.startswith(self.prefix) or msg_text.startswith(".")

        # Đẩy vào executor
        cmd_executor.submit(self._handle_ultra_fast, str(author_id), msg_text, message_object, thread_id, thread_type, mid, is_cmd)

    def _handle_ultra_fast(self, author_id, message_text, message_object, thread_id, thread_type, mid, is_cmd):
        try:
            is_me = self.is_super_admin(author_id)

            if is_cmd:
                msg_low = message_text.lower()
                parts = msg_low[1:].strip().split() if message_text.startswith(".") else msg_low[len(self.prefix):].strip().split()
                if parts:
                    cmd_name = parts[0]
                    if is_me:
                        if cmd_name == "ping":
                            self.replyMessage(Message(text="⚡️ SIÊU TỐC: 0.001s!"), message_object, thread_id, thread_type)
                            return
                        if cmd_name == "uid":
                            self.replyMessage(Message(text=f"👤 UID: {author_id}"), message_object, thread_id, thread_type)
                            return

                    is_approved = str(thread_id) in self.duyetbox_cache
                    if is_me or is_approved:
                        if cmd_name == "bot" and "on" in msg_low and is_me:
                            self.bot_status_handler.handle_bot_command(message_text, message_object, thread_id, thread_type, author_id)
                            self.duyetbox_cache = set(str(gid) for gid in self.load_duyetbox_data())
                            return
                        self.command_handler.handle_command(message_text, author_id, message_object, thread_id, thread_type)

            # --- XỬ LÝ TÁC VỤ NGẦM (Dù là chính mình hay người khác) ---
            from modules.blacklist import load_blacklist
            if str(thread_id) not in load_blacklist():
                bg_executor.submit(process_mod_files, self, message_object, thread_id, thread_type)
                bg_executor.submit(process_message_for_autojoin, self, message_object, thread_id, thread_type, author_id, message_text, mid, logger)
        except Exception as e: pass

    def onGroupEvent(self, event_type, event_data, thread_id, author_id):
        bg_executor.submit(handleGroupEvent, self, event_type, event_data, thread_id, author_id)

def shutdown(signum, frame):
    sys.exit(0)

signal.signal(signal.SIGINT, shutdown)
signal.signal(signal.SIGTERM, shutdown)

def start_bot():
    try:
        with open("seting.json", "r", encoding="utf-8") as f: cfg = json.load(f)
        client = Client(API_KEY, SECRET_KEY, cfg.get("imei"), cfg.get("session_cookies"))

        if not getattr(sys, '_tele_started', False):
            threading.Thread(target=start_tele_bot, args=(client,), daemon=True, name="TeleThread").start()
            threading.Thread(target=startup_auto_acc, args=(client,), daemon=True, name="AutoAccThread").start()
            setattr(sys, '_tele_started', True)

        client.listen(type="websocket", thread=False, run_forever=True)
    except Exception as e:
        print(Fore.RED + f"🛑 LỖI KHỞI ĐỘNG: {e}")
        time.sleep(5)
        sys.exit(1)

if __name__ == "__main__":
    start_bot()
