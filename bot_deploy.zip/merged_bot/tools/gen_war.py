# -*- coding: utf-8 -*-
import random
import os

def generate_war_content(count=10000):
    # Dữ liệu thành phần để kết hợp
    prefixes = [
        "Mày là", "Đồ", "Thằng", "Con", "Cái loại", "Nhìn cái bản mặt",
        "Trình", "Đúng là", "Đừng có", "Thứ", "Mày định", "Tao thấy mày",
        "Cái giống", "Bản chất là", "Ngu như", "Sủa mạnh lên", "Cút ngay",
        "Biến khỏi đây", "Run sợ trước tao", "Câm ngay cái mồm"
    ]

    subjects = [
        "chó rách", "ngu ngốc", "phế vật", "óc lợn", "lúa", "rác rưởi",
        "cùi bắp", "anh hùng bàn phím", "trẻ trâu", "đần độn", "ngáo đá",
        "vô dụng", "hèn nhát", "rẻ tiền", "tạp nham", "bẩn thỉu", "ngu muội",
        "óc chó", "phế thải", "thất bại của tạo hóa"
    ]

    actions = [
        "sủa", "cút", "biến", "ngậm mồm", "run sợ", "khóc lóc", "quỳ xuống",
        "về chuồng", "đi chết", "đập đầu vào gối", "về bú tí mẹ", "học lại lớp 1",
        "xin tha", "van xin tao", "nhìn lại mình", "tự vả vào mặt"
    ]

    suffixes = [
        "đi", "ngay", "luôn", "cho tao", "đê", "hả con", "vãi", "thế", "nhé",
        "đúng không", "chưa", "hả mày", "tội nghiệp", "đáng thương", "ngu ạ",
        "đồ ngu", "con ạ", "thế cơ á", "kinh thế", "sợ quá cơ"
    ]

    sentences = set()

    # Tạo ngẫu nhiên cho đến khi đủ số lượng
    while len(sentences) < count:
        # Kiểu 1: Prefix + Subject + Action + Suffix
        if random.random() > 0.5:
            s = f"{random.choice(prefixes)} {random.choice(subjects)} {random.choice(actions)} {random.choice(suffixes)}"
        # Kiểu 2: Prefix + Subject
        elif random.random() > 0.3:
            s = f"{random.choice(prefixes)} {random.choice(subjects)} {random.choice(suffixes)}"
        # Kiểu 3: Action + Suffix
        else:
            s = f"{random.choice(actions).capitalize()} {random.choice(suffixes)}"

        sentences.add(s)

    # Lưu vào file
    os.makedirs("data", exist_ok=True)
    with open("data/war_content.txt", "w", encoding="utf-8") as f:
        for line in sentences:
            f.write(line + "\n")

    print(f"✅ Đã tạo thành công {len(sentences)} câu war vào file data/war_content.txt!")

if __name__ == "__main__":
    generate_war_content(10000)
