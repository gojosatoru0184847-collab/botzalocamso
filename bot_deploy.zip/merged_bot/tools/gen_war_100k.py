# -*- coding: utf-8 -*-
import random
import os

def generate_ultra_war_content(count=100000):
    prefixes = [
        "Mày là", "Đồ", "Thằng", "Con", "Cái loại", "Nhìn cái bản mặt",
        "Trình", "Đúng là", "Đừng có", "Thứ", "Mày định", "Tao thấy mày",
        "Cái giống", "Bản chất là", "Ngu như", "Sủa mạnh lên", "Cút ngay",
        "Biến khỏi đây", "Run sợ trước tao", "Câm ngay cái mồm", "Thấy tao là",
        "Mày chỉ là", "Đúng cái thứ", "Hết thuốc chữa", "Thật sự là", "Vô phước",
        "Tội nghiệp cái loại", "Mặt dày như", "Óc ngắn như", "Bản mặt hèn"
    ]

    subjects = [
        "chó rách", "ngu ngốc", "phế vật", "óc lợn", "lúa", "rác rưởi",
        "cùi bắp", "anh hùng bàn phím", "trẻ trâu", "đần độn", "ngáo đá",
        "vô dụng", "hèn nhát", "rẻ tiền", "tạp nham", "bẩn thỉu", "ngu muội",
        "óc chó", "phế thải", "thất bại của tạo hóa", "đồ bỏ đi", "óc đất",
        "thằng đần", "con ngốc", "vô học", "thiếu năng", "dưới đáy xã hội",
        "rác rưởi công nghệ", "phế vật học đường", "óc bằng hạt nho"
    ]

    actions = [
        "sủa", "cút", "biến", "ngậm mồm", "run sợ", "khóc lóc", "quỳ xuống",
        "về chuồng", "đi chết", "đập đầu vào gối", "về bú tí mẹ", "học lại lớp 1",
        "xin tha", "van xin tao", "nhìn lại mình", "tự vả vào mặt", "bốc hơi",
        "tự hủy", "mất tích", "đứng im đó", "nhìn tao đây này", "xách dép cho tao"
    ]

    suffixes = [
        "đi", "ngay", "luôn", "cho tao", "đê", "hả con", "vãi", "thế", "nhé",
        "đúng không", "chưa", "hả mày", "tội nghiệp", "đáng thương", "ngu ạ",
        "đồ ngu", "con ạ", "thế cơ á", "kinh thế", "sợ quá cơ", "cho nó nhanh",
        "ngay lập tức", "luôn đi cho rảnh", "nhỉ", "không hả mày", "đúng cái loại"
    ]

    sentences = set()
    print(f"🚀 Bắt đầu sinh {count} câu chửi siêu cấp...")

    # Để đạt 100k câu không trùng lặp, ta cần kết hợp nhiều thành phần hơn
    while len(sentences) < count:
        rand = random.random()
        if rand > 0.8:
            s = f"{random.choice(prefixes)} {random.choice(subjects)} {random.choice(actions)} {random.choice(suffixes)}"
        elif rand > 0.6:
            s = f"{random.choice(prefixes)} {random.choice(subjects)} {random.choice(suffixes)}"
        elif rand > 0.4:
            s = f"{random.choice(actions).capitalize()} {random.choice(suffixes)} {random.choice(subjects)}"
        elif rand > 0.2:
            s = f"{random.choice(prefixes)} {random.choice(subjects)} {random.choice(actions)}"
        else:
            s = f"{random.choice(prefixes)} {random.choice(subjects)} {random.choice(subjects)} {random.choice(suffixes)}"

        sentences.add(s)
        if len(sentences) % 10000 == 0:
            print(f"✅ Đã tạo được {len(sentences)} câu...")

    # Đường dẫn thư mục Downloads của người dùng
    download_path = "C:/Users/Hoanglam/Downloads/war_content_100k.txt"

    with open(download_path, "w", encoding="utf-8") as f:
        for line in sentences:
            f.write(line + "\n")

    print(f"\n🎉 HOÀN TẤT! Đã tạo thành công {len(sentences)} câu war!")
    print(f"📍 File được lưu tại: {download_path}")

if __name__ == "__main__":
    generate_ultra_war_content(100000)
