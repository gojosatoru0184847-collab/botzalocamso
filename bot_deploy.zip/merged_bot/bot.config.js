module.exports = {
  apps: [
    {
      name: "zalo-bot",
      script: "main.py",
      interpreter: "python.exe",
      env: {
        PYTHONIOENCODING: "utf-8",
        PYTHONUTF8: "1",
        PATH: "C:\\Windows\\System32;C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\;" + process.env.PATH
      },
      kill_timeout: 5000,
      wait_ready: false,
      autorestart: true,
      max_restarts: 10,
      min_uptime: "15s"
    }
  ]
}
