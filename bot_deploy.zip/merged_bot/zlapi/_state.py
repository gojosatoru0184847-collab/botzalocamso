# -*- coding: UTF-8 -*-
import attr
import random
import requests, json
import threading
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

from . import _util, _exception

class State(object):
	def __init__(cls):
		cls._config = {}
		cls._headers = _util.HEADERS
		cls._cookies = _util.COOKIES

		# Tối ưu Session với cơ chế tự động thử lại
		cls._session = requests.Session()
		retry_strategy = Retry(
			total=3,
			backoff_factor=1,
			status_forcelist=[429, 500, 502, 503, 504],
		)
		adapter = HTTPAdapter(max_retries=retry_strategy)
		cls._session.mount("https://", adapter)
		cls._session.mount("http://", adapter)

		cls.user_id = None
		cls.user_imei = None
		cls._loggedin = False
	
	def get_cookies(cls):
		return cls._cookies
	
	def set_cookies(cls, cookies):
		cls._cookies = cookies
		
	def get_secret_key(cls):
		return cls._config.get("secret_key")
	
	def set_secret_key(cls, secret_key):
		cls._config["secret_key"] = secret_key
	
	def _get(cls, *args, **kwargs):
		if "timeout" not in kwargs:
			kwargs["timeout"] = 25
		return cls._session.get(*args, **kwargs, headers=cls._headers, cookies=cls._cookies)
		
	def _post(cls, *args, **kwargs):
		if "timeout" not in kwargs:
			kwargs["timeout"] = 25
		return cls._session.post(*args, **kwargs, headers=cls._headers, cookies=cls._cookies)
	
	def is_logged_in(cls):
		return cls._loggedin
	
	def login(cls, phone, password, imei, session_cookies=None, user_agent=None):
		if cls._cookies and cls._config.get("secret_key"):
			cls._loggedin = True
			return
			
		if user_agent:
			cls._headers["User-Agent"] = user_agent
			
		if cls._cookies and len(cls._cookies) > 0:
			try:
				url = f"https://wpa.chat.zalo.me/api/login/getLoginInfo?imei={imei}&type=30&client_version=645&computer_name=Web&ts={_util.now()}"
				response = requests.get(url, headers=cls._headers, cookies=cls._cookies, timeout=20)

				try:
					data = response.json()
				except:
					raise _exception.ZaloLoginError("Máy chủ Zalo trả về dữ liệu không hợp lệ.")

				if not data or not isinstance(data, dict):
					raise _exception.ZaloLoginError("Không thể đọc dữ liệu đăng nhập từ Zalo.")

				if data.get("error_code") != 0:
					raise _exception.ZaloLoginError(f"Lỗi Zalo #{data.get('error_code')}: {data.get('error_message')}")

				login_info = data.get("data")
				if not login_info:
					raise _exception.ZaloLoginError("Dữ liệu đăng nhập trống (NoneType).")

				zpw = login_info.get("zpw_ws")
				uid = login_info.get("uid")
				phone_num = login_info.get("phone_number")
				key = login_info.get("zpw_enk")

				if not key:
					raise _exception.ZaloLoginError("Không thể lấy secret key từ session.")

				cls._config = {
					"phone_number": str(phone_num),
					"secret_key": str(key),
					"send2me_id": str(uid),
					"zpw_ws": zpw,
				}
				
				cls._loggedin = True
				cls.user_id = str(uid)
				cls.user_imei = imei
				return

			except _exception.ZaloLoginError as e:
				raise _exception.ZaloLoginError(str(e))
			except Exception as e:
				raise _exception.ZaloLoginError(f"Lỗi đăng nhập: {str(e)}")
		
		else:
			raise _exception.LoginMethodNotSupport("Cần quét mã QR để đăng nhập.")
