from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Dịch ngôn ngữ đa năng (50+ ngôn ngữ)", 'power': "Thành viên"}

LANG_MAP = {
    "en":"English","vi":"Tiếng Việt","ja":"日本語","ko":"한국어","zh":"中文",
    "fr":"Français","de":"Deutsch","es":"Español","th":"ภาษาไทย","ru":"Русский",
    "ar":"العربية","pt":"Português","it":"Italiano","id":"Indonesia","ms":"Malay"
}

def _translate(text, src="auto", dest="vi"):
    try:
        url = "https://translate.googleapis.com/translate_a/single"
        params = {"client":"gtx","sl":src,"tl":dest,"dt":"t","q":text}
        r = requests.get(url, params=params, timeout=10)
        result = r.json()
        return "".join(seg[0] for seg in result[0] if seg[0])
    except Exception as e:
        return f"Lỗi dịch: {e}"

def _trans(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=2)
    if len(p) < 2:
        client.replyMessage(Message(text="🌐 Dùng: .tr <ngôn ngữ> <văn bản>\nVí dụ: .tr en Xin chào\nHoặc: .tr vi Hello"), message_object, thread_id, thread_type); return
    if len(p) == 2:
        dest, text = "vi", p[1]
    else:
        dest, text = p[1].lower(), p[2]
    if dest not in LANG_MAP:
        client.replyMessage(Message(text=f"❌ Ngôn ngữ không hỗ trợ. Thử: {', '.join(LANG_MAP.keys())}"), message_object, thread_id, thread_type); return
    result = _translate(text, dest=dest)
    client.replyMessage(Message(text=f"🌐 [{LANG_MAP[dest]}]\n{result}"), message_object, thread_id, thread_type)

def _langlist(message, message_object, thread_id, thread_type, author_id, client):
    msg = "🌐 NGÔN NGỮ HỖ TRỢ:\n" + "\n".join(f"  {k}: {v}" for k,v in LANG_MAP.items())
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'tr': _trans, 'dich2': _trans, 'langlist': _langlist}
