from config import PREFIX
from zlapi.models import Message
import json, time

des = {
    'version': "1.0.5",
    'credits': "Khánh Sang",
    'description': "check prefix",
    'power': "Thành viên"
}

COOLDOWN_TIME = 30
user_cooldowns = {}
user_notified = {}

def prf():
    with open('seting.json', 'r') as f:
        return json.load(f).get('prefix')

def checkprefix(message, message_object, thread_id, thread_type, author_id, client):
    current_time = time.time()
    
    if author_id in user_cooldowns:
        last_used = user_cooldowns[author_id]
        if current_time - last_used < COOLDOWN_TIME:
            if author_id not in user_notified or not user_notified[author_id]:
                remaining = COOLDOWN_TIME - (current_time - last_used)
                gui = Message(text=f"⏳ Vui lòng chờ {remaining:.1f} giây trước khi dùng lại lệnh!")
                client.replyMessage(gui, message_object, thread_id, thread_type, ttl=10000)
                user_notified[author_id] = True
            return
    
    user_notified[author_id] = False
    user_cooldowns[author_id] = current_time
    
    gui = Message(text=f"🚦Prefix hiện tại của bot là: {prf()}")
    client.replyMessage(gui, message_object, thread_id, thread_type, ttl=20000)

def PTA():
    return {
        'prefix': checkprefix
    }