from zlapi.models import Message
import json, os, random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Game ghi nhớ số dãy", 'power': "Thành viên"}

GAME_FILE = "modules/cache/data/memory.json"

def _load():
    try:
        with open(GAME_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

def _mem(message, message_object, thread_id, thread_type, author_id, client):
    games = _load()
    tid = str(thread_id)
    uid = str(author_id)
    key = f"{tid}_{uid}"
    p = message.strip().split(maxsplit=1)

    if len(p) < 2 or p[1].lower() == "new":
        length = 3
        seq = [str(random.randint(0,9)) for _ in range(length)]
        games[key] = {"seq": seq, "step": 0}
        _save(games)
        client.replyMessage(Message(text=f"🧠 GHI NHỚ DÃY SỐ:\n{' '.join(seq)}\nSau đó gõ: .memory <dãy số> để kiểm tra!"), message_object, thread_id, thread_type)
        return

    if key not in games:
        client.replyMessage(Message(text="❌ Chưa có game. Gõ .memory new"), message_object, thread_id, thread_type); return

    answer = p[1].replace(' ','').strip()
    correct = ''.join(games[key]["seq"])

    if answer == correct:
        length = len(games[key]["seq"]) + 1
        seq = [str(random.randint(0,9)) for _ in range(length)]
        games[key] = {"seq": seq, "step": games[key].get("step",0)+1}
        _save(games)
        client.replyMessage(Message(text=f"✅ Đúng! Level {length-2}\nDãy mới: {' '.join(seq)}"), message_object, thread_id, thread_type)
    else:
        score = games[key].get("step",0)
        del games[key]; _save(games)
        client.replyMessage(Message(text=f"❌ Sai! Đúng là: {' '.join(correct)}\nLevel đạt được: {score}"), message_object, thread_id, thread_type)

def PTA():
    return {'memory': _mem, 'ghinho': _mem}
