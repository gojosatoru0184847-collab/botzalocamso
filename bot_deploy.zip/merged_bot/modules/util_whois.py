from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tra cứu domain Whois", 'power': "Thành viên"}

def handle_whois_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🌐 Dùng: .whois <domain.com>"), message_object, thread_id, thread_type)
        return
    domain = parts[1].strip().replace("https://", "").replace("http://", "").split("/")[0]
    try:
        r = requests.get(f"https://rdap.org/domain/{domain}", timeout=10)
        data = r.json()
        events = data.get("events", [])
        reg_date = next((e["eventDate"] for e in events if e["eventAction"] == "registration"), "N/A")
        exp_date = next((e["eventDate"] for e in events if e["eventAction"] == "expiration"), "N/A")
        nameservers = [ns.get("ldhName","") for ns in data.get("nameservers", [])]
        msg = (
            f"🌐 WHOIS: {domain}\n"
            f"━━━━━━━━━━━━━━━\n"
            f"• Đăng ký: {reg_date}\n"
            f"• Hết hạn: {exp_date}\n"
            f"• Nameserver: {', '.join(nameservers[:3]) or 'N/A'}"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tra được domain: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'whois': handle_whois_command}
