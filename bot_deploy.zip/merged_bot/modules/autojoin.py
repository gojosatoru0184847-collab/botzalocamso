from zlapi.models import Message, ZaloAPIException, ThreadType, Mention, MultiMention, MultiMsgStyle, MessageStyle
from config import ADMIN, PREFIX
import json
import os
import re
import logging
import time
import requests
import threading

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

des = {
    'version': "1.1.0",
    'credits': "HOANG LAM",
    'description': "Tự động tham gia nhóm Zalo & Telegram",
    'power': "Quản trị viên Bot"
}

def get_user_name(client, uid):
    try:
        user_info = client.fetchUserInfo(uid)
        author_info = user_info.changed_profiles.get(str(uid), {}) if user_info and user_info.changed_profiles else {}
        name = author_info.get('zaloName', 'Không xác định')
        return name
    except Exception as e:
        logger.error(f"[get_user_name] Failed to fetch name for user {uid}: {e}")
        return 'Không xác định'

def process_message_for_autojoin(client, message_object, thread_id, thread_type, author_id, message_text, mid, logger_obj):
    """Hàm xử lý autojoin được gọi từ main.py."""
    handler = getattr(client, 'autojoin_handler', None)
    if not handler:
        handler = AutoJoinHandler(client)
        client.autojoin_handler = handler

    handler.check_and_join_group(message_text, message_object, thread_id, thread_type, author_id)

class AutoJoinHandler:
    def __init__(self, client):
        self.client = client
        self.settings_file = "data/autojoin_settings.json"
        self.autojoin_enabled = self.load_autojoin_settings()
        # Chạy dọn dẹp trong luồng riêng để tránh lag lúc khởi động
        threading.Thread(target=self.cleanup_invalid_groups, daemon=True).start()
        self.start_periodic_check()

    def load_autojoin_settings(self):
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, "r", encoding='utf-8') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            logger.error(f"[AUTOJOIN] Lỗi khi tải cài đặt autojoin: {e}")
            return {}

    def save_autojoin_settings(self):
        try:
            with open(self.settings_file, "w", encoding='utf-8') as f:
                json.dump(self.autojoin_enabled, f, indent=4)
        except Exception as e:
            logger.error(f"[AUTOJOIN] Lỗi khi lưu cài đặt autojoin: {e}")

    def cleanup_invalid_groups(self):
        try:
            all_groups = set(str(group_id) for group_id in self.client.fetchAllGroups().gridVerMap.keys())
            current_settings = self.autojoin_enabled.copy()
            removed_groups = []

            for group_id in current_settings:
                if group_id not in all_groups:
                    removed_groups.append(group_id)
                    del self.autojoin_enabled[group_id]

            if removed_groups:
                logger.info(f"[AUTOJOIN] Đã xóa {len(removed_groups)} nhóm không tồn tại khỏi cài đặt.")
                self.save_autojoin_settings()
        except: pass

    def check_new_groups(self):
        try:
            all_groups = self.client.fetchAllGroups().gridVerMap.keys()
            for group_id in all_groups:
                group_id = str(group_id)
                if group_id not in self.autojoin_enabled:
                    self.on_group_joined(group_id)
        except: pass

    def start_periodic_check(self):
        try:
            self.check_new_groups()
            threading.Timer(600, self.start_periodic_check).start()
        except: pass

    def on_group_joined(self, group_id):
        try:
            group_id = str(group_id)
            if group_id not in self.autojoin_enabled:
                self.autojoin_enabled[group_id] = False # Mặc định tắt cho nhóm mới
                self.save_autojoin_settings()
        except: pass

    def handle_autojoin_command(self, message_text, message_object, thread_id, thread_type, author_id):
        name = get_user_name(self.client, author_id)
        if not self.client.is_super_admin(author_id):
            return

        parts = message_text.split()
        if len(parts) < 2:
            client.replyMessage(Message(text=f"🚦 Dùng: {PREFIX}autojoin <on/off>"), message_object, thread_id, thread_type)
            return

        action = parts[1].lower()
        status = (action == "on")

        all_groups = self.client.fetchAllGroups().gridVerMap.keys()
        for g_id in all_groups:
            self.autojoin_enabled[str(g_id)] = status
        self.save_autojoin_settings()

        msg = f"✅ Đã {'BẬT' if status else 'TẮT'} tự động tham gia nhóm cho tất cả các nhóm!"
        self.client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

    def check_and_join_group(self, message_text, message_object, thread_id, thread_type, author_id):
        if str(thread_id) not in self.autojoin_enabled or not self.autojoin_enabled[str(thread_id)]:
            return

        # --- AUTOJOIN TELEGRAM ---
        tele_link_pattern = r"(https?://)?t\.me/(joinchat/|\+)?([a-zA-Z0-9_]{5,})"
        tele_matches = re.finditer(tele_link_pattern, message_text)
        for match in tele_matches:
            tele_link = match.group(0).strip()
            try:
                from modules.tele_getfile import tele_join_queue
                tele_join_queue.put(tele_link)
            except: pass

        # --- AUTOJOIN ZALO ---
        zalo_link_pattern = r"https://zalo\.me/(g/)?([a-zA-Z0-9]+)"
        zalo_matches = re.finditer(zalo_link_pattern, message_text)
        for match in zalo_matches:
            group_link = match.group(0)
            zalo_link_pattern_match = re.search(r"https://zalo\.me/(g/)?([^\s]+)", group_link)
            if zalo_link_pattern_match:
                group_code = zalo_link_pattern_match.group(2).strip()
                try: self.client.joinGroup(group_code)
                except: pass

def _autojoin_wrapper(message, message_object, thread_id, thread_type, author_id, client):
    handler = getattr(client, 'autojoin_handler', None)
    if handler is None:
        handler = AutoJoinHandler(client)
        client.autojoin_handler = handler
    return handler.handle_autojoin_command(message, message_object, thread_id, thread_type, author_id)

def PTA():
    return {'autojoin': _autojoin_wrapper}
