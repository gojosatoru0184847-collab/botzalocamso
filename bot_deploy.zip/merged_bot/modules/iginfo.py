from zlapi.models import Message
import requests
import os

des = {
    'version': "1.1.0",
    'credits': "UltraBot",
    'description': "Lấy thông tin Instagram từ username",
    'power': "Thành viên"
}

def handle_iginfo_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()
    if len(content) < 2:
        client.replyMessage(Message(text="📸 Dùng: .iginfo <username>\nVí dụ: .iginfo cristiano"), message_object, thread_id, thread_type)
        return
    username = content[1].strip().replace("@", "")
    try:
        # API public Instagram info
        api_url = f"https://api.sumiproject.net/instagram?username={username}"
        r = requests.get(api_url, timeout=10)
        data = r.json()
        if not data or data.get("error"):
            raise ValueError("Không tìm thấy tài khoản")
        msg = (
            f"📸 THÔNG TIN INSTAGRAM\n"
            f"━━━━━━━━━━━━━━━\n"
            f"• Tên: {data.get('full_name','N/A')}\n"
            f"• Username: @{data.get('username','N/A')}\n"
            f"• Followers: {data.get('followers','N/A')}\n"
            f"• Following: {data.get('following','N/A')}\n"
            f"• Bài viết: {data.get('posts','N/A')}\n"
            f"• Bio: {data.get('bio','')}\n"
            f"• Xác minh: {'✅' if data.get('verified') else '❌'}\n"
            f"• Link: https://instagram.com/{username}"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi lấy thông tin Instagram: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'iginfo': handle_iginfo_command}
