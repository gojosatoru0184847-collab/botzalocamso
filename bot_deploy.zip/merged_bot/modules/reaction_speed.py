from zlapi.models import Message
import json, os, time, random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Test tốc độ phản xạ (reaction time)", 'power': "Thành viên"}

GAME_FILE = "modules/cache/data/reaction.json"

def _load():
    try:
        with open(GAME_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

def _react(message, message_object, thread_id, thread_type, author_id, client):
    import threading
    games = _load()
    uid = str(author_id)
    p = message.strip().split()

    if len(p) < 2 or p[1].lower() == "start":
        delay = random.uniform(2, 6)
        games[uid] = {"start": None, "delay": delay, "ready": False}
        _save(games)
        client.replyMessage(Message(text="⚡ REACTION TEST\nKhi thấy 🟢 xuất hiện, gõ ngay .react tap!\nChuẩn bị..."), message_object, thread_id, thread_type)

        def show_signal():
            time.sleep(delay)
            g = _load()
            if uid in g:
                g[uid]["ready"] = True
                g[uid]["start"] = time.time()
                _save(g)
                try:
                    client.replyMessage(Message(text="🟢 TAP NGAY! Gõ .react tap"), message_object, thread_id, thread_type)
                except: pass
        threading.Thread(target=show_signal, daemon=True).start()
        return

    if p[1].lower() == "tap":
        if uid not in games:
            client.replyMessage(Message(text="❌ Chưa bắt đầu. Gõ .react start"), message_object, thread_id, thread_type); return
        g = games[uid]
        if not g.get("ready"):
            client.replyMessage(Message(text="❌ Chưa thấy 🟢! Đừng tap sớm!"), message_object, thread_id, thread_type); return
        elapsed = (time.time() - g["start"]) * 1000
        del games[uid]; _save(games)
        if elapsed < 150: msg = f"⚡ {elapsed:.0f}ms - Phản xạ THẦN TỐC! 🏆"
        elif elapsed < 250: msg = f"⚡ {elapsed:.0f}ms - Rất nhanh! 🎯"
        elif elapsed < 400: msg = f"⚡ {elapsed:.0f}ms - Bình thường"
        else: msg = f"⚡ {elapsed:.0f}ms - Hơi chậm 😅"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'react': _react, 'phanxa': _react}
