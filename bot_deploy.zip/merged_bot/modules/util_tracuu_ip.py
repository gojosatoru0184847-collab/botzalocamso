from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tra cứu thông tin địa chỉ IP", 'power': "Thành viên"}

def handle_ipinfo_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🌐 Dùng: .ipinfo <địa chỉ IP>"), message_object, thread_id, thread_type)
        return
    ip = parts[1].strip()
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}?lang=vi", timeout=10)
        data = r.json()
        if data.get("status") != "success":
            raise ValueError(data.get("message", "IP không hợp lệ"))
        msg = (
            f"🌐 THÔNG TIN IP: {ip}\n"
            f"━━━━━━━━━━━━━━━\n"
            f"• Quốc gia: {data.get('country','N/A')}\n"
            f"• Khu vực: {data.get('regionName','N/A')}\n"
            f"• Thành phố: {data.get('city','N/A')}\n"
            f"• ISP: {data.get('isp','N/A')}\n"
            f"• Tổ chức: {data.get('org','N/A')}\n"
            f"• Múi giờ: {data.get('timezone','N/A')}"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'ipinfo': handle_ipinfo_command, 'traip': handle_ipinfo_command}
