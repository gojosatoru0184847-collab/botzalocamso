from zlapi.models import Message
import random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Lắc xúc xắc", 'power': "Thành viên"}

DICE_FACES = {1: "⚀", 2: "⚁", 3: "⚂", 4: "⚃", 5: "⚄", 6: "⚅"}

def handle_xucxac_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    n = 1
    if len(parts) > 1:
        try:
            n = max(1, min(int(parts[1]), 6))
        except: pass
    results = [random.randint(1, 6) for _ in range(n)]
    faces = " ".join(DICE_FACES[r] for r in results)
    total = sum(results)
    msg = f"🎲 Kết quả: {faces}\nTổng: {total}"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'xucxac': handle_xucxac_command, 'dice': handle_xucxac_command, 'lacxucxac': handle_xucxac_command}
