from zlapi.models import *
from config import ADMIN, PREFIX

des = {
    'version': "1.0.0",
    'credits': "UltraBot",
    'description': "Bật/tắt thông báo khi có thành viên vào/ra nhóm",
    'power': "Quản trị viên Bot"
}

def get_user_name_by_id(client, author_id):
    try:
        user_info = client.fetchUserInfo(author_id)
        author_info = user_info.changed_profiles.get(author_id, {}) if user_info and user_info.changed_profiles else {}
        return author_info.get('zaloName', 'Không xác định')
    except Exception as e:
        print(f"Lỗi lấy tên người dùng {author_id}: {e}")
        return 'Không xác định'

def is_admin(author_id):
    return author_id == ADMIN

# SỬA: Đã đổi tên tham số cuối cùng từ 'self' sang 'client' cho đồng bộ
def setnotify(message, message_object, thread_id, thread_type, author_id, client):
    try:
        parts = message.strip().split()
        name = get_user_name_by_id(client, author_id)
        mention = Mention(author_id, offset=len("🚦 "), length=len(f"{name}"))
        
        # Hàm gửi tin nhắn phản hồi đã được tối ưu
        def send_reply(text_content):
            client.replyMessage(
                Message(
                    text=f"🚦{name}\n{text_content}",
                    mention=mention
                ),
                message_object,
                thread_id,
                thread_type,
                ttl=86400000
            )

        if not is_admin(author_id):
            send_reply("Bạn không có quyền sử dụng lệnh này.")
            return
            
        if len(parts) < 2:
            send_reply(f"Vui lòng dùng đúng cú pháp: {PREFIX}tb <on/off> [all]")
            return
            
        action = parts[1].lower()
        
        # 1: Tắt thông báo, 3: Bật thông báo (Tùy thuộc vào framework Zalo API)
        # Tôi giữ nguyên giá trị bạn dùng (1 và 3) nhưng sửa nội dung thông báo để tránh nhầm lẫn
        if action == 'on':
            # Bật thông báo (Dùng 3: thường là bật, 1: thường là tắt)
            notify_level = 3
            success_message_prefix = "Đã bật thông báo cho"
            
            if len(parts) > 2 and parts[2].lower() == 'all':
                all_grid = client.fetchAllGroups().gridVerMap.keys()
                group_count = 0
                for grid in all_grid:
                    client.changeGroupSetting(grid, notify_level) # Giá trị 3 (Bật)
                    group_count += 1
                send_reply(f"{success_message_prefix} {group_count} nhóm/cộng đồng")
            else:
                group = client.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                group_type_name = "cộng đồng" if group.type == 2 else "nhóm"
                client.changeGroupSetting(thread_id, notify_level) # Giá trị 3 (Bật)
                send_reply(f"{success_message_prefix} {group_type_name} {group.name}")
            
        elif action == 'off':
            # Tắt thông báo (Dùng 1: thường là tắt, 3: thường là bật)
            notify_level = 1
            success_message_prefix = "Đã tắt thông báo cho"
            
            if len(parts) > 2 and parts[2].lower() == 'all':
                all_grid = client.fetchAllGroups().gridVerMap.keys()
                group_count = 0
                for grid in all_grid:
                    client.changeGroupSetting(grid, notify_level) # Giá trị 1 (Tắt)
                    group_count += 1
                send_reply(f"{success_message_prefix} {group_count} nhóm/cộng đồng")
            else:
                group = client.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                group_type_name = "cộng đồng" if group.type == 2 else "nhóm"
                client.changeGroupSetting(thread_id, notify_level) # Giá trị 1 (Tắt)
                send_reply(f"{success_message_prefix} {group_type_name} {group.name}")
            
    except Exception as e:
        print(f"Lỗi khi xử lý thông báo nhóm: {e}")


def PTA():
    return {
        'tb': setnotify
    }