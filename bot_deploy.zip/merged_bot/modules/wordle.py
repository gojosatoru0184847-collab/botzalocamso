from zlapi.models import Message
import random, json, os
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Chơi Wordle đoán từ 5 chữ",'power':"Thành viên"}
WORDS = ["apple","bread","crane","drone","flame","grace","happy","inner","joker","knife",
         "lemon","magic","night","ocean","piano","queen","radio","snake","tiger","ultra",
         "video","water","xenon","yacht","zebra","alarm","blend","cloud","dance","earth"]
GAME_FILE = "modules/cache/wordle.json"

def load():
    try:
        with open(GAME_FILE, encoding='utf-8') as f: return json.load(f)
    except: return {}
def save(d):
    os.makedirs("modules/cache",exist_ok=True)
    with open(GAME_FILE,"w", encoding='utf-8') as f: json.dump(d,f)

def check_guess(secret, guess):
    result = []
    for i,(s,g) in enumerate(zip(secret,guess)):
        if g==s: result.append("🟩")
        elif g in secret: result.append("🟨")
        else: result.append("⬛")
    return "".join(result)

def handle_wordle_command(message, message_object, thread_id, thread_type, author_id, client):
    parts=message.strip().split(); games=load(); key=f"{thread_id}_{author_id}"
    if len(parts)==1:
        word=random.choice(WORDS)
        games[key]={"word":word,"tries":0,"max":6,"history":[]}; save(games)
        client.replyMessage(Message(text=f"🟩 WORDLE!\nĐoán từ 5 chữ cái tiếng Anh\n🟩=Đúng 🟨=Sai vị trí ⬛=Không có\nGõ: {PREFIX}wordle <từ>"), message_object, thread_id, thread_type); return
    if key not in games:
        client.replyMessage(Message(text=f"❌ Chưa bắt đầu! Gõ {PREFIX}wordle"), message_object, thread_id, thread_type); return
    g=games[key]; guess=parts[1].lower()
    if len(guess)!=5 or not guess.isalpha():
        client.replyMessage(Message(text="❌ Cần đúng 5 chữ cái!"), message_object, thread_id, thread_type); return
    g["tries"]+=1
    result=check_guess(g["word"],guess)
    g["history"].append(f"{guess.upper()} {result}")
    history_text="\n".join(g["history"])
    if guess==g["word"]:
        del games[key]; save(games)
        client.replyMessage(Message(text=f"🎉 Đúng! Sau {g['tries']} lần!\n{history_text}"), message_object, thread_id, thread_type)
    elif g["tries"]>=g["max"]:
        del games[key]; save(games)
        client.replyMessage(Message(text=f"💀 Thua! Từ đúng: {g['word'].upper()}\n{history_text}"), message_object, thread_id, thread_type)
    else:
        save(games)
        client.replyMessage(Message(text=f"Lần {g['tries']}/{g['max']}:\n{history_text}"), message_object, thread_id, thread_type)

def PTA():
    return {'wordle': handle_wordle_command}
