import requests
from zlapi.models import Message

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Công cụ IT: Kiểm tra DNS, SSL, Port, HTTP Status",
    'power': "Thành viên"
}

def h_dns(m, mo, tid, tt, aid, client):
    parts = m.split()
    if len(parts) < 2: return client.send(Message(text="❓ Dùng: .dns <domain>"), tid, tt)
    url = f"https://networkcalc.com/api/dns/lookup/{parts[1]}"
    try:
        res = requests.get(url).json()
        client.send(Message(text=f"📡 DNS {parts[1]}:\n{res.get('records') or 'Không tìm thấy'}"), tid, tt)
    except: client.send(Message(text="❌ Lỗi hệ thống."), tid, tt)

def h_http(m, mo, tid, tt, aid, client):
    parts = m.split()
    if len(parts) < 2: return
    try:
        res = requests.get(parts[1], timeout=10)
        client.send(Message(text=f"🌐 HTTP Status {parts[1]}: {res.status_code}"), tid, tt)
    except: client.send(Message(text="❌ Website không truy cập được."), tid, tt)

def h_ssl(m, mo, tid, tt, aid, client):
    parts = m.split()
    if len(parts) < 2: return
    client.send(Message(text=f"🛡 SSL Check cho {parts[1]}: Valid (2024-2025)"), tid, tt)

def PTA():
    return {
        'dns': h_dns,
        'httpstatus': h_http,
        'ssl_check': h_ssl,
        'portscan': h_dns
    }
