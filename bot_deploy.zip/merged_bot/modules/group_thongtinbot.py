from zlapi.models import Message
import platform, sys, time

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Thông tin hệ thống bot đang chạy", 'power': "Thành viên"}

START_TIME = time.time()

def handle_sysinfo_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        import psutil
        cpu = psutil.cpu_percent()
        ram = psutil.virtual_memory()
        msg = (
            f"🖥 THÔNG TIN HỆ THỐNG\n━━━━━━━━━━━━━━━\n"
            f"• Python: {sys.version.split()[0]}\n"
            f"• OS: {platform.system()} {platform.release()}\n"
            f"• CPU: {cpu}%\n"
            f"• RAM: {ram.percent}% ({ram.used//1024//1024}MB/{ram.total//1024//1024}MB)\n"
            f"• Uptime bot: {int(time.time()-START_TIME)}s"
        )
    except Exception:
        msg = f"🖥 Python: {sys.version.split()[0]} | OS: {platform.system()}"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'sysinfo': handle_sysinfo_command, 'sysinfobot': handle_sysinfo_command}
