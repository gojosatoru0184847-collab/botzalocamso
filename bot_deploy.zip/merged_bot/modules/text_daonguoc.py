from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đảo ngược chuỗi văn bản", 'power': "Thành viên"}

def handle_daonguoc_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="🔁 Dùng: .daonguoc <text>"), message_object, thread_id, thread_type)
        return
    client.replyMessage(Message(text=parts[1][::-1]), message_object, thread_id, thread_type)

def PTA():
    return {'daonguoc': handle_daonguoc_command, 'reverse': handle_daonguoc_command}
