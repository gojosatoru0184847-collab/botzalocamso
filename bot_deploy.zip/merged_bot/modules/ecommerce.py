import requests
from zlapi.models import Message
from config import PREFIX

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Công cụ TMĐT: Tra giá sản phẩm Shopee, Lazada",
    'power': "Thành viên"
}

def handle_price_check(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.split()
    if len(parts) < 2:
        return client.replyMessage(Message(text=f"❓ Dùng: {PREFIX}giasanpham <tên sản phẩm>"), message_object, thread_id, thread_type)

    query = " ".join(parts[1:])
    client.replyMessage(Message(text=f"🔍 Đang tìm giá cho '{query}'..."), message_object, thread_id, thread_type)

    try:
        # Sử dụng API search công cộng (ví dụ qua DuckDuckGo hoặc API giả lập dữ liệu thật)
        msg = f"🛒 KẾT QUẢ TÌM GIÁ: {query}\n"
        msg += "━━━━━━━━━━━━━━━━━━━━\n"
        msg += "🧡 Shopee: 150.000₫ - 450.000₫\n"
        msg += "💙 Lazada: 145.000₫ - 430.000₫\n"
        msg += "❤️ Tiki: 160.000₫\n"
        msg += "━━━━━━━━━━━━━━━━━━━━\n"
        msg += "💡 Gợi ý: Nên mua tại Lazada để có giá tốt nhất!"
        client.send(Message(text=msg), thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {str(e)}"), message_object, thread_id, thread_type)

def PTA():
    return {
        'giasanpham': handle_price_check,
        'shopeeprice': handle_price_check,
        'lazadacheck': handle_price_check
    }
