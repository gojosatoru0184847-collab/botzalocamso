from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đọc chữ từ ảnh (OCR)", 'power': "Thành viên"}

def _ocr(message, message_object, thread_id, thread_type, author_id, client):
    quote = getattr(message_object, 'quote', None)
    if not quote:
        client.replyMessage(Message(text="📷 Reply vào ảnh và gõ .ocr để đọc chữ trong ảnh."), message_object, thread_id, thread_type)
        return
    try:
        img_url = None
        if hasattr(quote, 'attach'):
            attach = quote.attach
            if isinstance(attach, str) and attach.startswith('http'): img_url = attach
            elif isinstance(attach, dict): img_url = attach.get('href') or attach.get('url')
        if not img_url and hasattr(quote, 'href'): img_url = quote.href
        if not img_url:
            client.replyMessage(Message(text="❌ Không tìm thấy ảnh."), message_object, thread_id, thread_type)
            return
        import base64
        img_data = requests.get(img_url, timeout=15).content
        img_b64 = base64.b64encode(img_data).decode()
        # OCR via OCR.space free API
        r = requests.post("https://api.ocr.space/parse/image",
            data={"base64Image": f"data:image/jpeg;base64,{img_b64}",
                  "language": "vie", "isOverlayRequired": False,
                  "apikey": "helloworld"},
            timeout=20)
        result = r.json()
        parsed = result.get("ParsedResults",[])
        if parsed:
            text = parsed[0].get("ParsedText","").strip()
            if text:
                client.replyMessage(Message(text=f"📝 NỘI DUNG ẢNH:\n{text[:1500]}"), message_object, thread_id, thread_type)
                return
        client.replyMessage(Message(text="❌ Không đọc được chữ trong ảnh này."), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi OCR: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'ocr': _ocr, 'docchu': _ocr}
