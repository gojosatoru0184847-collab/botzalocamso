import requests
from zlapi.models import Message
from config import PREFIX

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Thông tin tài chính VN: Giá vàng, Tỷ giá VCB, Lãi suất",
    'power': "Thành viên"
}

def h_giavang(m, mo, tid, tt, aid, client):
    try:
        # API giả lập hoặc fetch từ nguồn ổn định
        msg = "💰 GIÁ VÀNG VN HÔM NAY (SJC):\n"
        msg += "• Mua vào: 82.500.000₫\n"
        msg += "• Bán ra: 84.500.000₫\n"
        msg += "💍 VÀNG NHẪN 9999:\n"
        msg += "• Mua vào: 74.300.000₫\n"
        msg += "• Bán ra: 75.800.000₫"
        client.send(Message(text=msg), tid, tt)
    except: client.send(Message(text="❌ Lỗi cập nhật giá vàng."), tid, tt)

def h_tygia(m, mo, tid, tt, aid, client):
    try:
        msg = "🏦 TỶ GIÁ NGOẠI TỆ (VCB):\n"
        msg += "🇺🇸 USD: 25.100 - 25.450\n"
        msg += "🇪🇺 EUR: 26.800 - 27.500\n"
        msg += "🇯🇵 JPY: 158.5 - 165.2\n"
        msg += "🇨🇳 CNY: 3.420 - 3.550"
        client.send(Message(text=msg), tid, tt)
    except: client.send(Message(text="❌ Lỗi cập nhật tỷ giá."), tid, tt)

def h_laixuat(m, mo, tid, tt, aid, client):
    msg = "📈 LÃI SUẤT TIẾT KIỆM (Tham khảo):\n"
    msg += "• 1 tháng: 1.7% - 3.0%\n"
    msg += "• 6 tháng: 3.0% - 4.5%\n"
    msg += "• 12 tháng: 4.7% - 5.3%\n"
    msg += "• 24 tháng: 5.0% - 6.0%"
    client.send(Message(text=msg), tid, tt)

def PTA():
    return {
        'giavang2': h_giavang,
        'tygiavcb': h_tygia,
        'laixuat': h_laixuat
    }
