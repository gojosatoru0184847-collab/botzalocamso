from zlapi.models import Message
import random, json, os
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Chơi Bingo số",'power':"Thành viên"}
GAME_FILE = "modules/cache/bingo.json"

def load(): 
    try:
        with open(GAME_FILE, encoding='utf-8') as f: return json.load(f)
    except: return {}

def save(d):
    os.makedirs("modules/cache", exist_ok=True)
    with open(GAME_FILE,"w", encoding='utf-8') as f: json.dump(d,f)

def handle_bingo_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    games = load(); key = str(thread_id)
    if len(parts) == 1 or parts[1].lower() == "new":
        nums = random.sample(range(1,76),5)
        games[key] = {"pool": list(range(1,76)), "card": nums, "called": []}
        save(games)
        card_str = " | ".join(f"[{n:2d}]" for n in sorted(nums))
        client.replyMessage(Message(text=f"🎰 BINGO! Thẻ của bạn:\n{card_str}\nGõ {PREFIX}bingo draw để rút số!"), message_object, thread_id, thread_type)
    elif parts[1].lower() == "draw":
        if key not in games:
            client.replyMessage(Message(text=f"❌ Chưa bắt đầu! Gõ {PREFIX}bingo new"), message_object, thread_id, thread_type); return
        g = games[key]
        if not g["pool"]:
            client.replyMessage(Message(text="🎰 Hết số rồi!"), message_object, thread_id, thread_type); return
        n = random.choice(g["pool"])
        g["pool"].remove(n); g["called"].append(n)
        hit = n in g["card"]
        matched = [x for x in g["card"] if x in g["called"]]
        save(games)
        status = f"✅ TRÚNG {n}! ({len(matched)}/5)" if hit else f"❌ Số {n} - Chưa trúng ({len(matched)}/5)"
        if len(matched) == 5:
            del games[key]; save(games)
            status += "\n🎉🎉 BINGO! Bạn thắng! 🎉🎉"
        client.replyMessage(Message(text=f"🎰 Rút được: {n}\n{status}"), message_object, thread_id, thread_type)

def PTA():
    return {'bingo': handle_bingo_command}
