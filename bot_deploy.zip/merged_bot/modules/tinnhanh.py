from zlapi.models import Message
import requests
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tin tức mới nhất",'power':"Thành viên"}

def handle_tinnhanh_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get(
            "https://gnews.io/api/v4/top-headlines?lang=vi&country=vn&max=5&apikey=demo",
            timeout=10
        )
        data = r.json()
        articles = data.get("articles",[])
        if not articles:
            # Fallback: dùng RSS VnExpress
            import xml.etree.ElementTree as ET
            rss = requests.get("https://vnexpress.net/rss/tin-moi-nhat.rss", timeout=10)
            root = ET.fromstring(rss.content)
            items = root.findall(".//item")[:5]
            msg = "📰 TIN TỨC MỚI NHẤT (VnExpress)\n━━━━━━━━━━━━━━━\n"
            for i, item in enumerate(items, 1):
                title = item.findtext("title","")
                link = item.findtext("link","")
                msg += f"{i}. {title}\n🔗 {link}\n\n"
        else:
            msg = "📰 TIN TỨC MỚI NHẤT\n━━━━━━━━━━━━━━━\n"
            for i, a in enumerate(articles, 1):
                msg += f"{i}. {a.get('title','')}\n🔗 {a.get('url','')}\n\n"
        client.replyMessage(Message(text=msg.strip()), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'tinnhanh': handle_tinnhanh_command}
