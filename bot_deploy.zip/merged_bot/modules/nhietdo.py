from zlapi.models import Message
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Chuyển đổi nhiệt độ C/F/K",'power':"Thành viên"}

def handle_nhietdo_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 3:
        client.replyMessage(Message(text=f"🌡 Dùng: {PREFIX}nhietdo <số> <đơn vị: C/F/K>\nVí dụ: {PREFIX}nhietdo 100 C"), message_object, thread_id, thread_type); return
    try:
        val = float(parts[1])
        unit = parts[2].upper()
        if unit == "C":
            f = val*9/5+32; k = val+273.15
            msg = f"🌡 {val}°C = {f:.2f}°F = {k:.2f}K"
        elif unit == "F":
            c = (val-32)*5/9; k = c+273.15
            msg = f"🌡 {val}°F = {c:.2f}°C = {k:.2f}K"
        elif unit == "K":
            c = val-273.15; f = c*9/5+32
            msg = f"🌡 {val}K = {c:.2f}°C = {f:.2f}°F"
        else:
            raise ValueError()
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Đơn vị hợp lệ: C, F, K"), message_object, thread_id, thread_type)

def PTA():
    return {'nhietdo': handle_nhietdo_command}
