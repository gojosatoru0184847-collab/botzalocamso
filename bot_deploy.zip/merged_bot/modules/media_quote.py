from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Câu nói hay ngẫu nhiên", 'power': "Thành viên"}

def handle_quote_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://api.quotable.io/random", timeout=10)
        data = r.json()
        msg = f"💭 \"{data.get('content')}\"\n— {data.get('author','Unknown')}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'quote': handle_quote_command, 'cauhay': handle_quote_command}
