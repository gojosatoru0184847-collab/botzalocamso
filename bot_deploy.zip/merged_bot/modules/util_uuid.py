from zlapi.models import Message
import uuid

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Sinh UUID ngẫu nhiên", 'power': "Thành viên"}

def handle_uuid_command(message, message_object, thread_id, thread_type, author_id, client):
    new_id = str(uuid.uuid4())
    client.replyMessage(Message(text=f"🆔 UUID: {new_id}"), message_object, thread_id, thread_type)

def PTA():
    return {'uuid': handle_uuid_command}
