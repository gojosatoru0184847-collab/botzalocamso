from zlapi.models import Message
from datetime import datetime

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Xem ngày âm lịch hôm nay", 'power': "Thành viên"}

def _solar_to_lunar(dd, mm, yy):
    # Thuật toán chuyển đổi âm dương lịch (Hồ Ngọc Đức)
    import math
    def jdn(dd, mm, yy):
        a = (14 - mm) // 12
        y = yy + 4800 - a
        m = mm + 12*a - 3
        jd = dd + (153*m+2)//5 + 365*y + y//4 - y//100 + y//400 - 32045
        return jd
    def get_new_moon_day(k):
        T = k/1236.85
        T2, T3, T4 = T*T, T*T*T, T*T*T*T
        Jd1 = 2415020.75933 + 29.53058868*k + 0.0001178*T2 - 0.000000155*T3
        Jd1 += 0.00033*math.sin(math.radians(166.56+132.87*T-0.009173*T2))
        M = 359.2242+29.10535608*k-0.0000333*T2-0.00000347*T3
        Mpr = 306.0253+385.81691806*k+0.0107306*T2+0.00001236*T3
        F = 21.2964+390.67050646*k-0.0016528*T2-0.00000239*T3
        C1 = (0.1734-0.000393*T)*math.sin(math.radians(M))+0.0021*math.sin(math.radians(2*M))
        C1 -= 0.4068*math.sin(math.radians(Mpr))+0.0161*math.sin(math.radians(2*Mpr))
        C1 -= 0.0004*math.sin(math.radians(3*Mpr))
        C1 += 0.0104*math.sin(math.radians(2*F))-0.0051*math.sin(math.radians(M+Mpr))
        C1 -= 0.0074*math.sin(math.radians(M-Mpr))+0.0004*math.sin(math.radians(2*F+M))
        C1 -= 0.0004*math.sin(math.radians(2*F-M))-0.0006*math.sin(math.radians(2*F+Mpr))
        C1 += 0.0010*math.sin(math.radians(2*F-Mpr))+0.0005*math.sin(math.radians(2*Mpr+M))
        JdNew = Jd1 + C1
        return math.floor(JdNew + 0.5)
    def get_sun_longitude(jdn_):
        T = (jdn_ - 2451545.5) / 36525
        T2 = T*T
        dr = math.pi/180
        M = 357.52910+35999.05030*T-0.0001559*T2-0.00000048*T*T2
        L0 = 280.46645+36000.76983*T+0.0003032*T2
        DL = (1.914600-0.004817*T-0.000014*T2)*math.sin(M*dr)
        DL += (0.019993-0.000101*T)*math.sin(2*M*dr)+0.000290*math.sin(3*M*dr)
        L = L0 + DL
        L = L*dr
        L = L - math.pi*2*math.floor(L/(math.pi*2))
        return math.floor(L / math.pi * 6)
    dayNumber = jdn(dd, mm, yy)
    k = math.floor((dayNumber - 2415021.076998695) / 29.530588853)
    monthStart = get_new_moon_day(k+1)
    if monthStart > dayNumber:
        monthStart = get_new_moon_day(k)
    a11 = get_sun_longitude(monthStart) if monthStart else 0
    lunarDay = dayNumber - monthStart + 1
    lunarMonth = ((get_sun_longitude(monthStart) // 1) % 12) + 1 if monthStart else mm
    return int(lunarDay), int(lunarMonth) if lunarMonth else mm, yy

def handle_amlich_command(message, message_object, thread_id, thread_type, author_id, client):
    now = datetime.now()
    try:
        ld, lm, ly = _solar_to_lunar(now.day, now.month, now.year)
        msg = (
            f"📅 NGÀY ÂM LỊCH\n━━━━━━━━━━━━━━━\n"
            f"• Dương lịch: {now.day}/{now.month}/{now.year}\n"
            f"• Âm lịch (ước tính): {ld}/{lm}/{ly}\n"
            f"⚠️ Lưu ý: kết quả chỉ mang tính tham khảo"
        )
    except Exception:
        msg = f"📅 Dương lịch: {now.day}/{now.month}/{now.year}\n(Không tính được âm lịch chính xác)"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'amlich': handle_amlich_command, 'lichvn': handle_amlich_command}
