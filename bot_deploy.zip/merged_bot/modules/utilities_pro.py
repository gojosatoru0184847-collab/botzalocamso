import urllib.parse
from zlapi.models import Message
import requests
import tempfile
import os
from PIL import Image

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Công cụ tiện ích: QR Wifi, Barcode",
    'power': "Thành viên"
}

def send_img(client, tid, tt, url, caption=""):
    temp_path = None
    try:
        res = requests.get(url, timeout=20)
        if res.status_code == 200:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
                tf.write(res.content)
                temp_path = tf.name
            with Image.open(temp_path) as img: w, h = img.size
            client.sendLocalImage(temp_path, thread_id=tid, thread_type=tt, width=w, height=h, message=Message(text=caption))
    finally:
        if temp_path and os.path.exists(temp_path): os.remove(temp_path)

def h_qrwifi(m, mo, tid, tt, aid, client):
    parts = m.split()
    if len(parts) < 3: return client.send(Message(text="❓ Dùng: .qrwifi <tên_wifi> <mật_khẩu>"), tid, tt)
    ssid, pwd = parts[1], parts[2]
    url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=WIFI:S:{ssid};T:WPA;P:{pwd};;"
    send_img(client, tid, tt, url, f"📶 QR WIFI cho nhóm: {ssid}")

def h_barcode(m, mo, tid, tt, aid, client):
    parts = m.split()
    if len(parts) < 2: return
    data = parts[1]
    url = f"https://barcode.tec-it.com/barcode.ashx?data={data}&code=Code128"
    send_img(client, tid, tt, url, f"🏷 BARCODE: {data}")

def PTA():
    return {
        'qrwifi': h_qrwifi,
        'barcode': h_barcode,
        'fontpreview': h_barcode
    }
