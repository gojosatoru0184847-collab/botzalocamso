from zlapi.models import Message
import base64

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Mã hóa / giải mã: Base64, Caesar, ROT13, Hex", 'power': "Thành viên"}

_ROT13 = str.maketrans(
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
    'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm')

def _caesar(t, s):
    r = ""
    for c in t:
        if c.isalpha():
            b = ord('A') if c.isupper() else ord('a')
            r += chr((ord(c)-b+s) % 26 + b)
        else: r += c
    return r

def _enc(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=2)
    if len(p) < 3:
        client.replyMessage(Message(text="🔐 Dùng: .encode <b64/caesar/rot13/hex> <text>"), message_object, thread_id, thread_type); return
    m, t = p[1].lower(), p[2]
    try:
        if m == "b64":    r = base64.b64encode(t.encode()).decode()
        elif m == "caesar": r = _caesar(t, 3)
        elif m == "rot13": r = t.translate(_ROT13)
        elif m == "hex":   r = t.encode().hex()
        else: r = f"Không hỗ trợ '{m}'"
        client.replyMessage(Message(text=f"🔐 [{m.upper()}]:\n{r}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ {e}"), message_object, thread_id, thread_type)

def _dec(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=2)
    if len(p) < 3:
        client.replyMessage(Message(text="🔓 Dùng: .decode <b64/caesar/rot13/hex> <text>"), message_object, thread_id, thread_type); return
    m, t = p[1].lower(), p[2]
    try:
        if m == "b64":    r = base64.b64decode(t.encode()).decode(errors='replace')
        elif m == "caesar": r = _caesar(t, -3)
        elif m == "rot13": r = t.translate(_ROT13)
        elif m == "hex":   r = bytes.fromhex(t).decode(errors='replace')
        else: r = f"Không hỗ trợ '{m}'"
        client.replyMessage(Message(text=f"🔓 [{m.upper()}]:\n{r}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'encode': _enc, 'mahoa': _enc, 'decode': _dec, 'giama': _dec}
