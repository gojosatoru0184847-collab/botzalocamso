from zlapi.models import Message
import json, os, random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chơi đoán từ tiếng Việt (Wordle)", 'power': "Thành viên"}

WORDS = ["apple","house","music","water","light","black","white","green","table","phone",
         "smile","heart","cloud","night","earth","world","money","bread","sugar","dream",
         "stone","track","grace","slide","plant","curve","large","small","quick","brave"]

GAME_FILE = "modules/cache/data/wordle_vn.json"

def _load():
    try:
        with open(GAME_FILE, encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

def _check(guess, secret):
    result = []
    for i, c in enumerate(guess):
        if c == secret[i]: result.append("🟩")
        elif c in secret: result.append("🟨")
        else: result.append("⬛")
    return "".join(result)

def _play(message, message_object, thread_id, thread_type, author_id, client):
    games = _load()
    tid = str(thread_id)
    uid = str(author_id)
    key = f"{tid}_{uid}"
    p = message.strip().split(maxsplit=1)

    if len(p) < 2 or p[1].lower() == "new":
        word = random.choice(WORDS)
        games[key] = {"word": word, "tries": 0, "max": 6}
        _save(games)
        client.replyMessage(Message(text=f"🔤 WORDLE - Đoán từ 5 chữ cái!\nGõ .wordle <từ> để đoán (tối đa 6 lần)\nVí dụ: .wordle apple"), message_object, thread_id, thread_type)
        return

    if key not in games:
        client.replyMessage(Message(text="❌ Chưa có game. Gõ .wordle new để bắt đầu."), message_object, thread_id, thread_type)
        return

    guess = p[1].strip().lower()
    if len(guess) != 5 or not guess.isalpha():
        client.replyMessage(Message(text="❌ Phải đoán đúng 5 chữ cái tiếng Anh."), message_object, thread_id, thread_type)
        return

    g = games[key]
    g["tries"] += 1
    result = _check(guess, g["word"])

    if guess == g["word"]:
        del games[key]
        _save(games)
        client.replyMessage(Message(text=f"{result}\n🎉 Chính xác! Từ là '{g['word']}'\nBạn đoán đúng sau {g['tries']} lần!"), message_object, thread_id, thread_type)
    elif g["tries"] >= g["max"]:
        secret = g["word"]
        del games[key]
        _save(games)
        client.replyMessage(Message(text=f"{result}\n❌ Hết lượt! Từ đúng là: '{secret}'"), message_object, thread_id, thread_type)
    else:
        _save(games)
        left = g["max"] - g["tries"]
        client.replyMessage(Message(text=f"{result}\nCòn {left} lượt đoán."), message_object, thread_id, thread_type)

def PTA():
    return {'wordlevn': _play, 'doantu': _play}
