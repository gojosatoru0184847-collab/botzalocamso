from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Thông tin Covid-19 theo quốc gia", 'power': "Thành viên"}

def handle_covid_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    country = parts[1] if len(parts) > 1 else "vietnam"
    try:
        r = requests.get(f"https://disease.sh/v3/covid-19/countries/{country}", timeout=10)
        data = r.json()
        msg = (
            f"🦠 COVID-19: {data.get('country','N/A')}\n━━━━━━━━━━━━━━━\n"
            f"• Tổng ca: {data.get('cases',0):,}\n"
            f"• Tử vong: {data.get('deaths',0):,}\n"
            f"• Hồi phục: {data.get('recovered',0):,}\n"
            f"• Đang điều trị: {data.get('active',0):,}"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy dữ liệu cho '{country}': {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'covid': handle_covid_command}
