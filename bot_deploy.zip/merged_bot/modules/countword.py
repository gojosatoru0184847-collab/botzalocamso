from zlapi.models import Message
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Đếm ký tự, từ, dòng",'power':"Thành viên"}

def handle_countword_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        if getattr(message_object, 'quote', None):
            text = getattr(message_object, 'quote', None).msg or ""
        else:
            client.replyMessage(Message(text=f"📊 Dùng: {PREFIX}countword <text>"), message_object, thread_id, thread_type); return
    else:
        text = parts[1]
    chars = len(text)
    chars_no_space = len(text.replace(" ",""))
    words = len(text.split())
    lines = len(text.splitlines())
    msg = (f"📊 THỐNG KÊ VĂN BẢN\n━━━━━━━━━━━━━━━\n"
           f"• Ký tự (có dấu cách): {chars}\n• Ký tự (không dấu cách): {chars_no_space}\n"
           f"• Từ: {words}\n• Dòng: {lines}")
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'countword': handle_countword_command}
