from zlapi.models import Message
from datetime import datetime, timedelta
import pytz

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Xem ngày giờ, đếm ngược sự kiện", 'power': "Thành viên"}

VN_TZ = pytz.timezone("Asia/Ho_Chi_Minh")

def _now(message, message_object, thread_id, thread_type, author_id, client):
    now = datetime.now(VN_TZ)
    days_vn = ["Thứ Hai","Thứ Ba","Thứ Tư","Thứ Năm","Thứ Sáu","Thứ Bảy","Chủ Nhật"]
    dow = days_vn[now.weekday()]
    msg = (f"🕐 GIỜ VIỆT NAM\n{dow}, {now.strftime('%d/%m/%Y')}\n{now.strftime('%H:%M:%S')}")
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def _countdown(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="📅 Dùng: .countdown dd/mm/yyyy\nVí dụ: .countdown 01/01/2026"), message_object, thread_id, thread_type)
        return
    try:
        target = datetime.strptime(p[1].strip(), "%d/%m/%Y")
        now = datetime.now()
        delta = target - now
        if delta.days < 0:
            client.replyMessage(Message(text=f"📅 {p[1]} đã qua {abs(delta.days)} ngày trước."), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text=f"⏳ Còn {delta.days} ngày đến {p[1]}"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Sai định dạng. Dùng dd/mm/yyyy"), message_object, thread_id, thread_type)

def _weekday(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="📅 Dùng: .thumayngay dd/mm/yyyy"), message_object, thread_id, thread_type)
        return
    try:
        d = datetime.strptime(p[1].strip(), "%d/%m/%Y")
        days_vn = ["Thứ Hai","Thứ Ba","Thứ Tư","Thứ Năm","Thứ Sáu","Thứ Bảy","Chủ Nhật"]
        client.replyMessage(Message(text=f"📅 {p[1]} là {days_vn[d.weekday()]}"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Sai định dạng. Dùng dd/mm/yyyy"), message_object, thread_id, thread_type)

def PTA():
    return {'now': _now, 'giohientai': _now, 'countdown': _countdown, 'demngay': _countdown, 'thumayngay': _weekday}
