from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đổi mã màu HEX/RGB", 'power': "Thành viên"}

def handle_color_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🎨 Dùng: .color #FF5733 hoặc .color 255,87,51"), message_object, thread_id, thread_type)
        return
    val = parts[1]
    try:
        if val.startswith("#"):
            h = val.lstrip("#")
            r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
            msg = f"🎨 HEX {val} → RGB({r},{g},{b})"
        else:
            r, g, b = map(int, val.split(","))
            hex_val = "#{:02x}{:02x}{:02x}".format(r,g,b)
            msg = f"🎨 RGB({r},{g},{b}) → HEX {hex_val}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi định dạng màu: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'color': handle_color_command, 'mausac': handle_color_command}
