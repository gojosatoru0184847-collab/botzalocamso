# -*- coding: utf-8 -*-
import os
import requests
import tempfile
import time
import subprocess
import threading
import json
import base64
from zlapi.models import Message

des = {
    'version': "2.0.0",
    'credits': "HOANG LAM",
    'description': "Gửi tin nhắn thoại TikTok Đa Giọng (Nam/Nữ)",
    'power': "Thành viên"
}

# Cấu hình giọng nói TikTok
VOICE_MAP = {
    "nam": "vi_male_trananh",
    "nữ": "vi_female_linhchi",
    "nu": "vi_female_linhchi"
}
DEFAULT_VOICE = "vi_male_trananh" # Giọng nam mặc định theo ý Đại ca

def get_audio_duration(file_path):
    try:
        cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', file_path]
        duration = subprocess.check_output(cmd).decode('utf-8').strip()
        return int(float(duration) * 1000)
    except:
        return 5000

def is_ffmpeg_installed():
    try:
        subprocess.run(['ffmpeg', '-version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except:
        return False

def handle_voice_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message_object.content.strip()
    parts = content.split(maxsplit=2) # Tách: .voice | nam/nữ | nội dung

    if len(parts) < 2:
        msg = "🎙️ [ MENU GIỌNG NÓ NÓI ]\n"
        msg += "━━━━━━━━━━━━━━━\n"
        msg += f"🔹 Mặc định (Nam): {client.prefix}voice [nội dung]\n"
        msg += f"🔹 Giọng Nữ: {client.prefix}voice nữ [nội dung]\n"
        msg += f"🔹 Giọng Nam: {client.prefix}voice nam [nội dung]\n"
        msg += "━━━━━━━━━━━━━━━\n"
        msg += "💡 Ví dụ: .voice nữ chào đại ca"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
        return

    # Kiểm tra xem có từ khóa chọn giọng không
    first_arg = parts[1].lower()
    if first_arg in VOICE_MAP:
        voice_id = VOICE_MAP[first_arg]
        if len(parts) < 3:
            client.replyMessage(Message(text="⚠️ Đại ca chưa nhập nội dung cần nói."), message_object, thread_id, thread_type)
            return
        text_to_say = parts[2]
    else:
        # Không có từ khóa -> Dùng giọng mặc định
        voice_id = DEFAULT_VOICE
        text_to_say = content.split(maxsplit=1)[1]

    temp_mp3 = None
    temp_aac = None

    try:
        cache_dir = "modules/cache/voice_temp"
        os.makedirs(cache_dir, exist_ok=True)

        fd_aac, temp_aac = tempfile.mkstemp(suffix=".aac", dir=cache_dir)
        os.close(fd_aac)

        # GỌI API TIKTOK
        api_url = "https://tiktok-tts.weilbyte.dev/api/generate"
        use_tiktok = False
        try:
            payload = {"text": text_to_say, "voice": voice_id}
            response = requests.post(api_url, json=payload, timeout=10)

            if response.status_code == 200:
                data = response.json()
                if "data" in data:
                    with open(temp_aac, 'wb') as f:
                        f.write(base64.b64decode(data["data"]))
                    use_tiktok = True
        except Exception as tiktok_err:
            print(f"[VOICE] TikTok API Error: {tiktok_err}")

        # FALLBACK GOOGLE TTS
        if not use_tiktok:
            from gtts import gTTS
            fd_mp3, temp_mp3 = tempfile.mkstemp(suffix=".mp3", dir=cache_dir)
            os.close(fd_mp3)
            tts = gTTS(text=text_to_say, lang='vi')
            tts.save(temp_mp3)

            if is_ffmpeg_installed():
                subprocess.run(['ffmpeg', '-y', '-i', temp_mp3, '-c:a', 'aac', '-ac', '1', '-ar', '16000', '-b:a', '32k', temp_aac],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                with open(temp_mp3, 'rb') as f_in, open(temp_aac, 'wb') as f_out:
                    f_out.write(f_in.read())

            try: os.remove(temp_mp3)
            except: pass

        duration = get_audio_duration(temp_aac)
        file_size = os.path.getsize(temp_aac)

        # GỬI TIN NHẮN THOẠI
        voice_url = None
        try:
            with open(temp_aac, 'rb') as f:
                up = requests.post('https://catbox.moe/user/api.php',
                                   data={'reqtype': 'fileupload'},
                                   files={'fileToUpload': f},
                                   timeout=15)
                voice_url = up.text.strip()

                if voice_url.startswith('http'):
                    res = client.sendRemoteVoice(voice_url, thread_id, thread_type, fileSize=file_size, duration=duration)
                    if res:
                        client.sendReaction(message_object, "🎤", thread_id, thread_type)
                        return
        except Exception as e:
            print(f"[VOICE] Upload Error: {e}")

        if voice_url and voice_url.startswith('http'):
             client.replyMessage(Message(text=f"🎤 (Zalo bận) Nghe tại: {voice_url}"), message_object, thread_id, thread_type)

    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {str(e)}"), message_object, thread_id, thread_type)

    finally:
        def cleanup(files):
            time.sleep(60)
            for f in files:
                if f and os.path.exists(f):
                    try: os.remove(f)
                    except: pass

        cleanup_list = [temp_aac]
        if 'temp_mp3' in locals() and temp_mp3:
            cleanup_list.append(temp_mp3)

        threading.Thread(target=cleanup, args=(cleanup_list,), daemon=True).start()

def PTA():
    return {'voice': handle_voice_command}
