from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tỷ giá ngoại tệ", 'power': "Thành viên"}

def handle_tygia_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    base = parts[1].upper() if len(parts) > 1 else "USD"
    try:
        r = requests.get(f"https://open.er-api.com/v6/latest/{base}", timeout=10)
        data = r.json()
        if data.get("result") != "success":
            raise ValueError("Mã tiền tệ không hợp lệ")
        rates = data["rates"]
        vnd = rates.get("VND", "N/A")
        usd = rates.get("USD", "N/A")
        eur = rates.get("EUR", "N/A")
        jpy = rates.get("JPY", "N/A")
        msg = (
            f"💱 TỶ GIÁ {base}\n"
            f"━━━━━━━━━━━━━━━\n"
            f"🇻🇳 VND: {vnd:,.0f}\n"
            f"🇺🇸 USD: {usd}\n"
            f"🇪🇺 EUR: {eur}\n"
            f"🇯🇵 JPY: {jpy}\n"
            f"Cập nhật: {data.get('time_last_update_utc','N/A')}"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'tygia': handle_tygia_command, 'exchange': handle_tygia_command}
