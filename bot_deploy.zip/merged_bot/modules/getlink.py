from zlapi.models import Message
import json
import urllib.parse
import re

des = {
    'version': "1.1.0",
    'credits': "HOANG LAM",
    'description': "Lấy link trực tiếp từ ảnh, video, file hoặc tin nhắn trích dẫn",
    'power': "Thành viên"
}

def extract_url(text):
    url_pattern = r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+[/\w\.-]*\??[\w=&]*'
    match = re.search(url_pattern, text)
    return match.group(0) if match else None

def handle_getlink_command(message, message_object, thread_id, thread_type, author_id, client):
    # 1. Kiểm tra nếu có link trực tiếp trong tin nhắn lệnh
    link_in_msg = extract_url(message)
    if link_in_msg:
        return client.replyMessage(Message(text=f"🔗 Link phát hiện:\n{link_in_msg}"), message_object, thread_id, thread_type)

    # 2. Kiểm tra nếu là reply tin nhắn (Quote)
    if message_object.quote:
        attach = message_object.quote.attach
        if attach:
            try:
                data = json.loads(attach)
                url = data.get('hdUrl') or data.get('href') or data.get('url')
                if url:
                    return client.replyMessage(Message(text=f"🔗 Link từ dữ liệu đính kèm:\n{url}"), message_object, thread_id, thread_type)
            except:
                pass
        
        # Thử tìm link trong text của tin nhắn được quote
        quote_text = getattr(message_object.quote, 'text', '') or getattr(message_object.quote, 'content', '')
        if isinstance(quote_text, str):
            link_in_quote = extract_url(quote_text)
            if link_in_quote:
                return client.replyMessage(Message(text=f"🔗 Link từ tin nhắn trích dẫn:\n{link_in_quote}"), message_object, thread_id, thread_type)

    # 3. Thông báo nếu không thấy gì
    client.replyMessage(
        Message(text="⚠️ Không tìm thấy link nào. Bạn hãy:\n1. Reply vào ảnh/video/file cần lấy link.\n2. Gửi kèm link trong tin nhắn."),
        message_object, thread_id, thread_type
    )

def PTA():
    return {
        'getlink': handle_getlink_command
    }
