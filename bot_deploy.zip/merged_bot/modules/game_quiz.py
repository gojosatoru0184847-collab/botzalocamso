from zlapi.models import Message
import random, json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Trắc nghiệm kiến thức", 'power': "Thành viên"}

QUESTIONS = [
    {"q": "Thủ đô của Việt Nam là gì?", "a": ["hà nội"]},
    {"q": "1 + 1 x 2 = ?", "a": ["3"]},
    {"q": "Hành tinh gần Mặt Trời nhất?", "a": ["sao thủy", "thủy tinh", "mercury"]},
    {"q": "Việt Nam có bao nhiêu tỉnh thành (2024)?", "a": ["63"]},
    {"q": "Tác giả Truyện Kiều là ai?", "a": ["nguyễn du"]},
    {"q": "Sông dài nhất Việt Nam?", "a": ["sông mê kông", "mê kông", "cửu long"]},
    {"q": "Ngôn ngữ lập trình phổ biến nhất 2024?", "a": ["python"]},
    {"q": "1 năm có bao nhiêu ngày (năm thường)?", "a": ["365"]},
    {"q": "Quốc gia có dân số đông nhất thế giới?", "a": ["ấn độ", "india"]},
    {"q": "Đỉnh núi cao nhất Việt Nam?", "a": ["fansipan", "phan xi păng"]},
    {"q": "Năm Việt Nam giải phóng hoàn toàn?", "a": ["1975"]},
    {"q": "Số nguyên tố nhỏ nhất?", "a": ["2"]},
]

GAME_FILE = "modules/cache/data/quiz_game.json"

def _load():
    try:
        with open(GAME_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)

def handle_quiz_command(message, message_object, thread_id, thread_type, author_id, client):
    games = _load()
    tid = str(thread_id)
    parts = message.strip().split(maxsplit=1)

    if len(parts) >= 2 and tid in games:
        answer = parts[1].strip().lower()
        correct = games[tid]["a"]
        if answer in correct:
            del games[tid]
            _save(games)
            client.replyMessage(Message(text="🎉 Chính xác!"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="❌ Sai rồi, thử lại!"), message_object, thread_id, thread_type)
        return

    q = random.choice(QUESTIONS)
    games[tid] = {"q": q["q"], "a": q["a"]}
    _save(games)
    client.replyMessage(Message(text=f"❓ {q['q']}\n(Trả lời bằng .quiz <câu trả lời>)"), message_object, thread_id, thread_type)

def PTA():
    return {'quiz': handle_quiz_command, 'tracnghiem': handle_quiz_command}
