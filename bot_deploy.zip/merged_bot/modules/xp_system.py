from zlapi.models import Message
import json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Hệ thống XP & cấp độ thành viên", 'power': "Thành viên"}

XP_FILE = "modules/cache/data/xp_data.json"
XP_PER_MSG = 5
LEVELS = [0,100,300,600,1000,1500,2100,2800,3600,4500,5500]
LEVEL_NAMES = ["Mới","Sơ Cấp","Cơ Bản","Trung Cấp","Thành Thạo","Chuyên Gia","Cao Thủ","Đại Sư","Huyền Thoại","Siêu Việt","Vô Địch"]

def _load():
    try:
        with open(XP_FILE,'r',encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(XP_FILE), exist_ok=True)
    with open(XP_FILE,'w',encoding='utf-8') as f: json.dump(d,f,indent=2)

def get_level(xp):
    for i in range(len(LEVELS)-1, -1, -1):
        if xp >= LEVELS[i]: return i
    return 0

def _xp(message, message_object, thread_id, thread_type, author_id, client):
    d = _load(); uid = str(author_id)
    xp = d.get(uid, 0)
    lv = get_level(xp)
    next_xp = LEVELS[lv+1] if lv < len(LEVELS)-1 else LEVELS[-1]
    pct = int((xp - LEVELS[lv]) / max(1, next_xp - LEVELS[lv]) * 20)
    bar = "█"*pct + "░"*(20-pct)
    msg = (f"⚡ XP CỦA BẠN\n━━━━━━━━━━━━\n"
           f"• Cấp: {lv} - {LEVEL_NAMES[min(lv,len(LEVEL_NAMES)-1)]}\n"
           f"• XP: {xp}/{next_xp}\n• [{bar}]")
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def _topxp(message, message_object, thread_id, thread_type, author_id, client):
    d = _load()
    top = sorted(d.items(), key=lambda x:x[1], reverse=True)[:10]
    lines = []
    for i,(uid,xp) in enumerate(top,1):
        lv = get_level(xp)
        lines.append(f"{i}. [{LEVEL_NAMES[min(lv,len(LEVEL_NAMES)-1)]}] UID:{uid[:8]}... - {xp}XP")
    msg = "🏆 TOP XP\n" + "\n".join(lines) if lines else "Chưa có dữ liệu XP"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def add_xp(author_id, amount=XP_PER_MSG):
    """Gọi từ event handler để cộng XP mỗi tin nhắn"""
    d = _load()
    uid = str(author_id)
    old_lv = get_level(d.get(uid,0))
    d[uid] = d.get(uid,0) + amount
    new_lv = get_level(d[uid])
    _save(d)
    return new_lv > old_lv, new_lv  # trả về True nếu vừa lên cấp

def PTA():
    return {'xp': _xp, 'level': _xp, 'topxp': _topxp}
