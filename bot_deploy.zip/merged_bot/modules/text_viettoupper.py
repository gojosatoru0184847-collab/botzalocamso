from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chuyển chữ HOA/thường/Title", 'power': "Thành viên"}

def handle_textcase_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=2)
    if len(parts) < 3:
        client.replyMessage(Message(text="🔤 Dùng: .textcase upper/lower/title <text>"), message_object, thread_id, thread_type)
        return
    mode, text = parts[1].lower(), parts[2]
    if mode == "upper":
        result = text.upper()
    elif mode == "lower":
        result = text.lower()
    elif mode == "title":
        result = text.title()
    else:
        result = "❌ Chỉ hỗ trợ upper/lower/title"
    client.replyMessage(Message(text=result), message_object, thread_id, thread_type)

def PTA():
    return {'textcase': handle_textcase_command}
