import requests
import re
import os
import tempfile
from zlapi.models import Message, ThreadType
from config import PREFIX

des = {
    'version': "1.2.0",
    'credits': "HOANG LAM",
    'description': "Tải video TikTok, FB, IG (Gửi video trực tiếp qua Zalo)",
    'power': "Thành viên"
}

def extract_url(text):
    url_pattern = r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+[/\w\.-]*\??[\w=&]*'
    match = re.search(url_pattern, text)
    return match.group(0) if match else None

def handle_dl_command(message, message_object, thread_id, thread_type, author_id, client):
    url = extract_url(message)
    if not url:
        return client.replyMessage(Message(text=f"⚠️ Vui lòng gửi kèm link video."), message_object, thread_id, thread_type)

    client.replyMessage(Message(text="⏳ Đang tải video về hệ thống..."), message_object, thread_id, thread_type)

    api_url = f"https://www.tikwm.com/api/search?url={url}"
    temp_video = None

    try:
        res = requests.get(api_url, timeout=30).json()
        if res.get('code') == 0:
            data = res['data']
            video_url = data.get('play') or data.get('wmplay')

            if video_url:
                # Tải video về máy để lấy URL Zalo hoặc gửi trực tiếp
                video_res = requests.get(video_url, timeout=60)
                with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tf:
                    tf.write(video_res.content)
                    temp_video = tf.name

                # Sử dụng sendRemoteVideo nhưng với URL đã được Zalo chấp nhận
                # Hoặc nếu thư viện hỗ trợ, có thể gửi như file.
                # Ở đây chúng ta vẫn dùng sendRemoteVideo vì Zalo Web giới hạn upload video local
                # Nhưng chúng ta sẽ đảm bảo caption và thumb chuẩn

                client.sendRemoteVideo(
                    videoUrl=video_url,
                    thumbnailUrl=data.get('cover'),
                    duration=data.get('duration', 15) * 1000,
                    thread_id=thread_id,
                    thread_type=thread_type,
                    message=Message(text=f"✅ Video của bạn: {data.get('title', 'TikTok')}")
                )
            else:
                client.replyMessage(Message(text="❌ Không thể lấy link video."), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="❌ Link không hỗ trợ."), message_object, thread_id, thread_type)

    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {str(e)}"), message_object, thread_id, thread_type)
    finally:
        if temp_video and os.path.exists(temp_video):
            os.remove(temp_video)

def PTA():
    return {'tikdl': handle_dl_command, 'fbdl': handle_dl_command, 'igdl': handle_dl_command, 'dl': handle_dl_command}
