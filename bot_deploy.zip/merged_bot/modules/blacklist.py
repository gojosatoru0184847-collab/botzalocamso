# -*- coding: utf-8 -*-
import os
import json
import threading
from zlapi.models import Message

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Quản lý danh sách đen các nhóm (Bot không hoạt động, không hút hàng)",
    'power': "Chủ sở hữu Bot"
}

BLACKLIST_FILE = "data/blacklist_groups.json"
_blacklist_lock = threading.Lock()
_blacklist_cache = None

def load_blacklist():
    global _blacklist_cache
    with _blacklist_lock:
        if _blacklist_cache is not None:
            return _blacklist_cache
        try:
            if os.path.exists(BLACKLIST_FILE):
                with open(BLACKLIST_FILE, "r", encoding='utf-8') as f:
                    _blacklist_cache = set(json.load(f))
            else:
                _blacklist_cache = set()
        except:
            _blacklist_cache = set()
        return _blacklist_cache

def save_blacklist(blacklist_set):
    global _blacklist_cache
    with _blacklist_lock:
        _blacklist_cache = blacklist_set
        try:
            os.makedirs("data", exist_ok=True)
            with open(BLACKLIST_FILE, "w", encoding='utf-8') as f:
                json.dump(list(blacklist_set), f, indent=4)
        except: pass

def handle_blacklist_command(message, message_object, thread_id, thread_type, author_id, client):
    if not client.is_super_admin(author_id): return

    parts = message.split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🚦 Cú pháp:\n.blacklist add [ID]\n.blacklist del [ID]\n.blacklist list"), message_object, thread_id, thread_type)
        return

    action = parts[1].lower()
    blacklist = load_blacklist()

    if action == "add":
        target_id = parts[2] if len(parts) > 2 else thread_id
        blacklist.add(str(target_id))
        save_blacklist(blacklist)
        client.replyMessage(Message(text=f"✅ Đã đưa nhóm {target_id} vào danh sách đen! Bot sẽ không hoạt động tại đây."), message_object, thread_id, thread_type)

    elif action == "del":
        target_id = parts[2] if len(parts) > 2 else thread_id
        if str(target_id) in blacklist:
            blacklist.remove(str(target_id))
            save_blacklist(blacklist)
            client.replyMessage(Message(text=f"✅ Đã gỡ nhóm {target_id} khỏi danh sách đen."), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text=f"❌ Nhóm {target_id} không có trong danh sách đen."), message_object, thread_id, thread_type)

    elif action == "list":
        if not blacklist:
            client.replyMessage(Message(text="📜 Danh sách đen đang trống."), message_object, thread_id, thread_type)
        else:
            msg = "📜 [ CÁC NHÓM BỊ CẤM ]\n"
            for gid in blacklist:
                msg += f"• {gid}\n"
            client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'blacklist': handle_blacklist_command}
