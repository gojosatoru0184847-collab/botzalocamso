from zlapi.models import Message
import re

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Test regex pattern", 'power': "Thành viên"}

def handle_regextest_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=2)
    if len(parts) < 3:
        client.replyMessage(Message(text="🔍 Dùng: .regextest <pattern> <text>"), message_object, thread_id, thread_type)
        return
    pattern, text = parts[1], parts[2]
    try:
        matches = re.findall(pattern, text)
        msg = f"🔍 Tìm thấy {len(matches)} kết quả:\n{matches[:20]}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Regex lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'regextest': handle_regextest_command}
