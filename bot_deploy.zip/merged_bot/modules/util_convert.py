from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đổi đơn vị (km/mi, kg/lb, c/f)", 'power': "Thành viên"}

CONVERTERS = {
    "kmtomi": lambda x: x * 0.621371,
    "mitokm": lambda x: x / 0.621371,
    "kgtolb": lambda x: x * 2.20462,
    "lbtokg": lambda x: x / 2.20462,
    "ctof": lambda x: x * 9/5 + 32,
    "ftoc": lambda x: (x - 32) * 5/9,
    "mtoft": lambda x: x * 3.28084,
    "fttom": lambda x: x / 3.28084,
}

def handle_convert_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 3:
        client.replyMessage(Message(text="🔄 Dùng: .convert <loại> <số>\nLoại: kmtomi, mitokm, kgtolb, lbtokg, ctof, ftoc, mtoft, fttom"), message_object, thread_id, thread_type)
        return
    conv_type = parts[1].lower()
    if conv_type not in CONVERTERS:
        client.replyMessage(Message(text="❌ Loại chuyển đổi không hợp lệ."), message_object, thread_id, thread_type)
        return
    try:
        val = float(parts[2])
        result = CONVERTERS[conv_type](val)
        client.replyMessage(Message(text=f"🔄 {val} → {result:.2f}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'convert': handle_convert_command, 'doidonvi': handle_convert_command}
