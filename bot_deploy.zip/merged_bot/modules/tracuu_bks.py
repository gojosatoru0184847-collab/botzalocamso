from zlapi.models import Message
import requests
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tra cứu thông tin biển số xe",'power':"Thành viên"}

TINH = {
    "11":"Cao Bằng","12":"Lạng Sơn","14":"Quảng Ninh","15":"Hải Phòng","16":"Hải Phòng",
    "17":"Thái Bình","18":"Nam Định","19":"Phú Thọ","20":"Thái Nguyên","21":"Yên Bái",
    "22":"Tuyên Quang","23":"Hà Giang","24":"Lào Cai","25":"Lai Châu","26":"Sơn La",
    "27":"Điện Biên","28":"Hòa Bình","29":"Hà Nội","30":"Hà Nội","31":"Hà Nội",
    "32":"Hà Nội","33":"Hà Nội","34":"Hải Dương","35":"Ninh Bình","36":"Thanh Hóa",
    "37":"Nghệ An","38":"Hà Tĩnh","40":"Lâm Đồng","41":"Đồng Nai","43":"Đà Nẵng",
    "47":"Đắk Lắk","48":"Đắk Nông","49":"Lâm Đồng","50":"TP.HCM","51":"TP.HCM",
    "52":"TP.HCM","53":"TP.HCM","54":"TP.HCM","55":"TP.HCM","56":"Bình Dương",
    "57":"Bình Phước","58":"Bình Thuận","59":"TP.HCM","60":"Đồng Nai","61":"Bình Dương",
    "62":"Long An","63":"Tiền Giang","64":"Vĩnh Long","65":"Cần Thơ","66":"Đồng Tháp",
    "67":"An Giang","68":"Kiên Giang","69":"Cà Mau","70":"Tây Ninh","71":"Bến Tre",
    "72":"Bà Rịa-Vũng Tàu","73":"Quảng Bình","74":"Quảng Trị","75":"Thừa Thiên Huế",
    "76":"Quảng Ngãi","77":"Bình Định","78":"Phú Yên","79":"Khánh Hòa","80":"Kon Tum",
    "81":"Gia Lai","82":"Ninh Thuận","83":"Sóc Trăng","84":"Trà Vinh","85":"Hậu Giang",
    "86":"Vĩnh Long","88":"Bình Dương","89":"An Giang","90":"Hưng Yên","92":"Quảng Nam",
    "93":"Bình Phước","95":"Bạc Liêu","97":"Bắc Kạn","98":"Bắc Giang","99":"Bắc Ninh"
}

def handle_tracuu_bks_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text=f"🚗 Dùng: {PREFIX}tracuu_bks <biển số>\nVí dụ: {PREFIX}tracuu_bks 51A-12345"), message_object, thread_id, thread_type); return
    bs = parts[1].upper().replace("-","").replace(".","").replace(" ","")
    so = bs[:2]
    tinh = TINH.get(so, "Không xác định")
    loai = "Ô tô" if bs[2].isalpha() and bs[2] != "R" else "Xe máy"
    msg = (f"🚗 TRA CỨU BIỂN SỐ\n━━━━━━━━━━━━━━━\n"
           f"• Biển số: {parts[1].upper()}\n• Tỉnh/TP: {tinh}\n"
           f"• Phương tiện: {loai}\n• Đầu số: {so}\n"
           f"⚠️ Chỉ mang tính tham khảo")
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'tracuu_bks': handle_tracuu_bks_command}
