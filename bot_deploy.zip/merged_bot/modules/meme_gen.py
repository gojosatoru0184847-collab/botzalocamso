import os
import requests
import tempfile
from PIL import Image
from zlapi.models import Message

des = {
    'version': "1.1.0",
    'credits': "HOANG LAM",
    'description': "Tạo meme & ảnh vui (Gửi ảnh trực tiếp)",
    'power': "Thành viên"
}

def _send_image_from_url(client, url, thread_id, thread_type, caption=""):
    temp_path = None
    try:
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tf:
                tf.write(response.content)
                temp_path = tf.name

            with Image.open(temp_path) as img:
                width, height = img.size

            client.sendLocalImage(
                temp_path,
                thread_id=thread_id,
                thread_type=thread_type,
                width=width,
                height=height,
                message=Message(text=caption)
            )
        return True
    except:
        return False
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)

def _catimage(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://api.thecatapi.com/v1/images/search", timeout=10)
        url = r.json()[0]["url"]
        if not _send_image_from_url(client, url, thread_id, thread_type, "🐱 Mèo méo meo..."):
            client.replyMessage(Message(text="❌ Lỗi khi tải ảnh mèo."), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _dogimage(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://dog.ceo/api/breeds/image/random", timeout=10)
        url = r.json()["message"]
        if not _send_image_from_url(client, url, thread_id, thread_type, "🐶 Gâu gâu!"):
            client.replyMessage(Message(text="❌ Lỗi khi tải ảnh chó."), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _foximage(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://randomfox.ca/floof/", timeout=10)
        url = r.json()["image"]
        _send_image_from_url(client, url, thread_id, thread_type, "🦊 Cáo tuyết!")
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _duckimage(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://random-d.uk/api/random", timeout=10)
        url = r.json()["url"]
        _send_image_from_url(client, url, thread_id, thread_type, "🦆 Quack quack!")
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _waifu(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://api.waifu.pics/sfw/waifu", timeout=10)
        url = r.json()["url"]
        _send_image_from_url(client, url, thread_id, thread_type, "🌸 Waifu!")
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {
        'cat': _catimage, 'meo': _catimage,
        'dog': _dogimage, 'cho': _dogimage,
        'fox': _foximage,
        'duck': _duckimage, 'vit': _duckimage,
        'waifu': _waifu,
    }
