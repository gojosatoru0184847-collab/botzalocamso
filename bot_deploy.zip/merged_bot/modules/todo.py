from zlapi.models import Message
import json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Danh sách công việc cần làm (To-Do)", 'power': "Thành viên"}

TODO_FILE = "modules/cache/data/todo.json"

def _load():
    try:
        with open(TODO_FILE,'r',encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(TODO_FILE), exist_ok=True)
    with open(TODO_FILE,'w',encoding='utf-8') as f: json.dump(d,f,ensure_ascii=False,indent=2)

def _todo_cmd(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=2)
    d = _load(); uid = str(author_id)
    if uid not in d: d[uid] = []

    sub = p[1].lower() if len(p) > 1 else "list"

    if sub == "add" and len(p) > 2:
        d[uid].append({"task": p[2], "done": False})
        _save(d)
        client.replyMessage(Message(text=f"✅ Đã thêm: {p[2]}"), message_object, thread_id, thread_type)

    elif sub == "done" and len(p) > 2:
        try:
            idx = int(p[2]) - 1
            d[uid][idx]["done"] = True
            _save(d)
            client.replyMessage(Message(text=f"✅ Đã đánh dấu hoàn thành #{int(p[2])}"), message_object, thread_id, thread_type)
        except: client.replyMessage(Message(text="❌ Số không hợp lệ"), message_object, thread_id, thread_type)

    elif sub == "del" and len(p) > 2:
        try:
            idx = int(p[2]) - 1
            removed = d[uid].pop(idx)
            _save(d)
            client.replyMessage(Message(text=f"🗑 Đã xóa: {removed['task']}"), message_object, thread_id, thread_type)
        except: client.replyMessage(Message(text="❌ Số không hợp lệ"), message_object, thread_id, thread_type)

    elif sub == "clear":
        d[uid] = []; _save(d)
        client.replyMessage(Message(text="🗑 Đã xóa toàn bộ todo"), message_object, thread_id, thread_type)

    else:  # list
        tasks = d.get(uid, [])
        if not tasks:
            client.replyMessage(Message(text="📋 Danh sách trống. Thêm: .todo add <việc cần làm>"), message_object, thread_id, thread_type); return
        lines = []
        for i,t in enumerate(tasks,1):
            icon = "✅" if t["done"] else "⬜"
            lines.append(f"{icon} {i}. {t['task']}")
        client.replyMessage(Message(text="📋 TODO LIST:\n" + "\n".join(lines)), message_object, thread_id, thread_type)

def PTA():
    return {'todo': _todo_cmd}
