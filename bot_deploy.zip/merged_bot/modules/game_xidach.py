from zlapi.models import Message
import random, json

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chơi xì dách (blackjack đơn giản)", 'power': "Thành viên"}

MONEY_FILE = 'modules/cache/money.json'

def _load_money():
    try:
        with open(MONEY_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save_money(d):
    with open(MONEY_FILE, 'w', encoding='utf-8') as f: json.dump(d, f, indent=4)

def _draw_card():
    return random.randint(1, 11)

def handle_xidach_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🃏 Dùng: .xidach <số tiền cược>"), message_object, thread_id, thread_type)
        return
    try:
        bet = int(parts[1])
    except:
        client.replyMessage(Message(text="❌ Số tiền không hợp lệ"), message_object, thread_id, thread_type)
        return

    money = _load_money()
    uid = str(author_id)
    balance = money.get(uid, 0)
    if bet <= 0 or bet > balance:
        client.replyMessage(Message(text=f"❌ Số dư không đủ. Hiện có: {balance}"), message_object, thread_id, thread_type)
        return

    player = _draw_card() + _draw_card()
    bot_ = _draw_card() + _draw_card()
    player = min(player, 21)
    bot_ = min(bot_, 21)

    if player > bot_:
        money[uid] = balance + bet
        msg = f"🃏 Bạn: {player} | Nhà cái: {bot_}\n✅ THẮNG +{bet}\nSố dư: {money[uid]}"
    elif player < bot_:
        money[uid] = balance - bet
        msg = f"🃏 Bạn: {player} | Nhà cái: {bot_}\n❌ THUA -{bet}\nSố dư: {money[uid]}"
    else:
        msg = f"🃏 Bạn: {player} | Nhà cái: {bot_}\n🤝 HÒA, không mất tiền"

    _save_money(money)
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'xidach': handle_xidach_command, 'blackjack': handle_xidach_command}
