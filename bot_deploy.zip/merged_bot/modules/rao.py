from zlapi.models import Message, ThreadType # Giả định các import cần thiết
import threading
import time
from datetime import datetime, timedelta
import pytz
import os
import json
from pathlib import Path
import logging
import requests
import re
import random # Thêm thư viện random để chọn media ngẫu nhiên

des = {
    'version': "1.3.1", # Cập nhật version
    'credits': "HOANG LAM",
    'description':  "Qc nội dung (Auto Rao)",
    'power': "all"
}

# cấu hình logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='rao.log',
    encoding='utf-8'
)

# cấu hình múi giờ và hằng số
vn_tz = pytz.timezone("Asia/Ho_Chi_Minh")
network_timeout = 10  # timeout cho yêu cầu mạng
message_delay = 0.3   # độ trễ giữa các tin nhắn
max_retries = 3       # số lần thử lại khi tải ảnh/video
monitor_interval = 60 # Khoảng thời gian kiểm tra của rao_monitor (giây)

# trạng thái toàn cục
rao_threads = {}      # {index: Thread}
rao_running = {}      # {index: bool}
disbox_groups = {}    # {username: [thread_id]}
rao_sent_cache = {}   # {index: [{msgId, cliMsgId, threadId}]}

# ==========================
# xử lý file và data
# ==========================

def ensure_data_dir(username: str) -> Path:
    """ĐẢM BẢO THƯ MỤC DỮ LIỆU RIÊNG CỦA BOT TỒN TẠI (rao/{username})."""
    data_dir = Path(f"rao/{username}")
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        return data_dir
    except Exception as e:
        logging.error(f"❌ LỖI KHI TẠO THƯ MỤC DỮ LIỆU CHO {username}: {e}")
        return None

def get_file_paths(username: str) -> dict:
    """TẠO ĐƯỜNG DẪN FILE CHO TỪNG BOT."""
    data_dir = ensure_data_dir(username)
    if not data_dir:
        return None
    return {
        "messages": data_dir,
        "disbox": data_dir / "disbox.json"
    }

def load_rao_messages(username: str) -> list:
    """ĐỌC TẤT CẢ FILE JSON TIN NHẮN VÀ CHUẨN HÓA DỮ LIỆU."""
    file_paths = get_file_paths(username)
    if not file_paths:
        return []
    
    messages = []
    data_dir = file_paths["messages"]
    # Tải các file có tên là số nguyên (trừ disbox.json)
    json_files = sorted(data_dir.glob("*.json"), key=lambda x: int(x.stem) if x.stem.isdigit() else float('inf'))
    
    for file_path in json_files:
        try:
            if file_path.name == "disbox.json":
                continue
            with file_path.open("r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    data = json.loads(content)
                    
                    # Chuẩn hóa dữ liệu (quan trọng cho tự động bật lại)
                    if not data.get("index"): data["index"] = int(file_path.stem)
                    if isinstance(data["created_at"], str):
                        data["created_at"] = datetime.fromisoformat(data["created_at"]).astimezone(vn_tz)
                    data["enabled"] = data.get("enabled", False)
                    data["images"] = data.get("images", [])
                    data["videos"] = data.get("videos", [])
                    data["card"] = data.get("card", {})
                    
                    messages.append(data)
        except Exception as e:
            logging.error(f"LỖI KHI ĐỌC {file_path} CHO {username}: {e}")
    
    return sorted(messages, key=lambda x: int(x.get("index", 0)))

def save_rao_message(username: str, message_data: dict, index: int) -> None:
    """LƯU MỘT TIN NHẮN RAO VÀO FILE JSON."""
    file_paths = get_file_paths(username)
    if not file_paths:
        return
    
    file_path = file_paths["messages"] / f"{index}.json"
    try:
        message_data_copy = message_data.copy()
        # Chuyển datetime về isoformat string
        message_data_copy["created_at"] = message_data_copy["created_at"].isoformat()
        with file_path.open("w", encoding="utf-8") as f:
            json.dump(message_data_copy, f, indent=4, ensure_ascii=False)
    except Exception as e:
        logging.error(f"LỖI KHI LƯU TIN NHẮN RAO {index} CHO {username}: {e}")

def load_disbox(username: str) -> list:
    """TẢI DANH SÁCH NHÓM BỊ CHẶN."""
    file_paths = get_file_paths(username)
    if not file_paths:
        return []
    file_path = file_paths["disbox"]
    try:
        if file_path.exists():
            with file_path.open("r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    return json.loads(content)
        return []
    except Exception as e:
        logging.error(f"LỖI KHI ĐỌC DISBOX.JSON CHO {username}: {e}")
        return []

def save_disbox(username: str, disbox_ids: list) -> None:
    """LƯU DANH SÁCH NHÓM BỊ CHẶN."""
    global disbox_groups
    file_paths = get_file_paths(username)
    if not file_paths:
        return
    file_path = file_paths["disbox"]
    try:
        with file_path.open("w", encoding="utf-8") as f:
            json.dump(disbox_ids, f, indent=4, ensure_ascii=False)
        disbox_groups[username] = disbox_ids # Cập nhật trạng thái bộ nhớ
    except Exception as e:
        logging.error(f"LỖI KHI LƯU DISBOX.JSON CHO {username}: {e}")

def validate_url(url: str) -> bool:
    """KIỂM TRA TÍNH HỢP LỆ CỦA URL bằng cách ping HEAD."""
    if not url.startswith(('http://', 'https://')):
        url = f"https://{url}"
    try:
        response = requests.head(url, timeout=network_timeout, allow_redirects=True)
        return response.status_code == 200
    except Exception:
        return False

def download_file(url: str, file_type: str, username: str) -> str or None:
    """Tải file từ URL và lưu vào thư mục tạm."""
    try:
        paths = get_file_paths(username)
        temp_dir = paths["messages"].parent / "temp" # Đặt trong thư mục temp bên ngoài messages
        temp_dir.mkdir(exist_ok=True)
        
        file_ext = 'jpg' if file_type == 'image' else 'mp4'
        file_name = f"{int(time.time())}_{random.randint(1000, 9999)}.{file_ext}"
        file_path = temp_dir / file_name

        response = requests.get(url, timeout=network_timeout)
        response.raise_for_status()

        with open(file_path, 'wb') as f:
            f.write(response.content)
            
        return str(file_path)
    except Exception as e:
        logging.error(f"Lỗi khi tải file từ URL ({url}): {e}")
        return None

# ==========================
# xử lý thời gian
# ==========================

def parse_time_input(time_str: str) -> int:
    """CHUYỂN ĐỔI THỜI GIAN DẠNG VĂN BẢN THÀNH SỐ PHÚT SO VỚI HIỆN TẠI (Chỉ giữ lại logic số phút)."""
    try:
        # Nếu là số, trả về số phút, tối thiểu 1
        return max(1, int(time_str))
    except ValueError:
        # Logic parse thời gian phức tạp bị loại bỏ để đơn giản hóa, chỉ chấp nhận số phút
        raise ValueError("ĐỊNH DẠNG THỜI GIAN PHẢI LÀ SỐ PHÚT (TỐI THIỂU 1 PHÚT)!")


# ==========================
# vòng lặp rao
# ==========================

def rao_loop(client, index: int, username: str):
    """VÒNG LẶP GỬI TIN NHẮN RAO: GỬI MỘT LẦN CHO TẤT CẢ NHÓM, SAU ĐÓ CHỜ ĐẾN LẦN TIẾP THEO."""
    global rao_running
    logging.info(f"[{index}] RAO THREAD KHỞI ĐỘNG cho {username}")
    
    try:
        while rao_running.get(index, False):
            
            # Tải dữ liệu mới nhất
            rao_data = next((r for r in load_rao_messages(username) if r["index"] == index), None)
            if not rao_data or not rao_data.get("enabled", False):
                logging.warning(f"[{index}] DỮ LIỆU RAO KHÔNG TỒN TẠI HOẶC ĐÃ BỊ TẮT. DỪNG THREAD.")
                break 

            interval = rao_data.get("interval", 120)
            message_text = rao_data.get("message", f"Tin nhắn rao số {index}")
            image_urls = rao_data.get("images", [])
            video_data_list = rao_data.get("videos", [])
            card_data = rao_data.get("card", {})
            
            # Lấy danh sách nhóm
            disbox_ids = disbox_groups.get(username, load_disbox(username))
            allowed_thread_ids = []
            
            try:
                # Giả định client.getThreads() là hàm lấy danh sách nhóm có threadId và threadType
                threads_raw = client.getThreads() # Thay thế bằng API lấy threadlist chuẩn của Zalo
                threads_list = threads_raw.get("threads", []) if threads_raw else []
                # Nếu API khác, cần điều chỉnh ở đây. Tạm dùng client.fetchAllGroups() như logic cũ.
                all_groups = client.fetchAllGroups()
                allowed_thread_ids = list(all_groups.gridVerMap.keys()) if all_groups and hasattr(all_groups, 'gridVerMap') else []
                allowed_thread_ids = [tid for tid in allowed_thread_ids if tid not in disbox_ids]
            except Exception as e:
                logging.error(f"Lỗi khi lấy danh sách nhóm: {e}")
                
            logging.info(f"[{index}] BẮT ĐẦU RAO nội dung '{message_text[:20]}...' tới {len(allowed_thread_ids)} nhóm.")

            # Reset cache cho vòng rao mới
            if index not in rao_sent_cache: rao_sent_cache[index] = []
            # Giới hạn cache tối đa 2000 tin nhắn gần nhất để tránh tràn ram
            if len(rao_sent_cache[index]) > 2000: rao_sent_cache[index] = rao_sent_cache[index][-1000:]

            for thread_id in allowed_thread_ids:
                thread_type = ThreadType.GROUP # Mặc định là Group
                
                def track_sent(res, tid):
                    if res and hasattr(res, 'msgId'):
                        rao_sent_cache[index].append({
                            'msgId': res.msgId,
                            'cliMsgId': res.cliMsgId,
                            'threadId': tid
                        })
                    elif isinstance(res, dict) and 'msgId' in res:
                         rao_sent_cache[index].append({
                            'msgId': res['msgId'],
                            'cliMsgId': res['cliMsgId'],
                            'threadId': tid
                        })

                # 1. Gửi media (ưu tiên Video > Ảnh)
                is_video = False
                
                # Chọn ngẫu nhiên 1 video
                if video_data_list:
                    video_data = random.choice(video_data_list)
                    video_url = video_data.get("normalUrl", "")
                    if validate_url(video_url):
                        try:
                            res = client.sendRemoteVideo(
                                videoUrl=video_url,
                                thumbnailUrl=video_data.get("thumb", video_url),
                                duration=video_data.get("duration", 10000),
                                width=video_data.get("width", 720),
                                height=video_data.get("height", 720),
                                thread_id=thread_id,
                                thread_type=ThreadType.GROUP,
                                ttl=3600000
                            )
                            track_sent(res, thread_id)
                            is_video = True
                        except Exception as e:
                            logging.error(f"LỖI GỬI REMOTE VIDEO {video_url}: {e}")
                    
                # Chọn ngẫu nhiên 1 ảnh nếu không có video
                elif image_urls and not is_video:
                    url = random.choice(image_urls)
                    path = download_file(url, 'image', username)
                    if path:
                        try:
                            res = client.sendMultiLocalImage(
                                [path],
                                thread_id=thread_id,
                                thread_type=ThreadType.GROUP,
                                ttl=3600000
                            )
                            track_sent(res, thread_id)
                        except Exception as e:
                            logging.error(f"LỖI GỬI ẢNH {path}: {e}")
                        finally:
                            try: os.remove(path)
                            except: pass
                
                # 2. Gửi nội dung văn bản
                if message_text:
                    res = client.sendMessage(
                        message=Message(text=message_text),
                        thread_id=thread_id,
                        thread_type=ThreadType.GROUP,
                        ttl=3600000
                    )
                    track_sent(res, thread_id)
                    time.sleep(message_delay)

                # 3. Gửi danh thiếp (card)
                if card_data and card_data.get('uid') and card_data.get('content'):
                    try:
                        res = client.sendBusinessCard(
                            userId=card_data['uid'],
                            qrCodeUrl="",
                            phone=card_data['content'],
                            thread_id=thread_id,
                            thread_type=ThreadType.GROUP,
                            ttl=3600000
                        )
                        track_sent(res, thread_id)
                    except:
                        pass
                
                time.sleep(message_delay)
            
            logging.info(f"[{index}] KẾT THÚC VÒNG RAO. NGỦ {interval} PHÚT.")
            
            # Ngủ cho đến lần chạy tiếp theo
            sleep_time_seconds = interval * 60
            while sleep_time_seconds > 0 and rao_running.get(index, False):
                time.sleep(min(10, sleep_time_seconds))
                sleep_time_seconds -= 10
                
            if not rao_running.get(index, False):
                break # Thoát nếu bị tắt trong khi ngủ

    except Exception as e:
        logging.error(f"[{index}] LỖI NGHIÊM TRỌNG TRONG RAO_LOOP: {e}")
        # Không cần `pass` vì `finally` sẽ xử lý việc thoát
        
    finally:
        # Quan trọng: Đặt trạng thái chạy thành False khi thread kết thúc
        logging.warning(f"[{index}] RAO THREAD KẾT THÚC.")
        rao_running[index] = False
        if index in rao_threads:
            del rao_threads[index]


# ==========================
# giám sát rao (Rao Monitor) - LOGIC TỰ ĐỘNG BẬT LẠI
# ==========================

def rao_monitor(client, username: str):
    """KIỂM TRA ĐỊNH KỲ VÀ KHỞI ĐỘNG LẠI CÁC TÁC VỤ RAO BỊ DỪNG NHƯNG VẪN ĐƯỢC KÍCH HOẠT (ENABLED: TRUE)."""
    while True:
        time.sleep(monitor_interval)
        try:
            rao_list = load_rao_messages(username)
            for rao_data in rao_list:
                index = rao_data["index"]
                
                # Điều kiện TỰ ĐỘNG BẬT LẠI:
                if rao_data.get("enabled", False) and not rao_running.get(index, False):
                    logging.warning(f"PHÁT HIỆN RAO SỐ {index} BỊ TẮT KHÔNG CHỦ ĐỊNH. TIẾN HÀNH TỰ ĐỘNG KHỞI ĐỘNG LẠI.")
                    
                    rao_running[index] = True
                    thread = threading.Thread(
                        target=rao_loop,
                        args=(client, index, username),
                        daemon=True,
                        name=f"raothread-{index}-{username}"
                    )
                    rao_threads[index] = thread
                    thread.start()
                    logging.info(f"✅ ĐÃ TỰ ĐỘNG KHỞI ĐỘNG LẠI RAO SỐ {index}")

        except Exception as e:
            logging.error(f"LỖI TRONG RAO_MONITOR CHO {username}: {e}")

# ==========================
# khởi tạo bot
# ==========================

def startup_rao_checker(client):
    """KHỞI ĐỘNG CÁC TÁC VỤ RAO ĐƯỢC ĐÁNH DẤU 'ENABLED: TRUE' VÀ KHỞI ĐỘNG MONITOR."""
    username = client.me_name if hasattr(client, 'me_name') else "BOT KHÔNG TÊN"
    ensure_data_dir(username)
    load_disbox_groups(username) # Tải danh sách nhóm bị chặn vào bộ nhớ
    rao_list = load_rao_messages(username)

    # 1. Khởi động các tác vụ rao đã lưu
    for rao_data in rao_list:
        index = rao_data["index"]
        if rao_data.get("enabled", False) and not rao_running.get(index, False):
            logging.info(f"KHỞI ĐỘNG LẠI TÁC VỤ RAO SỐ {index} (trạng thái lưu: BẬT)")
            rao_running[index] = True
            thread = threading.Thread(
                target=rao_loop,
                args=(client, index, username),
                daemon=True,
                name=f"raothread-{index}-{username}"
            )
            rao_threads[index] = thread
            thread.start()
            
    # 2. Khởi động thread Giám sát (Monitor)
    monitor_thread = threading.Thread(
        target=rao_monitor,
        args=(client, username),
        daemon=True,
        name=f"raomonitor-{username}"
    )
    monitor_thread.start()
    logging.info(f"✅ ĐÃ KHỞI ĐỘNG RAO MONITOR CHO {username}")

# ==========================
# xử lý lệnh chính (handle_rao_command)
# ==========================

def handle_rao_command(message, message_object, thread_id, thread_type, author_id, client):
    username = client.me_name if hasattr(client, 'me_name') else "BOT KHÔNG TÊN"
    ensure_data_dir(username)

    rao_list = load_rao_messages(username)
    parts = message.strip().split(maxsplit=5)
    
    def find_rao_data(idx):
        return next((r for r in rao_list if r["index"] == idx), None)

    # Nếu chỉ gõ "rao"
    if len(parts) == 1:
        client.replyMessage(
            Message(text="📢 HỆ THỐNG AUTO RAO\nSỬ DỤNG: `rao <nội dung> <thời gian> on/off`\nVÍ DỤ: `rao chào mọi người 120 on`\nNHẬP `rao help` ĐỂ XEM CHI TIẾT!"),
            message_object, thread_id, thread_type, ttl=120000
        )
        return

    # lệnh help
    if len(parts) == 2 and parts[1].lower() == "help":
        help_text = (
            "📋 HỆ THỐNG AUTO RAO 🤖\n"
            "LƯU Ý: INDEX là số thứ tự.\n\n"
            "CÚ PHÁP CƠ BẢN: `rao <nội dung> <thời gian> on/off`\n"
            "ví dụ: `rao chào mọi người 120 on` (rao 120 phút 1 lần)\n\n"
            "🔧 QUẢN LÝ NỘI DUNG:\n"
            "  - `rao set <index> <nội dung>`: cập nhật nội dung rao\n"
            "  - `rao time <index> <phút>`: chỉnh thời gian lặp\n"
            "📷 QUẢN LÝ ẢNH:\n"
            "  - `rao image add <index>` + đính kèm hoặc nhập link\n"
            "  - `rao image remove <index> <số>` / `rao image clear <index>`\n"
            "🎥 QUẢN LÝ VIDEO:\n"
            "  - `rao video add <index>` + đính kèm hoặc nhập link\n"
            "  - `rao video remove <index> <số>` / `rao video clear <index>`\n"
            "📇 DANH THIẾP:\n"
            "  - `rao card <index> <uid> <nội dung>` / `rao card clear <index>`\n"
            "🚫 CHẶN NHÓM:\n"
            "  - `rao disbox`: chặn nhóm này\n"
            "  - `rao undisbox`: bỏ chặn nhóm này\n"
            "📊 KHÁC:\n"
            "  - `rao list`, `rao info <index>`, `rao on/off <index>`, `rao del <index>`, `rao check`, `rao undo <index>`"
        )
        client.replyMessage(Message(text=help_text), message_object, thread_id, thread_type, ttl=120000)
        return

    # LỆNH MỚI: rao undo <index>
    if len(parts) == 3 and parts[1].lower() == "undo":
        try:
            index = int(parts[2])
            if index not in rao_sent_cache or not rao_sent_cache[index]:
                client.replyMessage(Message(text=f"⚠️ KHÔNG TÌM THẤY LỊCH SỬ TIN NHẮN GẦN NHẤT CỦA RAO SỐ {index} ĐỂ THU HỒI."), message_object, thread_id, thread_type, ttl=120000)
                return

            sent_msgs = rao_sent_cache[index]
            client.replyMessage(Message(text=f"⏳ ĐANG THU HỒI {len(sent_msgs)} TIN NHẮN CỦA RAO SỐ {index}..."), message_object, thread_id, thread_type, ttl=120000)

            success_undo = 0
            for msg in sent_msgs:
                try:
                    # ownerId là UID của bot
                    client.deleteGroupMsg(msg['msgId'], client.uid, msg['cliMsgId'], msg['threadId'])
                    success_undo += 1
                    time.sleep(0.1)
                except:
                    pass

            # Xóa cache sau khi undo
            rao_sent_cache[index] = []
            client.replyMessage(Message(text=f"✅ ĐÃ THU HỒI THÀNH CÔNG {success_undo}/{len(sent_msgs)} TIN NHẮN."), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
             client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return
        
    # LỆNH MỚI: rao check
    if len(parts) == 2 and parts[1].lower() == "check":
        if not rao_list:
            client.replyMessage(
                Message(text="📪 DANH SÁCH NỘI DUNG RAO TRỐNG. KHÔNG CÓ GÌ ĐỂ KIỂM TRA."),
                message_object, thread_id, thread_type, ttl=120000
            )
            return

        check_text = "🔎 KIỂM TRA TRẠNG THÁI RAO\n\n"
        
        for rao in rao_list:
            index = rao["index"]
            is_enabled = rao.get("enabled", False)
            is_running = rao_running.get(index, False)
            
            status_text = ""
            if is_enabled and is_running:
                status_text = "✅ ĐANG CHẠY"
            elif is_enabled and not is_running:
                status_text = f"⚠️ LỖI/ĐÃ DỪNG (SẼ TỰ BẬT LẠI SAU {monitor_interval} GIÂY)"
            elif not is_enabled and not is_running:
                status_text = "❌ ĐANG TẮT (OFF)"
            elif not is_enabled and is_running:
                status_text = "❓ LỆNH TẮT ĐÃ GỬI (SẮP DỪNG)"

            check_text += (
                f"[{index}] {status_text}\n"
                f"   - Enabled (Lưu): {'BẬT' if is_enabled else 'TẮT'}\n"
                f"   - Running (Bộ nhớ): {'CHẠY' if is_running else 'DỪNG'}\n"
                f"   - Nội dung: {rao['message'][:30]}...\n\n"
            )
            
        client.replyMessage(
            Message(text=check_text),
            message_object, thread_id, thread_type, ttl=120000
        )
        return

    # xử lý disbox
    if len(parts) == 2 and parts[1].lower() == "disbox":
        disbox_ids = load_disbox(username)
        if thread_id not in disbox_ids:
            disbox_ids.append(thread_id)
            save_disbox(username, disbox_ids)
            client.replyMessage(Message(text="🚫 ĐÃ THÊM NHÓM VÀO DANH SÁCH CHẶN!"), message_object, thread_id, thread_type, ttl=120000)
        else:
            client.replyMessage(Message(text="⚠️ NHÓM NÀY ĐÃ TRONG DANH SÁCH CHẶN!"), message_object, thread_id, thread_type, ttl=120000)
        return

    if len(parts) == 2 and parts[1].lower() == "undisbox":
        disbox_ids = load_disbox(username)
        if thread_id in disbox_ids:
            disbox_ids.remove(thread_id)
            save_disbox(username, disbox_ids)
            client.replyMessage(Message(text="✅ ĐÃ GỠ NHÓM KHỎI DANH SÁCH CHẶN!"), message_object, thread_id, thread_type, ttl=120000)
        else:
            client.replyMessage(Message(text="⚠️ NHÓM KHÔNG TRONG DANH SÁCH CHẶN!"), message_object, thread_id, thread_type, ttl=120000)
        return
    
    # ... (Các lệnh image/video add/remove/clear, card, info, list, set, time)
    # Lưu ý: Các lệnh này phải kết thúc bằng `return` sau khi xử lý.

    # 🖼️ IMAGE ADD
    if len(parts) >= 4 and parts[1].lower() == "image" and parts[2].lower() == "add":
        try:
            index = int(parts[3])
            rao_data = find_rao_data(index)
            if not rao_data:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
                return

            images = rao_data.get("images", [])
            attachments = getattr(message_object, "attachments", None)
            added_links = []

            if attachments:
                for att in attachments:
                    if isinstance(att, dict) and att.get("type") == "image" and att.get("url"):
                        img_url = att["url"]
                        if img_url not in images:
                            images.append(img_url)
                            added_links.append(img_url)

            if not added_links and len(parts) >= 5:
                img_link = parts[4].strip()
                if not img_link.startswith(("http://", "https://")):
                    img_link = f"https://{img_link}"
                if validate_url(img_link) and img_link not in images:
                    images.append(img_link)
                    added_links.append(img_link)

            if added_links:
                rao_data["images"] = images
                rao_data["created_at"] = datetime.now(vn_tz)
                save_rao_message(username, rao_data, index)
                reply_text = f"✅ ĐÃ THÊM {len(added_links)} ẢNH VÀO SỐ {index}:\n" + "\n".join(added_links)
            else:
                reply_text = "⚠️ KHÔNG PHÁT HIỆN ẢNH HỢP LỆ!"
            client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # 🎥 VIDEO ADD
    if len(parts) >= 4 and parts[1].lower() == "video" and parts[2].lower() == "add":
        try:
            index = int(parts[3])
            rao_data = find_rao_data(index)
            if not rao_data:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
                return

            videos = rao_data.get("videos", [])
            video_list_added = []
            attachments = getattr(message_object, "attachments", None)

            if attachments:
                for att in attachments:
                    if isinstance(att, dict) and att.get("type") == "video" and att.get("url"):
                        vurl = att["url"]
                        if not vurl.startswith(("http://", "https://")):
                            vurl = f"https://{vurl}"
                        if vurl not in [v.get("normalUrl") for v in videos]:
                            videos.append({
                                "normalUrl": vurl,
                                "thumb": att.get("thumbnailUrl", vurl),
                                "duration": 10000,
                                "width": 720,
                                "height": 720
                            })
                            video_list_added.append(vurl)

            if not video_list_added and len(parts) >= 5:
                vlink = parts[4].strip()
                if not vlink.startswith(("http://", "https://")):
                    vlink = f"https://{vlink}"
                if validate_url(vlink) and vlink not in [v.get("normalUrl") for v in videos]:
                    videos.append({
                        "normalUrl": vlink,
                        "thumb": vlink,
                        "duration": 10000,
                        "width": 720,
                        "height": 720
                    })
                    video_list_added.append(vlink)

            if video_list_added:
                rao_data["videos"] = videos
                rao_data["created_at"] = datetime.now(vn_tz)
                save_rao_message(username, rao_data, index)
                reply_text = f"✅ ĐÃ THÊM {len(video_list_added)} VIDEO VÀO SỐ {index}:\n" + "\n".join(video_list_added)
            else:
                reply_text = "⚠️ KHÔNG PHÁT HIỆN VIDEO HỢP LỆ!"
            client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao image/video/card remove/clear
    if len(parts) >= 3 and parts[1].lower() in ["image", "video", "card"]:
        media_type = parts[1].lower()
        action = parts[2].lower()
        
        # Xử lý CLEAR
        if action == "clear" and len(parts) == 4:
            try:
                index = int(parts[3])
                rao_data = find_rao_data(index)
                if rao_data:
                    rao_data[f"{media_type}s" if media_type != "card" else media_type] = {} if media_type == "card" else []
                    rao_data["created_at"] = datetime.now(vn_tz)
                    save_rao_message(username, rao_data, index)
                    reply_text = f"✅ ĐÃ XÓA TẤT CẢ {media_type.upper()} KHỎI SỐ {index}!"
                    client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
                else:
                    client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
            except ValueError:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Xử lý REMOVE
        if action == "remove" and len(parts) == 5 and media_type != "card":
            try:
                index = int(parts[3])
                item_index = int(parts[4]) - 1
                rao_data = find_rao_data(index)
                if rao_data:
                    items = rao_data.get(f"{media_type}s", [])
                    if 0 <= item_index < len(items):
                        removed_item = items.pop(item_index)
                        rao_data[f"{media_type}s"] = items
                        rao_data["created_at"] = datetime.now(vn_tz)
                        save_rao_message(username, rao_data, index)
                        url_or_info = removed_item.get('normalUrl', removed_item) if isinstance(removed_item, dict) else removed_item
                        reply_text = f"✅ ĐÃ XÓA {media_type.upper()} SỐ {item_index + 1} KHỎI SỐ {index}: {url_or_info}"
                    else:
                        reply_text = f"⚠️ CHỈ SỐ {media_type.upper()} KHÔNG HỢP LỆ!"
                    client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
                else:
                    client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
            except ValueError:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ VÀ CHỈ SỐ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
            return
            
    # lệnh rao card <index> <uid> <nội dung>
    if len(parts) >= 5 and parts[1].lower() == "card" and parts[2].isdigit():
        try:
            index = int(parts[2])
            uid = parts[3].strip()
            content = " ".join(parts[4:]).strip()
            rao_data = find_rao_data(index)
            if rao_data:
                if not uid.isdigit():
                    reply_text = "⚠️ UID PHẢI LÀ SỐ HỢP LỆ!"
                elif not content:
                    reply_text = "⚠️ NỘI DUNG DANH THIẾP KHÔNG ĐƯỢC ĐỂ TRỐNG!"
                else:
                    rao_data["card"] = {
                        "status": "SAVED",
                        "uid": uid,
                        "content": content
                    }
                    rao_data["created_at"] = datetime.now(vn_tz)
                    save_rao_message(username, rao_data, index)
                    reply_text = f"✅ ĐÃ LƯU DANH THIẾP SỐ {index}:\nUID: {uid}\nNỘI DUNG: {content}"
                client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao info <index>
    if len(parts) == 3 and parts[1].lower() == "info":
        try:
            index = int(parts[2])
            rao_data = find_rao_data(index)
            if rao_data:
                status = "BẬT" if rao_running.get(index, False) else "TẮT"
                enabled_status = "BẬT (Lưu)" if rao_data.get("enabled", False) else "TẮT (Lưu)"
                images = rao_data.get("images", [])
                videos = rao_data.get("videos", [])
                card = rao_data.get("card", {})
                info_text = (
                    f"📋 CHI TIẾT NỘI DUNG RAO SỐ {index}\n\n"
                    f"NỘI DUNG: {rao_data['message'] or 'không có'}\n"
                    f"THỜI GIAN: {rao_data['interval']} phút\n"
                    f"TRẠNG THÁI HIỆN TẠI: {status}\n"
                    f"TRẠNG THÁI MONG MUỐN: {enabled_status}\n"
                    f"ẢNH: {len(images)} ảnh\n" + 
                    (f"  - " + "\n  - ".join(images) + "\n" if images else "") +
                    f"VIDEO: {len(videos)} video\n" +
                    (f"  - " + "\n  - ".join(v['normalUrl'] for v in videos) + "\n" if videos else "") +
                    f"DANH THIẾP: {card.get('status', 'chưa thiết lập')}\n" +
                    (f"  UID: {card.get('uid', 'chưa thiết lập')}\n  NỘI DUNG: {card.get('content', 'chưa thiết lập')}\n" if card.get('uid') else "") +
                    f"TẠO LÚC: {rao_data['created_at'].strftime('%Y-%m-%d %H:%M:%S')}\n"
                )
                client.replyMessage(Message(text=info_text), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao list
    if len(parts) == 2 and parts[1].lower() == "list":
        if not rao_list:
            client.replyMessage(Message(text="📪 DANH SÁCH NỘI DUNG RAO TRỐNG!"), message_object, thread_id, thread_type, ttl=120000)
            return

        list_text = f"📜 DANH SÁCH NỘI DUNG RAO ({len(rao_list)})\n\n"
        for rao in rao_list:
            index = rao["index"]
            status = "BẬT" if rao_running.get(index, False) else "TẮT"
            enabled_status = "BẬT (Lưu)" if rao.get("enabled", False) else "TẮT (Lưu)"
            images = rao.get("images", [])
            videos = rao.get("videos", [])
            card = rao.get("card", {})
            list_text += (
                f"{index}. NỘI DUNG: {rao['message'][:50] or 'không có'}...\n"
                f"   THỜI GIAN: {rao['interval']} phút\n"
                f"   TRẠNG THÁI: {status} / {enabled_status}\n"
                f"   MEDIA: {len(images)} ảnh | {len(videos)} video\n"
                f"   CARD: {card.get('uid', 'không')}\n"
                f"   TẠO LÚC: {rao['created_at'].strftime('%H:%M:%S %d/%m')}\n\n"
            )
        
        client.replyMessage(Message(text=list_text), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao del <index> (Thêm lệnh xóa)
    if len(parts) == 3 and parts[1].lower() == "del":
        try:
            index = int(parts[2])
            rao_data = find_rao_data(index)
            if rao_data:
                # Dừng thread nếu đang chạy
                if rao_running.get(index, False):
                    rao_running[index] = False
                
                # Xóa file
                file_paths = get_file_paths(username)
                file_path = file_paths["messages"] / f"{index}.json"
                if file_path.exists():
                    os.remove(file_path)
                
                client.replyMessage(Message(text=f"✅ ĐÃ XÓA TÁC VỤ RAO SỐ {index}"), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return
        
    # lệnh rao off <index>
    if len(parts) == 3 and parts[1].lower() == "off":
        try:
            index = int(parts[2])
            rao_data = find_rao_data(index)
            if rao_data:
                rao_data["enabled"] = False # Cập nhật trạng thái lưu trữ
                save_rao_message(username, rao_data, index)
                
                if rao_running.get(index, False):
                    rao_running[index] = False
                    client.replyMessage(Message(text=f"✅ ĐÃ GỬI LỆNH TẮT RAO SỐ {index}. THREAD SẼ DỪNG TRONG GIÂY LÁT."), message_object, thread_id, thread_type, ttl=120000)
                else:
                    client.replyMessage(Message(text=f"📢 RAO SỐ {index} ĐANG TẮT. ĐÃ CẬP NHẬT TRẠNG THÁI LƯU (ENABLED=FALSE)."), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao on <index>
    if len(parts) == 3 and parts[1].lower() == "on":
        try:
            index = int(parts[2])
            rao_data = find_rao_data(index)
            if rao_data:
                rao_data["enabled"] = True # Cập nhật trạng thái lưu trữ
                save_rao_message(username, rao_data, index)
                
                if rao_running.get(index, False):
                    reply_text = f"⚠️ RAO SỐ {index} ĐÃ ĐƯỢC BẬT RỒI!"
                else:
                    rao_running[index] = True
                    thread = threading.Thread(
                        target=rao_loop,
                        args=(client, index, username),
                        daemon=True,
                        name=f"raothread-{index}-{username}"
                    )
                    rao_threads[index] = thread
                    thread.start()
                    reply_text = f"✅ ĐÃ BẬT RAO SỐ {index}."
                client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao time <index> <thời gian>
    if len(parts) == 4 and parts[1].lower() == "time":
        try:
            index = int(parts[2])
            new_interval = parse_time_input(parts[3])
            rao_data = find_rao_data(index)
            if rao_data:
                rao_data["interval"] = new_interval
                save_rao_message(username, rao_data, index)
                reply_text = f"✅ ĐÃ ĐẶT THỜI GIAN RAO SỐ {index} THÀNH {new_interval} PHÚT."
            else:
                reply_text = "⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"
            client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
        except ValueError as e:
            client.replyMessage(Message(text=f"⚠️ LỖI: {str(e)}"), message_object, thread_id, thread_type, ttl=120000)
        return

    # lệnh rao set <index> <nội dung mới>
    if len(parts) >= 4 and parts[1].lower() == "set":
        try:
            index = int(parts[2])
            rao_data = find_rao_data(index)
            if rao_data:
                new_message = " ".join(parts[3:])
                if not new_message:
                    reply_text = "⚠️ VUI LÒNG NHẬP NỘI DUNG MỚI!"
                else:
                    rao_data["message"] = new_message
                    rao_data["created_at"] = datetime.now(vn_tz)
                    save_rao_message(username, rao_data, index)
                    reply_text = f"✅ ĐÃ CẬP NHẬT NỘI DUNG RAO SỐ {index}: {new_message}"
            else:
                reply_text = "⚠️ SỐ THỨ TỰ KHÔNG HỢP LỆ!"
            client.replyMessage(Message(text=reply_text), message_object, thread_id, thread_type, ttl=120000)
        except ValueError:
            client.replyMessage(Message(text="⚠️ SỐ THỨ TỰ PHẢI LÀ SỐ NGUYÊN!"), message_object, thread_id, thread_type, ttl=120000)
        return

    # -------------------------------------------------------------
    # LỆNH TẠO RAO MỚI: rao <nội dung> <thời gian> <on/off>
    # -------------------------------------------------------------
    is_create_command = False
    try:
        # Kiểm tra tối thiểu 4 phần tử (rao + nội dung + thời gian + on/off)
        if len(parts) >= 4 and parts[-1].lower() in ["on", "off"]:
            enabled = parts[-1].lower() == "on"
            interval = parse_time_input(parts[-2])
            message_text = " ".join(parts[1:-2])
            
            if not message_text:
                raise ValueError("NỘI DUNG RAO KHÔNG ĐƯỢC ĐỂ TRỐNG.")
            
            is_create_command = True

    except ValueError as e:
        # Lỗi cú pháp trong phần tạo rao, rơi xuống lỗi mặc định
        pass 
    except Exception as e:
        # Lỗi nghiêm trọng: trả lời và return
        client.replyMessage(
            Message(text=f"❌ LỖI TRONG QUÁ TRÌNH TẠO RAO MỚI: {e}"),
            message_object, thread_id, thread_type, ttl=120000
        )
        return

    # Xử lý tạo rao mới nếu thỏa mãn điều kiện
    if is_create_command:
        # tìm số thứ tự lớn nhất
        file_paths = get_file_paths(username)
        json_files = sorted(file_paths["messages"].glob("*.json"), key=lambda x: int(x.stem) if x.stem.isdigit() else float('inf'))
        next_index = max([int(f.stem) for f in json_files if f.stem.isdigit()] + [0]) + 1

        # thêm tin nhắn vào danh sách
        message_data = {
            "index": next_index,
            "message": message_text,
            "interval": interval,
            "enabled": enabled,
            "created_at": datetime.now(vn_tz),
            "images": [],
            "videos": [],
            "card": {}
        }
        save_rao_message(username, message_data, next_index)

        # bật rao mới nếu được yêu cầu
        if enabled:
            rao_running[next_index] = True
            thread = threading.Thread(
                target=rao_loop,
                args=(client, next_index, username),
                daemon=True,
                name=f"raothread-{next_index}-{username}"
            )
            rao_threads[next_index] = thread
            thread.start()

        status_text = "✅ ĐÃ BẬT TỰ ĐỘNG RAO" if enabled else "✅ ĐÃ LƯU"
        reply_text = (
            f"{status_text}\n"
            f"SỐ THỨ TỰ: {next_index}\n"
            f"THỜI GIAN: {interval} PHÚT\n"
            f"NỘI DUNG: {message_text}"
        )
        client.replyMessage(
            Message(text=reply_text),
            message_object, thread_id, thread_type, ttl=120000
        )
        return # QUAN TRỌNG: Kết thúc hàm sau khi xử lý thành công
    
    # -------------------------------------------------------------
    # PHẦN XỬ LÝ LỖI MẶC ĐỊNH (Chỉ chạy khi không khớp bất kỳ lệnh nào)
    # -------------------------------------------------------------
    client.replyMessage(
        Message(text="❌ LỆNH KHÔNG HỢP LỆ. VUI LÒNG KIỂM TRA LẠI CÚ PHÁP HOẶC GÕ `rao help`."),
        message_object, thread_id, thread_type, ttl=120000
    )


def PTA():
    """Hàm Khởi Tạo Plugin."""
    return {
        'rao': handle_rao_command,
            }
