from zlapi.models import Message
import json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tạo bình chọn (poll) trong nhóm", 'power': "Thành viên"}

POLL_FILE = "modules/cache/data/polls.json"

def _load():
    try:
        with open(POLL_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(POLL_FILE), exist_ok=True)
    with open(POLL_FILE, 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)

def handle_poll_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    polls = _load()
    tid = str(thread_id)

    if len(parts) < 2:
        client.replyMessage(Message(text="📊 Dùng: .poll <câu hỏi>|<lựa chọn 1>|<lựa chọn 2>|...\nHoặc: .poll vote <số> để bình chọn\nHoặc: .poll result để xem kết quả"), message_object, thread_id, thread_type)
        return

    arg = parts[1].strip()
    if arg.lower() == "result":
        if tid not in polls:
            client.replyMessage(Message(text="❌ Chưa có poll nào."), message_object, thread_id, thread_type)
            return
        poll = polls[tid]
        lines = [f"📊 {poll['question']}"]
        for i, opt in enumerate(poll['options'], 1):
            votes = sum(1 for v in poll['votes'].values() if v == i)
            lines.append(f"{i}. {opt}: {votes} vote")
        client.replyMessage(Message(text="\n".join(lines)), message_object, thread_id, thread_type)
        return

    if arg.lower().startswith("vote"):
        vparts = arg.split()
        if len(vparts) < 2 or tid not in polls:
            client.replyMessage(Message(text="❌ Chưa có poll hoặc thiếu số lựa chọn."), message_object, thread_id, thread_type)
            return
        try:
            choice = int(vparts[1])
            polls[tid]['votes'][str(author_id)] = choice
            _save(polls)
            client.replyMessage(Message(text=f"✅ Đã bình chọn lựa chọn {choice}"), message_object, thread_id, thread_type)
        except Exception as e:
            client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)
        return

    if "|" not in arg:
        client.replyMessage(Message(text="❌ Cần dùng dấu | để phân tách câu hỏi và lựa chọn."), message_object, thread_id, thread_type)
        return

    pieces = [p.strip() for p in arg.split("|")]
    question, options = pieces[0], pieces[1:]
    if len(options) < 2:
        client.replyMessage(Message(text="❌ Cần ít nhất 2 lựa chọn."), message_object, thread_id, thread_type)
        return

    polls[tid] = {"question": question, "options": options, "votes": {}}
    _save(polls)
    lines = [f"📊 {question}"] + [f"{i}. {o}" for i, o in enumerate(options, 1)]
    lines.append("\nGõ .poll vote <số> để bình chọn")
    client.replyMessage(Message(text="\n".join(lines)), message_object, thread_id, thread_type)

def PTA():
    return {'poll': handle_poll_command, 'binhchon': handle_poll_command}
