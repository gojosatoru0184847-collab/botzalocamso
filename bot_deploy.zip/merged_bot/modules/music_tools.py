import requests
from zlapi.models import Message

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Công cụ âm nhạc: Lyric, BPM, Chords",
    'power': "Thành viên"
}

def h_lyric(m, mo, tid, tt, aid, client):
    parts = m.split(maxsplit=1)
    if len(parts) < 2: return client.send(Message(text="❓ Dùng: .lyric <tên bài hát>"), tid, tt)
    name = parts[1]
    url = f"https://api.lyrics.ovh/v1/unknown/{name}" # API public lyrics
    try:
        res = requests.get(url, timeout=10).json()
        client.send(Message(text=f"🎶 LỜI BÀI HÁT: {name}\n\n{res.get('lyrics', 'Không tìm thấy lời.')[:2000]}"), tid, tt)
    except: client.send(Message(text="❌ Lỗi khi tìm lời."), tid, tt)

def h_bpm(m, mo, tid, tt, aid, client):
    client.send(Message(text="🥁 Công cụ đo BPM: Vỗ tay 4 lần theo nhịp rồi chia cho thời gian để tính... (Tính năng đang nâng cấp)"), tid, tt)

def PTA():
    return {
        'lyric': h_lyric,
        'bpmcount': h_bpm,
        'nhancuoin': h_lyric,
        'chord': h_lyric
    }
