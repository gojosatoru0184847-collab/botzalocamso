from zlapi.models import Message
import random, json, os, time

des = {
    'version': "1.0.0", 'credits': "UltraBot", 'description': "Đoán số từ 1-100",
    'power': "Thành viên"
}

GAME_FILE = "modules/cache/data/doanso_game.json"

def _load():
    try:
        with open(GAME_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

def handle_doanso_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    games = _load()
    tid = str(thread_id)

    if len(parts) < 2:
        client.replyMessage(Message(text="🎯 Dùng: .doanso start (bắt đầu)\n.doanso <số> (đoán)"), message_object, thread_id, thread_type)
        return

    if parts[1].lower() == "start":
        secret = random.randint(1, 100)
        games[tid] = {"secret": secret, "tries": 0, "start": time.time()}
        _save(games)
        client.replyMessage(Message(text="🎯 Đã bắt đầu game đoán số từ 1-100!\nGõ .doanso <số> để đoán."), message_object, thread_id, thread_type)
        return

    if tid not in games:
        client.replyMessage(Message(text="❌ Chưa có game nào. Gõ .doanso start trước."), message_object, thread_id, thread_type)
        return

    try:
        guess = int(parts[1])
    except:
        client.replyMessage(Message(text="❌ Vui lòng nhập số hợp lệ."), message_object, thread_id, thread_type)
        return

    games[tid]["tries"] += 1
    secret = games[tid]["secret"]

    if guess == secret:
        tries = games[tid]["tries"]
        elapsed = round(time.time() - games[tid]["start"], 1)
        del games[tid]
        _save(games)
        client.replyMessage(Message(text=f"🎉 Chính xác! Số là {secret}\nBạn đoán đúng sau {tries} lần ({elapsed}s)"), message_object, thread_id, thread_type)
    elif guess < secret:
        _save(games)
        client.replyMessage(Message(text="📈 Số cần đoán LỚN HƠN"), message_object, thread_id, thread_type)
    else:
        _save(games)
        client.replyMessage(Message(text="📉 Số cần đoán NHỎ HƠN"), message_object, thread_id, thread_type)

def PTA():
    return {'doanso': handle_doanso_command, 'guessnum': handle_doanso_command}
