from zlapi.models import Message
import requests
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tra Wikipedia tiếng Việt",'power':"Thành viên"}

def handle_wikivn_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text=f"📚 Dùng: {PREFIX}wikivn <từ khóa>"), message_object, thread_id, thread_type); return
    query = parts[1]
    try:
        r = requests.get(
            "https://vi.wikipedia.org/api/rest_v1/page/summary/" + requests.utils.quote(query, timeout=15),
            timeout=10
        )
        data = r.json()
        if data.get("type") == "disambiguation":
            raise ValueError("Từ khóa không rõ ràng")
        title = data.get("title","")
        extract = data.get("extract","")[:600]
        url = data.get("content_urls",{}).get("desktop",{}).get("page","")
        msg = f"📚 {title}\n━━━━━━━━━━━━━━━\n{extract}\n\n🔗 {url}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy: {query}"), message_object, thread_id, thread_type)

def PTA():
    return {'wikivn': handle_wikivn_command}
