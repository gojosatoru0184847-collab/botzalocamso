from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tra cứu thông tin phim", 'power': "Thành viên"}

def _movie(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="🎬 Dùng: .movie <tên phim>\nVí dụ: .movie Avengers"), message_object, thread_id, thread_type); return
    title = p[1].strip()
    try:
        r = requests.get(
            f"http://www.omdbapi.com/?t={requests.utils.quote(title)}&apikey=trilogy",
            timeout=10)
        d = r.json()
        if d.get("Response") == "False":
            raise ValueError(d.get("Error", "Không tìm thấy"))
        msg = (f"🎬 {d.get('Title')} ({d.get('Year')})\n━━━━━━━━━━━━━━\n"
               f"• Điểm IMDb: {d.get('imdbRating')}/10 ({d.get('imdbVotes')} votes)\n"
               f"• Thể loại: {d.get('Genre')}\n"
               f"• Đạo diễn: {d.get('Director')}\n"
               f"• Diễn viên: {d.get('Actors')}\n"
               f"• Thời gian: {d.get('Runtime')}\n"
               f"• Ngôn ngữ: {d.get('Language')}\n"
               f"• Tóm tắt: {(d.get('Plot',''))[:200]}")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm được phim: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'movie': _movie, 'phim': _movie}
