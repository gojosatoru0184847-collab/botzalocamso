from zlapi.models import Message
from datetime import datetime

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tính tuổi từ ngày sinh", 'power': "Thành viên"}

def handle_tinhtuoi_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🎂 Dùng: .tinhtuoi dd/mm/yyyy"), message_object, thread_id, thread_type)
        return
    try:
        birth = datetime.strptime(parts[1], "%d/%m/%Y")
        today = datetime.now()
        age = today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))
        days_lived = (today - birth).days
        next_bday = birth.replace(year=today.year)
        if next_bday < today:
            next_bday = next_bday.replace(year=today.year + 1)
        days_to_bday = (next_bday - today).days
        msg = (
            f"🎂 THÔNG TIN TUỔI\n━━━━━━━━━━━━━━━\n"
            f"• Ngày sinh: {parts[1]}\n"
            f"• Tuổi hiện tại: {age}\n"
            f"• Đã sống: {days_lived:,} ngày\n"
            f"• Còn {days_to_bday} ngày tới sinh nhật"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Sai định dạng ngày (dd/mm/yyyy): {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'tinhtuoi': handle_tinhtuoi_command}
