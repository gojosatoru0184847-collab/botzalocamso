from zlapi.models import Message
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tính lương thực nhận sau thuế TNCN",'power':"Thành viên"}

def tinh_thue(gross):
    giam_tru_bn = 11_000_000; giam_tru_pt = 4_400_000
    net = gross - giam_tru_bn
    bhxh = gross * 0.105
    net_taxable = max(0, net - bhxh)
    brackets = [(60e6,0.05),(60e6,0.10),(86.4e6,0.15),(162e6,0.20),(252e6,0.25),(540e6,0.30),(float('inf'),0.35)]
    tax = 0; remaining = net_taxable
    for limit, rate in brackets:
        if remaining <= 0: break
        taxable = min(remaining, limit)
        tax += taxable * rate
        remaining -= taxable
    take_home = gross - bhxh - gross*0.015 - gross*0.01 - tax
    return bhxh, tax, take_home

def handle_tinhluong_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text=f"💰 Dùng: {PREFIX}tinhluong <lương gross (triệu)>\nVí dụ: {PREFIX}tinhluong 20"), message_object, thread_id, thread_type); return
    try:
        gross = float(parts[1]) * 1_000_000
        bhxh, tax, take_home = tinh_luong = tinh_thue(gross)
        msg = (f"💰 TÍNH LƯƠNG THỰC NHẬN\n━━━━━━━━━━━━━━━\n"
               f"• Lương Gross: {gross/1e6:.1f} triệu\n"
               f"• BHXH-YT-TN (10.5%): -{bhxh/1e6:.2f} triệu\n"
               f"• Thuế TNCN: -{tax/1e6:.2f} triệu\n"
               f"━━━━━━━━━━━━━━━\n"
               f"• Lương Net: {take_home/1e6:.2f} triệu\n"
               f"⚠️ Chưa tính giảm trừ người phụ thuộc")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập số hợp lệ"), message_object, thread_id, thread_type)

def PTA():
    return {'tinhluong': handle_tinhluong_command}
