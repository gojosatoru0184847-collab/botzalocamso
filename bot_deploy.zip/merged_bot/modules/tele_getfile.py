# -*- coding: utf-8 -*-
import os, json, asyncio, threading, time, re, queue, random, logging
from telethon import TelegramClient, events, functions, types
from core.collect_utils import (
    global_hunted_cache, save_hunted_cache, cache_lock,
    STRICT_HOST_WHITELIST, DOMAIN_BLACKLIST, MOD_KEYWORDS, STRICT_EXT_WHITELIST
)

_tele_client = None
_tele_thread_running = False
TELE_TARGET_CHANNEL = "SHOPLIMINAL"

# Hàng đợi để xử lý yêu cầu từ Zalo gửi sang Telegram
tele_join_queue = queue.Queue()

def is_gold_content(message_obj):
    text = str(message_obj.text or "").lower()
    if message_obj.file:
        name = (message_obj.file.name or "").lower()
        return any(name.endswith(ext) for ext in STRICT_EXT_WHITELIST)
    has_link = any(host in text for host in STRICT_HOST_WHITELIST)
    has_keyword = any(kw in text for kw in MOD_KEYWORDS)
    if any(domain in text for domain in DOMAIN_BLACKLIST): return False
    return has_link and (has_keyword or any(ext in text for ext in STRICT_EXT_WHITELIST))

async def process_tele_message(event):
    global _tele_client
    try:
        chat_from = await event.get_chat()
        if getattr(chat_from, 'username', '').upper() == TELE_TARGET_CHANNEL.upper(): return
        if not is_gold_content(event.message): return

        unique_uid = f"tele_{event.chat_id}_{event.message.id}"
        with cache_lock:
            if unique_uid in global_hunted_cache: return
            global_hunted_cache.add(unique_uid)
            save_hunted_cache(global_hunted_cache)

        print(f"🚀 [TELE] Bế Hàng Xịn: {getattr(chat_from, 'title', 'Kênh ẩn')}", flush=True)
        await _tele_client.forward_messages(TELE_TARGET_CHANNEL, event.message)
    except: pass

async def worker_queue_handler():
    """Xử lý hàng đợi tham gia nhóm tự động."""
    global _tele_client
    while True:
        try:
            if not tele_join_queue.empty() and _tele_client and await _tele_client.is_user_authorized():
                link = tele_join_queue.get()
                print(f"🔗 [TELE] Đang thử tham gia: {link}")
                try:
                    if "joinchat/" in link or "+" in link:
                        hash_code = link.split('/')[-1].replace('+', '')
                        await _tele_client(functions.messages.ImportChatInviteRequest(hash_code))
                    else:
                        username = link.split('/')[-1]
                        await _tele_client(functions.channels.JoinChannelRequest(username))
                    print(f"✅ [TELE] Đã tham gia thành công: {link}")
                except Exception as e:
                    print(f"❌ [TELE] Lỗi tham gia {link}: {e}")
                tele_join_queue.task_done()
        except: pass
        await asyncio.sleep(5)

async def start_tele_scrapper():
    global _tele_client
    try:
        with open("seting.json", "r", encoding='utf-8') as f:
            config = json.load(f).get("telegram", {})
        api_id, api_hash, phone = config.get("api_id"), config.get("api_hash"), config.get("phone")
        if not api_id or not api_hash: return
    except: return

    # Thử các session file cũ để tìm cái đã login
    possible_sessions = ["data/tele_session", "data/tele_session_new", "data/tele_fixed"]

    for sess_path in possible_sessions:
        if os.path.exists(sess_path + ".session"):
            print(f"🔍 Đang kiểm tra session: {sess_path}")
            try:
                _tele_client = TelegramClient(sess_path, int(api_id), api_hash)
                await _tele_client.connect()
                if await _tele_client.is_user_authorized():
                    print(f"✅ Đã tìm thấy session hợp lệ tại: {sess_path}")
                    break
                else:
                    await _tele_client.disconnect()
                    _tele_client = None
            except:
                _tele_client = None

    if _tele_client is None:
        _tele_client = TelegramClient("data/tele_session", int(api_id), api_hash)

    @_tele_client.on(events.NewMessage)
    async def my_event_handler(event): await process_tele_message(event)

    print(f"🚀 Telegram Scrapper đang khởi động...", flush=True)
    try:
        if not _tele_client.is_connected():
            await _tele_client.connect()

        if not await _tele_client.is_user_authorized():
            print("⚠️ Telegram CHƯA ĐĂNG NHẬP. Vui lòng chạy file 'login_tele.py' để nhập mã!", flush=True)
            return

        print(f"✅ Telegram ĐÃ KẾT NỐI - Hút về: {TELE_TARGET_CHANNEL}", flush=True)

        # Chạy handler hàng đợi song song với scrapper
        asyncio.create_task(worker_queue_handler())

        await _tele_client.run_until_disconnected()
    except Exception as e:
        print(f"❌ Telethon Error: {e}")
    finally:
        if _tele_client: await _tele_client.disconnect()

def run_tele_thread(zalo_client):
    global _tele_thread_running
    if _tele_thread_running: return
    _tele_thread_running = True
    def worker():
        fail_count = 0
        while fail_count < 5:
            loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(start_tele_scrapper())
                fail_count = 0
            except Exception as e:
                fail_count += 1
                print(f"⚠️ Telethon loop crashed ({fail_count}/5): {e}. Restarting in 30s...")
            finally:
                try:
                    pending = asyncio.all_tasks(loop)
                    if pending: loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                    loop.close()
                except: pass
            time.sleep(30)
        print("🛑 Telethon scraper stopped after 5 consecutive failures.")
    threading.Thread(target=worker, daemon=True, name="TeleScraper").start()

def PTA(): return {}
des = {'version': "8.9.6", 'credits': "HOANG LAM", 'description': "Tự động tìm kiếm session đã login"}
