from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Sự thật thú vị ngẫu nhiên", 'power': "Thành viên"}

def handle_fact_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://uselessfacts.jsph.pl/api/v2/facts/random?language=en", timeout=10)
        data = r.json()
        client.replyMessage(Message(text=f"🧠 {data.get('text')}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'fact': handle_fact_command, 'suthat': handle_fact_command}
