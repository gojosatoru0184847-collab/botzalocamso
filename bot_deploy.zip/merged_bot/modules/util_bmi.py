from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tính chỉ số BMI", 'power': "Thành viên"}

def handle_bmi_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 3:
        client.replyMessage(Message(text="⚖️ Dùng: .bmi <cân nặng kg> <chiều cao cm>"), message_object, thread_id, thread_type)
        return
    try:
        weight = float(parts[1])
        height_cm = float(parts[2])
        height_m = height_cm / 100
        bmi = weight / (height_m ** 2)
        if bmi < 18.5: cat = "Thiếu cân"
        elif bmi < 25: cat = "Bình thường"
        elif bmi < 30: cat = "Thừa cân"
        else: cat = "Béo phì"
        msg = f"⚖️ BMI = {bmi:.1f}\nPhân loại: {cat}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi nhập liệu: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'bmi': handle_bmi_command}
