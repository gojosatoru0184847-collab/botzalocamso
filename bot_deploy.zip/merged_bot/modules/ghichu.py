from zlapi.models import Message
import json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Ghi chú cá nhân trong nhóm", 'power': "Thành viên"}

NOTE_FILE = "modules/cache/data/notes.json"

def _load():
    try:
        with open(NOTE_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(NOTE_FILE), exist_ok=True)
    with open(NOTE_FILE, 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False, indent=2)

def _add(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="📝 Dùng: .ghichu <nội dung>"), message_object, thread_id, thread_type); return
    d = _load(); uid = str(author_id)
    if uid not in d: d[uid] = []
    d[uid].append(p[1])
    _save(d)
    client.replyMessage(Message(text=f"✅ Đã lưu ghi chú #{len(d[uid])}"), message_object, thread_id, thread_type)

def _list(message, message_object, thread_id, thread_type, author_id, client):
    d = _load(); uid = str(author_id)
    notes = d.get(uid, [])
    if not notes:
        client.replyMessage(Message(text="📝 Bạn chưa có ghi chú nào."), message_object, thread_id, thread_type); return
    lines = "\n".join(f"{i+1}. {n}" for i,n in enumerate(notes))
    client.replyMessage(Message(text=f"📝 GHI CHÚ CỦA BẠN:\n{lines}"), message_object, thread_id, thread_type)

def _del(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🗑 Dùng: .xoagc <số thứ tự>"), message_object, thread_id, thread_type); return
    try:
        idx = int(p[1]) - 1
        d = _load(); uid = str(author_id)
        if 0 <= idx < len(d.get(uid,[])):
            removed = d[uid].pop(idx)
            _save(d)
            client.replyMessage(Message(text=f"🗑 Đã xóa: {removed}"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="❌ Số thứ tự không hợp lệ."), message_object, thread_id, thread_type)
    except: client.replyMessage(Message(text="❌ Nhập số hợp lệ."), message_object, thread_id, thread_type)

def PTA():
    return {'ghichu': _add, 'listnote': _list, 'xoagc': _del, 'notes': _list}
