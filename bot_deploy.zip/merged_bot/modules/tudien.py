from zlapi.models import Message
import requests
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tra từ điển tiếng Anh",'power':"Thành viên"}

def handle_tudien_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text=f"📖 Dùng: {PREFIX}tudien <từ tiếng Anh>"), message_object, thread_id, thread_type); return
    word = parts[1].lower()
    try:
        r = requests.get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}", timeout=10)
        data = r.json()
        if isinstance(data, dict) and data.get("title") == "No Definitions Found":
            raise ValueError("Không tìm thấy từ")
        entry = data[0]
        phonetic = entry.get("phonetic","")
        meanings = entry.get("meanings",[])
        msg = f"📖 {word.upper()} {phonetic}\n━━━━━━━━━━━━━━━\n"
        for m in meanings[:2]:
            pos = m.get("partOfSpeech","")
            msg += f"[{pos}]\n"
            for d in m.get("definitions",[])[:2]:
                msg += f"• {d.get('definition','')}\n"
                if d.get("example"): msg += f"  VD: {d['example']}\n"
            msg += "\n"
        client.replyMessage(Message(text=msg.strip()), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy '{word}'"), message_object, thread_id, thread_type)

def PTA():
    return {'tudien': handle_tudien_command}
