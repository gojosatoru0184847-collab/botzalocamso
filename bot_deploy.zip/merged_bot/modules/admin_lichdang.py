from zlapi.models import Message, ThreadType
import json, os, threading, time
from datetime import datetime
from config import ADMIN

des = {'version': "1.0.0", 'credits': "HOANG LAM", 'description': "Lên lịch gửi tin nhắn tự động", 'power': "Quản trị viên Bot"}

SCHED_FILE = "modules/cache/data/schedule_msgs.json"

def _load():
    try:
        with open(SCHED_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return []

def _save(d):
    os.makedirs(os.path.dirname(SCHED_FILE), exist_ok=True)
    with open(SCHED_FILE, 'w', encoding='utf-8') as f: json.dump(d, f, ensure_ascii=False)

def handle_lichdang_command(message, message_object, thread_id, thread_type, author_id, client):
    if str(author_id) != ADMIN and str(author_id) not in getattr(client, 'ADM', []):
        client.replyMessage(Message(text="⚠️ Chỉ admin bot mới dùng được lệnh này."), message_object, thread_id, thread_type)
        return
    parts = message.strip().split(maxsplit=2)
    if len(parts) < 3:
        client.replyMessage(Message(text="📅 Dùng: .lichdang HH:MM <nội dung>\nVí dụ: .lichdang 08:00 Chào buổi sáng!"), message_object, thread_id, thread_type)
        return
    time_str, content = parts[1], parts[2]
    try:
        datetime.strptime(time_str, "%H:%M")
    except:
        client.replyMessage(Message(text="❌ Định dạng giờ sai. Dùng HH:MM"), message_object, thread_id, thread_type)
        return
    scheds = _load()
    scheds.append({"thread_id": str(thread_id), "time": time_str, "content": content})
    _save(scheds)
    client.replyMessage(Message(text=f"✅ Đã lên lịch gửi '{content}' vào {time_str} mỗi ngày."), message_object, thread_id, thread_type)

_scheduler_started = False
_last_sent = {}

def start_schedule_checker(client):
    global _scheduler_started
    if _scheduler_started: return
    _scheduler_started = True
    def loop():
        while True:
            now = datetime.now().strftime("%H:%M")
            today = datetime.now().strftime("%Y-%m-%d")
            scheds = _load()
            for s in scheds:
                key = f"{s['thread_id']}_{s['time']}_{today}"
                if s["time"] == now and key not in _last_sent:
                    try:
                        client.send(Message(text=s["content"]), thread_id=s["thread_id"], thread_type=ThreadType.GROUP)
                        _last_sent[key] = True
                    except Exception:
                        pass
            time.sleep(30)
    threading.Thread(target=loop, daemon=True).start()

def PTA():
    return {'lichdang': handle_lichdang_command}
