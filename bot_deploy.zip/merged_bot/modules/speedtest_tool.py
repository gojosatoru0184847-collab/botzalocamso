from zlapi.models import Message
import requests, time

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Test tốc độ mạng bot server", 'power': "Thành viên"}

def _speedtest(message, message_object, thread_id, thread_type, author_id, client):
    client.replyMessage(Message(text="🌐 Đang test tốc độ mạng..."), message_object, thread_id, thread_type)
    try:
        t0 = time.time()
        r = requests.get("https://speed.cloudflare.com/__down?bytes=1000000", timeout=15, stream=True)
        total = sum(len(c) for c in r.iter_content(8192))
        dt = max(time.time() - t0, 0.01)
        dl_mbps = (total * 8 / 1_000_000) / dt
        t1 = time.time()
        requests.get("https://1.1.1.1", timeout=5)
        ping = (time.time() - t1) * 1000
        msg = f"🌐 SPEED TEST\n━━━━━━━━━━\n• Ping: {ping:.0f}ms\n• Download: {dl_mbps:.2f} Mbps"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'speedtest': _speedtest, 'nettest': _speedtest}
