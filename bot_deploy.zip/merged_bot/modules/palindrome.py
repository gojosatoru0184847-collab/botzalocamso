from zlapi.models import Message
import unicodedata, re
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Kiểm tra palindrome (đối xứng)",'power':"Thành viên"}

def normalize(text):
    text = text.lower()
    text = unicodedata.normalize('NFD', text)
    text = re.sub(r'[\u0300-\u036f]', '', text)
    return re.sub(r'[^a-z0-9]', '', text)

def handle_palindrome_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text=f"🔄 Dùng: {PREFIX}palindrome <text>"), message_object, thread_id, thread_type); return
    text = parts[1]
    norm = normalize(text)
    is_pal = norm == norm[::-1]
    if is_pal:
        client.replyMessage(Message(text=f"✅ \"{text}\" là palindrome! 🎉"), message_object, thread_id, thread_type)
    else:
        client.replyMessage(Message(text=f"❌ \"{text}\" không phải palindrome.\nĐảo ngược: {text[::-1]}"), message_object, thread_id, thread_type)

def PTA():
    return {'palindrome': handle_palindrome_command}
