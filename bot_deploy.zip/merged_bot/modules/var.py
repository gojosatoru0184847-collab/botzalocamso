# -*- coding: utf-8 -*-
import json, time, threading, random, os
from zlapi.models import Message, Mention, MultiMsgStyle, MessageStyle
from config import PREFIX

des = {
    'version': "3.0.0",
    'credits': "HOANG LAM",
    'description': "Var/War thống nhất - Kho đạn 100k câu",
    'power': "Chủ sở hữu Bot"
}

# BIẾN TRẠNG THÁI DÙNG CHUNG CHO TOÀN BỘ HỆ THỐNG WAR/VAR
# { thread_id: bool }
global_war_state = {}
state_lock = threading.Lock()

def get_100k_content():
    paths = ["war_content_100k.txt", "war_content.txt"]
    for p in paths:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return [l.strip() for l in f if l.strip()]
            except: pass
    return ["Sủa đi con chó rách! 🐶", "Gõ nhanh lên! ⌨️", "Trình còi! 🔥"]

def handle_var_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(client, 'is_super_admin') or not client.is_super_admin(author_id):
        return

    parts = message.split()
    if len(parts) < 2:
        client.replyMessage(Message(text=f"⚔️ Cách dùng: {PREFIX}var on/off hoặc {PREFIX}stop"), message_object, thread_id, thread_type)
        return
    
    action = parts[1].lower()

    if action == "on":
        with state_lock:
            if global_war_state.get(thread_id):
                client.replyMessage(Message(text="🚦 Hỏa lực đang rực cháy rồi!"), message_object, thread_id, thread_type)
                return
            global_war_state[thread_id] = True

        content = get_100k_content()
        client.replyMessage(Message(text=f"🚀 [ VAR 100K ] ĐÃ KHỞI ĐỘNG!"), message_object, thread_id, thread_type)

        def loop():
            while global_war_state.get(thread_id):
                txt = random.choice(content)
                styles = MultiMsgStyle([
                    MessageStyle(offset=0, length=len(txt), style="font", size="500", auto_format=False),
                    MessageStyle(offset=0, length=len(txt), style="bold", auto_format=False),
                    MessageStyle(offset=0, length=len(txt), style="color", color="#db342e", auto_format=False)
                ])
                try: client.sendMessage(Message(text=txt, style=styles), thread_id, thread_type)
                except: break
                time.sleep(0.3)
        threading.Thread(target=loop, daemon=True).start()

    elif action == "off":
        with state_lock: global_war_state[thread_id] = False
        client.replyMessage(Message(text="🛑 ĐÃ TẮT TOÀN BỘ VAR/WAR."), message_object, thread_id, thread_type)

def PTA():
    return {
        'var': handle_var_command,
        'stop': lambda msg, obj, tid, tty, aid, cli: handle_var_command(f"{PREFIX}var off", obj, tid, tty, aid, cli)
    }
