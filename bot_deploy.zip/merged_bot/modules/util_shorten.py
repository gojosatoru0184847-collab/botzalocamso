from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Rút gọn link", 'power': "Thành viên"}

def handle_shorten_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🔗 Dùng: .shorten <link>"), message_object, thread_id, thread_type)
        return
    url = parts[1].strip()
    try:
        r = requests.get(f"https://tinyurl.com/api-create.php?url={url}", timeout=10)
        short = r.text.strip()
        client.replyMessage(Message(text=f"🔗 Link rút gọn:\n{short}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi rút gọn link: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'shorten': handle_shorten_command, 'rutgon': handle_shorten_command}
