from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Giá Bitcoin/crypto realtime", 'power': "Thành viên"}

COIN_MAP = {
    "btc": "bitcoin", "bitcoin": "bitcoin",
    "eth": "ethereum", "ethereum": "ethereum",
    "bnb": "binancecoin", "sol": "solana",
    "doge": "dogecoin", "xrp": "ripple",
    "ada": "cardano", "usdt": "tether",
}

def handle_coin_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    coin = parts[1].lower() if len(parts) > 1 else "btc"
    coin_id = COIN_MAP.get(coin, coin)
    try:
        r = requests.get(f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd,vnd&include_24hr_change=true", timeout=10)
        data = r.json()
        if coin_id not in data:
            raise ValueError("Không tìm thấy coin")
        info = data[coin_id]
        change = info.get('usd_24h_change', 0)
        emoji = "📈" if change >= 0 else "📉"
        msg = (
            f"💰 GIÁ {coin.upper()}\n━━━━━━━━━━━━━━━\n"
            f"• USD: ${info.get('usd',0):,.2f}\n"
            f"• VND: {info.get('vnd',0):,.0f}đ\n"
            f"• 24h: {emoji} {change:.2f}%"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy coin '{coin}': {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'coin': handle_coin_command, 'gia': handle_coin_command, 'crypto': handle_coin_command}
