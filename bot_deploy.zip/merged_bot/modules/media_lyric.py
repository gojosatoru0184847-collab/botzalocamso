from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tra lời bài hát", 'power': "Thành viên"}

def handle_loi_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="🎵 Dùng: .loi <tên bài hát> - <ca sĩ>"), message_object, thread_id, thread_type)
        return
    query = parts[1]
    try:
        if " - " in query:
            title, artist = query.split(" - ", 1)
        else:
            title, artist = query, ""
        r = requests.get(f"https://api.lyrics.ovh/v1/{artist.strip()}/{title.strip()}", timeout=10)
        data = r.json()
        lyrics = data.get("lyrics")
        if not lyrics:
            raise ValueError("Không tìm thấy lời bài hát")
        client.replyMessage(Message(text=f"🎵 LỜI BÀI HÁT: {title}\n━━━━━━━━━━━━━━━\n{lyrics[:1500]}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy lời bài hát: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'loi': handle_loi_command, 'lyrics': handle_loi_command}
