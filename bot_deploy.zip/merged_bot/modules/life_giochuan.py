from zlapi.models import Message
from datetime import datetime
import pytz

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Xem giờ ở các quốc gia khác", 'power': "Thành viên"}

ZONES = {
    "vn": "Asia/Ho_Chi_Minh", "vietnam": "Asia/Ho_Chi_Minh",
    "us": "America/New_York", "uk": "Europe/London",
    "jp": "Asia/Tokyo", "japan": "Asia/Tokyo",
    "kr": "Asia/Seoul", "korea": "Asia/Seoul",
    "cn": "Asia/Shanghai", "china": "Asia/Shanghai",
    "au": "Australia/Sydney", "fr": "Europe/Paris",
    "de": "Europe/Berlin", "sg": "Asia/Singapore",
}

def handle_gioqt_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🌍 Dùng: .gioqt <mã quốc gia>\nVí dụ: us, uk, jp, kr, cn, au, fr, de, sg, vn"), message_object, thread_id, thread_type)
        return
    code = parts[1].lower()
    if code not in ZONES:
        client.replyMessage(Message(text="❌ Mã quốc gia không hỗ trợ."), message_object, thread_id, thread_type)
        return
    try:
        tz = pytz.timezone(ZONES[code])
        now = datetime.now(tz)
        msg = f"🌍 Giờ tại {code.upper()}: {now.strftime('%H:%M:%S - %d/%m/%Y')}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'gioqt': handle_gioqt_command, 'worldtime': handle_gioqt_command}
