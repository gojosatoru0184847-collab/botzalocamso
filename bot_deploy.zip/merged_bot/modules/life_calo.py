from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tính lượng calo cần/ngày (Harris-Benedict)", 'power': "Thành viên"}

def handle_calo_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 5:
        client.replyMessage(Message(text="🍽 Dùng: .calo <nam/nu> <tuổi> <kg> <cm>\nVí dụ: .calo nam 25 70 175"), message_object, thread_id, thread_type)
        return
    gender, age, weight, height = parts[1].lower(), parts[2], parts[3], parts[4]
    try:
        age, weight, height = int(age), float(weight), float(height)
        if gender == "nam":
            bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
        else:
            bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
        msg = (
            f"🍽 NHU CẦU CALO HÀNG NGÀY\n━━━━━━━━━━━━━━━\n"
            f"• BMR (cơ bản): {bmr:.0f} kcal\n"
            f"• Ít vận động: {bmr*1.2:.0f} kcal\n"
            f"• Vận động nhẹ: {bmr*1.375:.0f} kcal\n"
            f"• Vận động vừa: {bmr*1.55:.0f} kcal\n"
            f"• Vận động nhiều: {bmr*1.725:.0f} kcal"
        )
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi nhập liệu: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'calo': handle_calo_command}
