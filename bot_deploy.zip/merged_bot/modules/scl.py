import os
import logging
import requests
import json
import time
import urllib.parse
from zlapi.models import Message
from config import PREFIX

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

des = {
    'version': "2.5.0",
    'credits': "HOANG LAM",
    'description': "Tìm và phát nhạc từ SoundCloud (Hát trực tiếp)",
    'power': "Thành viên"
}

SEARCH_TIMEOUT = 120

def get_headers():
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    }

def handle_scl_command(message_text, message_object, thread_id, thread_type, author_id, client):
    user_states = client.scl_user_states
    parts = message_text.strip().split(maxsplit=1)

    # Lấy nội dung truy vấn (Bỏ prefix nếu có)
    query = ""
    if len(parts) >= 2:
        query = parts[1].strip()
    else:
        # Nếu chỉ gõ mỗi số (từ main.py chuyển sang)
        query = parts[0].strip()

    # Nếu là số -> đang chọn bài
    if query.isdigit() and author_id in user_states:
        state = user_states[author_id]
        if time.time() - state['time_of_search'] > SEARCH_TIMEOUT:
            del user_states[author_id]
            client.replyMessage(Message(text="⚠️ Kết quả đã hết hạn, vui lòng tìm lại."), message_object, thread_id, thread_type)
            return

        index = int(query) - 1
        tracks = state['tracks']

        if not (0 <= index < len(tracks)):
            client.replyMessage(Message(text="❌ Lựa chọn không hợp lệ."), message_object, thread_id, thread_type)
            return

        selected_track = tracks[index]
        del user_states[author_id]

        title = selected_track.get("title", "Không rõ")
        link = selected_track.get("permalink_url", "")

        client.replyMessage(Message(text=f"🎶 Đang tải bài: {title}...\nĐại ca đợi xíu nhé!"), message_object, thread_id, thread_type)

        try:
            # Sử dụng cobalt.tools để lấy audio URL
            api_url = "https://api.cobalt.tools/api/json"
            headers = {"Accept": "application/json", "Content-Type": "application/json"}
            payload = {"url": link, "aFormat": "mp3", "isAudioOnly": True}
            r = requests.post(api_url, json=payload, headers=headers, timeout=30)
            data = r.json()

            if data.get("status") in ("stream", "redirect", "tunnel"):
                audio_url = data.get("url")
                # Gửi dưới dạng tin nhắn thoại cho uy tín
                res = client.sendRemoteVoice(audio_url, thread_id, thread_type)
                if res:
                    client.sendReaction(message_object, "🎤", thread_id, thread_type)
            else:
                client.replyMessage(Message(text=f"❌ Không thể tải bài này: {data.get('text', 'Lỗi không xác định')}"), message_object, thread_id, thread_type)
        except Exception as download_err:
            logger.error(f"Lỗi tải nhạc SoundCloud: {download_err}")
            client.replyMessage(Message(text=f"🔗 Đại ca nghe tạm qua link nhé: {link}"), message_object, thread_id, thread_type)

        return

    if not query:
        client.replyMessage(Message(text=f"🎵 Vui lòng nhập tên bài hát.\nVí dụ: {PREFIX}scl Nơi này có anh"), message_object, thread_id, thread_type)
        return

    # Nếu là chữ -> Tìm kiếm
    client.replyMessage(Message(text=f"🔍 Đang tìm nhạc cho '{query}'..."), message_object, thread_id, thread_type)

    try:
        encoded = urllib.parse.quote(query)
        # Sử dụng API SoundCloud ổn định từ Vytub (Chống bị chặn ID)
        api_url = f"https://api.vytub.com/soundcloud/search?q={encoded}"
        res = requests.get(api_url, timeout=20)
        data = res.json()

        if not data.get("collection") and not data.get("data"):
            client.replyMessage(Message(text=f"❌ Không tìm thấy kết quả nào cho '{query}'."), message_object, thread_id, thread_type)
            return

        tracks = data.get("collection") or data.get("data")
        tracks = tracks[:10]

        user_states[author_id] = {'tracks': tracks, 'time_of_search': time.time()}

        msg = f"🎵 Kết quả SoundCloud cho '{query}':\n\n"
        for i, t in enumerate(tracks, 1):
            msg += f"{i}. {t.get('title')} - {t.get('user', {}).get('username')}\n"

        msg += f"\n➜ Trả lời tin nhắn này với số thứ tự để lấy link. Hết hạn sau {SEARCH_TIMEOUT}s."
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

    except Exception as e:
        logger.error(f"Lỗi SoundCloud: {str(e)}")
        client.replyMessage(Message(text="⚠️ Lỗi khi tìm nhạc SoundCloud!"), message_object, thread_id, thread_type)

def PTA():
    return {
        'scl': handle_scl_command
    }
