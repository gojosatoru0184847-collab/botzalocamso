import time
from zlapi.models import *
import requests
import urllib.parse
import os
import random

des = {
    'version': "1.0.5",
    'credits': "HOANG LAM",
    'description': "Tìm ảnh Pinterest (Đã Fix API)",
    'power': "Thành viên"
}

def handle_pin_command(message, message_object, thread_id, thread_type, author_id, client):
    text = message.split()

    if len(text) < 2:
        client.replyMessage(Message(text="⚠️ Dùng: .pin [tên ảnh] [số lượng]\nVí dụ: .pin girl 5"), message_object, thread_id, thread_type)
        return

    # Lấy số lượng ở cuối nếu có, mặc định là 5
    num = 5
    if text[-1].isdigit():
        num = int(text[-1])
        if num > 15: num = 15
        search_query = " ".join(text[1:-1])
    else:
        search_query = " ".join(text[1:])

    if not search_query.strip():
        client.replyMessage(Message(text="⚠️ Đại ca chưa nhập tên ảnh cần tìm!"), message_object, thread_id, thread_type)
        return

    client.sendReaction(message_object, "🔍", thread_id, thread_type)

    try:
        # Sử dụng API Pinterest mới (Vytub ổn định hơn)
        api_url = f"https://api.vytub.com/pinterest?search={urllib.parse.quote(search_query)}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        res_raw = requests.get(api_url, headers=headers, timeout=15)
        res = res_raw.json()

        if not links:
            client.replyMessage(Message(text="❌ Không tìm thấy ảnh này thưa Đại ca!"), message_object, thread_id, thread_type)
            return

        random.shuffle(links)
        final_links = links[:num]

        image_paths = []
        for i, url in enumerate(final_links):
            try:
                img_data = requests.get(url, timeout=10).content
                path = f"modules/cache/pin_{int(time.time())}_{i}.jpg"
                with open(path, 'wb') as f: f.write(img_data)
                image_paths.append(path)
            except: continue

        if image_paths:
            client.sendMultiLocalImage(image_paths, thread_id, thread_type, message=Message(text=f"✅ Đã tìm thấy {len(image_paths)} ảnh '{search_query}' cho Đại ca!"))
            for p in image_paths:
                if os.path.exists(p): os.remove(p)
        else:
            client.replyMessage(Message(text="❌ Lỗi tải ảnh, Đại ca thử lại nhé!"), message_object, thread_id, thread_type)

    except Exception as e:
        client.replyMessage(Message(text=f"⚠️ API Pinterest đang bận: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'pin': handle_pin_command}
