from zlapi.models import Message
import random, hashlib
from datetime import date

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Xin xăm / bói quẻ hôm nay", 'power': "Thành viên"}

QUE = [
    "Đại cát: Mọi việc thuận lợi, nên tiến hành kế hoạch đã định.",
    "Cát: Có chút trở ngại nhưng vẫn thành công nếu kiên trì.",
    "Bình: Mọi thứ ổn định, không có biến động lớn.",
    "Tiểu hung: Cần cẩn trọng trong quyết định, tránh vội vàng.",
    "Hung: Nên trì hoãn việc quan trọng, chờ thời điểm thích hợp hơn.",
]

def handle_xinxam_command(message, message_object, thread_id, thread_type, author_id, client):
    seed = f"{author_id}{date.today()}"
    random.seed(int(hashlib.md5(seed.encode()).hexdigest(), 16))
    que = random.choice(QUE)
    msg = f"🎋 QUẺ XĂM HÔM NAY\n━━━━━━━━━━━━━━━\n{que}"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'xinxam': handle_xinxam_command, 'boique': handle_xinxam_command}
