# -*- coding: utf-8 -*-
import requests
import random
import os
import tempfile
from PIL import Image
from zlapi.models import Message
from deep_translator import GoogleTranslator

des = {
    'version': "8.2.0",
    'credits': "HOANG LAM",
    'description': "Kho lệnh API giải trí 30+ lệnh (Đã gỡ AI - Chạy mượt 100%)",
    'power': "Thành viên"
}

def translate_vn(text):
    try: return GoogleTranslator(source='auto', target='vi').translate(text)
    except: return text

def get_json(url):
    try: return requests.get(url, timeout=10).json()
    except: return None

def send_img(client, tid, tt, url, caption=""):
    temp_path = None
    try:
        res = requests.get(url, timeout=20)
        if res.status_code == 200:
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tf:
                tf.write(res.content)
                temp_path = tf.name
            with Image.open(temp_path) as img: w, h = img.size
            client.sendLocalImage(temp_path, thread_id=tid, thread_type=tt, width=w, height=h, message=Message(text=caption))
    finally:
        if temp_path and os.path.exists(temp_path): os.remove(temp_path)

# --- HANDLERS ---
def h_animal(m, mo, tid, tt, aid, client):
    cmd = m.split()[0][1:].lower()
    urls = {
        'cat': "https://api.thecatapi.com/v1/images/search",
        'dog': "https://dog.ceo/api/breeds/image/random",
        'fox': "https://randomfox.ca/floof/",
        'panda': "https://some-random-api.com/img/panda",
        'bird': "https://some-random-api.com/img/bird",
        'koala': "https://some-random-api.com/img/koala"
    }
    url = urls.get(cmd)
    if url:
        data = get_json(url)
        img = data[0]['url'] if isinstance(data, list) else data.get('link') or data.get('image') or data.get('message')
        if img: send_img(client, tid, tt, img, f"🐾 {cmd.capitalize()} đây Đại ca!")

def h_fact(m, mo, tid, tt, aid, client):
    d = get_json("https://uselessfacts.jsph.pl/api/v2/facts/random?language=en")
    if d: client.send(Message(text=f"🧠 BẠN CÓ BIẾT:\n{translate_vn(d['text'])}"), tid, tt)

def h_joke(m, mo, tid, tt, aid, client):
    d = get_json("https://v2.jokeapi.dev/joke/Any?type=single")
    if d and d.get('joke'): client.send(Message(text=f"😆 CÂU ĐỐ VUI:\n{translate_vn(d['joke'])}"), tid, tt)

def h_ip(m, mo, tid, tt, aid, client):
    parts = m.split()
    ip = parts[1] if len(parts) > 1 else ""
    d = get_json(f"http://ip-api.com/json/{ip}")
    if d and d.get('status') == 'success':
        msg = f"📍 THÔNG TIN IP: {d['query']}\n🗺 Quốc gia: {d['country']}\n🏙 Thành phố: {d['city']}\n📡 ISP: {d['isp']}"
        client.send(Message(text=msg), tid, tt)

def h_listapi(m, mo, tid, tt, aid, client):
    msg = f"🚀 KHO LỆNH GIẢI TRÍ ({des['version']})\n"
    msg += "🐾 Động vật: cat, dog, fox, panda, bird, koala\n"
    msg += "🧠 Kiến thức: fact, joke, ip [ip], math [phép tính]\n"
    msg += "🎨 Ảnh: waifu, meme, pixel, avatar\n"
    msg += "👉 Dùng {client.prefix}[lệnh]"
    client.send(Message(text=msg), tid, tt)

def PTA():
    return {
        'cat': h_animal, 'dog': h_animal, 'fox': h_animal, 'panda': h_animal,
        'bird': h_animal, 'koala': h_animal, 'fact': h_fact, 'joke': h_joke,
        'ip': h_ip, 'listapi': h_listapi, 'waifu': h_animal, 'meme': h_animal
    }
