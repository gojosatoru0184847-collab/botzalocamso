from zlapi.models import Message, ThreadType
import json, os, time, threading

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Công cụ quản lý nhóm nâng cao", 'power': "Quản trị viên Bot"}

def _welcome_test(message, message_object, thread_id, thread_type, author_id, client):
    """Test tin nhắn chào mừng hiện tại"""
    try:
        with open('data/welcome_settings.json', encoding='utf-8') as f:
            ws = json.load(f)
        tid = str(thread_id)
        setting = ws.get(tid, {})
        if setting.get('enabled'):
            msg = setting.get('message', 'Chào mừng {name} đến nhóm!')
            client.replyMessage(Message(text=f"📋 Preview tin chào mừng:\n{msg}"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="ℹ️ Chào mừng chưa bật. Dùng .welcome on để bật."), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="ℹ️ Chưa có cấu hình chào mừng."), message_object, thread_id, thread_type)

def _countmem(message, message_object, thread_id, thread_type, author_id, client):
    """Đếm số thành viên nhóm"""
    try:
        info = client.fetchGroupInfo(thread_id)
        gdata = info.gridInfoMap.get(str(thread_id), info.gridInfoMap.get(thread_id, {}))
        members = gdata.get('memberIds', gdata.get('currentMems', []))
        name = gdata.get('name', 'Nhóm này')
        client.replyMessage(Message(text=f"👥 {name}\nSố thành viên: {len(members)} người"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _setdesc(message, message_object, thread_id, thread_type, author_id, client):
    """Đặt mô tả nhóm"""
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="📝 Dùng: .setdesc <nội dung mô tả nhóm>"), message_object, thread_id, thread_type)
        return
    try:
        client.changeGroupDesc(p[1], thread_id)
        client.replyMessage(Message(text="✅ Đã cập nhật mô tả nhóm!"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _pinlink(message, message_object, thread_id, thread_type, author_id, client):
    """Lấy link tham gia nhóm"""
    try:
        link = client.getQRLink(thread_id)
        client.replyMessage(Message(text=f"🔗 Link tham gia nhóm:\n{link}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi lấy link: {e}"), message_object, thread_id, thread_type)

def _muteall(message, message_object, thread_id, thread_type, author_id, client):
    """Im lặng tất cả thành viên (trừ admin)"""
    p = message.strip().split()
    duration = 10  # phút mặc định
    if len(p) > 1:
        try: duration = int(p[1])
        except: pass
    client.replyMessage(Message(text=f"🔕 Tính năng muteall cần quyền cao nhất. Dùng .mute @user để mute từng người."), message_object, thread_id, thread_type)

def PTA():
    return {
        'welcome_test': _welcome_test, 'testwelcome': _welcome_test,
        'countmem': _countmem, 'sochuong': _countmem,
        'setdesc': _setdesc, 'setmotat': _setdesc,
        'pinlink': _pinlink, 'linknhom': _pinlink,
    }
