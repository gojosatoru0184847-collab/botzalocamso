from zlapi.models import Message
import random
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tạo màu ngẫu nhiên",'power':"Thành viên"}

def handle_random_color_command(message, message_object, thread_id, thread_type, author_id, client):
    r,g,b = random.randint(0,255), random.randint(0,255), random.randint(0,255)
    hex_color = f"#{r:02X}{g:02X}{b:02X}"
    # Tính màu chữ tương phản
    luminance = 0.299*r + 0.587*g + 0.114*b
    contrast = "Trắng" if luminance < 128 else "Đen"
    msg = (f"🎨 MÀU NGẪU NHIÊN\n━━━━━━━━━━━━━━━\n"
           f"• HEX: {hex_color}\n• RGB: ({r}, {g}, {b})\n"
           f"• Chữ tương phản: {contrast}\n"
           f"• Độ sáng: {luminance:.0f}/255")
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'randomcolor': handle_random_color_command}
