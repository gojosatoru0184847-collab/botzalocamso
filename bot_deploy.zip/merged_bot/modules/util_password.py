from zlapi.models import Message
import random, string

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tạo mật khẩu ngẫu nhiên an toàn", 'power': "Thành viên"}

def handle_genpass_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    length = 12
    if len(parts) > 1:
        try:
            length = max(6, min(int(parts[1]), 64))
        except: pass
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    password = "".join(random.choice(chars) for _ in range(length))
    client.replyMessage(Message(text=f"🔑 Mật khẩu ngẫu nhiên ({length} ký tự):\n{password}\n\n⚠️ Hãy lưu lại an toàn, không chia sẻ cho ai!"), message_object, thread_id, thread_type)

def PTA():
    return {'genpass': handle_genpass_command, 'taomk': handle_genpass_command}
