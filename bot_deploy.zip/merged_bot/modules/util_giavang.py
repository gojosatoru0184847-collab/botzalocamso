from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Giá vàng SJC hôm nay", 'power': "Thành viên"}

def handle_giavang_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://www.giavang.org/api/v1/gold-price", timeout=10)
        if r.status_code != 200:
            # fallback to a known public API
            r2 = requests.get("https://api.btmc.vn/api/BTMCAPI/getpricebtmc?key=3kkhsj8sk88936072025dhgfdgsmms", timeout=10)
            data2 = r2.json()
            rows = data2.get("DataList", {}).get("Data", [])[:5]
            lines = []
            for row in rows:
                name = row.get("@n_1", "")
                buy = row.get("@pb_1", "")
                sell = row.get("@ps_1", "")
                if name:
                    lines.append(f"• {name}: Mua {buy} / Bán {sell}")
            msg = "🏆 GIÁ VÀNG HÔM NAY\n━━━━━━━━━━━━━━━\n" + "\n".join(lines)
        else:
            data = r.json()
            msg = f"🏆 GIÁ VÀNG: {data}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không lấy được giá vàng: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'giavang': handle_giavang_command}
