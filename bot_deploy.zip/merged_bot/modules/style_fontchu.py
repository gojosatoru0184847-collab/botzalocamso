from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chuyển chữ thành font đặc biệt", 'power': "Thành viên"}

FONTS = {
    "bubble": {
        'a':'ⓐ','b':'ⓑ','c':'ⓒ','d':'ⓓ','e':'ⓔ','f':'ⓕ','g':'ⓖ','h':'ⓗ','i':'ⓘ','j':'ⓙ',
        'k':'ⓚ','l':'ⓛ','m':'ⓜ','n':'ⓝ','o':'ⓞ','p':'ⓟ','q':'ⓠ','r':'ⓡ','s':'ⓢ','t':'ⓣ',
        'u':'ⓤ','v':'ⓥ','w':'ⓦ','x':'ⓧ','y':'ⓨ','z':'ⓩ'
    },
    "bold": {
        'a':'𝐚','b':'𝐛','c':'𝐜','d':'𝐝','e':'𝐞','f':'𝐟','g':'𝐠','h':'𝐡','i':'𝐢','j':'𝐣',
        'k':'𝐤','l':'𝐥','m':'𝐦','n':'𝐧','o':'𝐨','p':'𝐩','q':'𝐪','r':'𝐫','s':'𝐬','t':'𝐭',
        'u':'𝐮','v':'𝐯','w':'𝐰','x':'𝐱','y':'𝐲','z':'𝐳'
    },
    "italic": {
        'a':'𝑎','b':'𝑏','c':'𝑐','d':'𝑑','e':'𝑒','f':'𝑓','g':'𝑔','h':'ℎ','i':'𝑖','j':'𝑗',
        'k':'𝑘','l':'𝑙','m':'𝑚','n':'𝑛','o':'𝑜','p':'𝑝','q':'𝑞','r':'𝑟','s':'𝑠','t':'𝑡',
        'u':'𝑢','v':'𝑣','w':'𝑤','x':'𝑥','y':'𝑦','z':'𝑧'
    },
    "square": {
        'a':'🄰','b':'🄱','c':'🄲','d':'🄳','e':'🄴','f':'🄵','g':'🄶','h':'🄷','i':'🄸','j':'🄹',
        'k':'🄺','l':'🄻','m':'🄼','n':'🄽','o':'🄾','p':'🄿','q':'🅀','r':'🅁','s':'🅂','t':'🅃',
        'u':'🅄','v':'🅅','w':'🅆','x':'🅇','y':'🅈','z':'🅉'
    },
}

def _convert(text, fontmap):
    return "".join(fontmap.get(c.lower(), c) for c in text)

def _make_handler(font_key):
    def handler(message, message_object, thread_id, thread_type, author_id, client):
        parts = message.strip().split(maxsplit=1)
        if len(parts) < 2:
            client.replyMessage(Message(text=f"✏️ Dùng: .{font_key} <text>"), message_object, thread_id, thread_type)
            return
        result = _convert(parts[1], FONTS[font_key])
        client.replyMessage(Message(text=result), message_object, thread_id, thread_type)
    return handler

def PTA():
    return {
        'fontbubble': _make_handler("bubble"),
        'fontbold': _make_handler("bold"),
        'fontitalic': _make_handler("italic"),
        'fontsquare': _make_handler("square"),
    }
