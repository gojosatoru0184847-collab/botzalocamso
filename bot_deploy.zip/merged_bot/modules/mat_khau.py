from zlapi.models import Message
import secrets, string

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tạo mật khẩu mạnh hoặc PIN", 'power': "Thành viên"}

def _gen(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    length = 16
    mode = "pass"
    for x in p[1:]:
        if x.isdigit(): length = max(4, min(int(x), 64))
        elif x in ("pin","pass","phrase"): mode = x
    if mode == "pin":
        result = ''.join(secrets.choice(string.digits) for _ in range(length))
        msg = f"🔢 PIN ({length} số):\n{result}"
    elif mode == "phrase":
        words = ["mặt trời","bầu trời","ánh sáng","núi rừng","biển xanh","gió thổi","hoa nở","chim bay","sóng vỗ","mưa rơi"]
        result = "-".join(secrets.choice(words) for _ in range(4))
        msg = f"🔑 Passphrase:\n{result}"
    else:
        chars = string.ascii_letters + string.digits + "!@#$%&*"
        result = ''.join(secrets.choice(chars) for _ in range(length))
        msg = f"🔑 Mật khẩu ({length} ký tự):\n{result}\n⚠️ Đừng chia sẻ cho ai!"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'mkpass': _gen, 'genpin': _gen, 'passgen': _gen}
