from zlapi.models import Message
import json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Cờ caro 2 người (gõ vị trí 1-9)", 'power': "Thành viên"}

GAME_FILE = "modules/cache/data/caro_game.json"

def _load():
    try:
        with open(GAME_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

def _render(board):
    symbols = {0: "⬜", 1: "❌", 2: "⭕"}
    rows = []
    for i in range(0, 9, 3):
        rows.append("".join(symbols[board[j]] for j in range(i, i+3)))
    return "\n".join(rows)

def _check_win(board, p):
    wins = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
    return any(all(board[i] == p for i in w) for w in wins)

def handle_caro_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    games = _load()
    tid = str(thread_id)

    if len(parts) >= 2 and parts[1].lower() == "new":
        games[tid] = {"board": [0]*9, "turn": 1, "p1": str(author_id), "p2": None}
        _save(games)
        client.replyMessage(Message(text=f"🎮 Đã tạo bàn cờ caro mới!\n{_render([0]*9)}\nNgười chơi 1 (❌): bạn\nGõ .caro <1-9> để đánh"), message_object, thread_id, thread_type)
        return

    if tid not in games:
        client.replyMessage(Message(text="❌ Chưa có trận. Gõ .caro new để tạo."), message_object, thread_id, thread_type)
        return

    game = games[tid]
    if len(parts) < 2:
        client.replyMessage(Message(text=_render(game["board"])), message_object, thread_id, thread_type)
        return

    try:
        pos = int(parts[1]) - 1
        if pos < 0 or pos > 8: raise ValueError
    except:
        client.replyMessage(Message(text="❌ Vị trí phải từ 1-9"), message_object, thread_id, thread_type)
        return

    uid = str(author_id)
    if game["p1"] == uid:
        player_num = 1
    elif game["p2"] is None:
        game["p2"] = uid
        player_num = 2
    elif game["p2"] == uid:
        player_num = 2
    else:
        client.replyMessage(Message(text="❌ Trận đã đủ 2 người chơi."), message_object, thread_id, thread_type)
        return

    if game["turn"] != player_num:
        client.replyMessage(Message(text="❌ Chưa đến lượt bạn!"), message_object, thread_id, thread_type)
        return

    if game["board"][pos] != 0:
        client.replyMessage(Message(text="❌ Ô này đã có người đánh!"), message_object, thread_id, thread_type)
        return

    game["board"][pos] = player_num
    if _check_win(game["board"], player_num):
        del games[tid]
        _save(games)
        client.replyMessage(Message(text=f"{_render(games.get(tid,{}).get('board', game['board']))}\n🎉 Người chơi {player_num} THẮNG!"), message_object, thread_id, thread_type)
        return

    if 0 not in game["board"]:
        del games[tid]
        _save(games)
        client.replyMessage(Message(text=f"{_render(game['board'])}\n🤝 HÒA!"), message_object, thread_id, thread_type)
        return

    game["turn"] = 2 if player_num == 1 else 1
    _save(games)
    client.replyMessage(Message(text=f"{_render(game['board'])}\nLượt của người chơi {game['turn']}"), message_object, thread_id, thread_type)

def PTA():
    return {'caro': handle_caro_command}
