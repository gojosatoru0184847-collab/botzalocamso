# -*- coding: utf-8 -*-
import os
import json
import time
import threading
import random
from zlapi.models import Message, ThreadType

des = {
    'version': "2.1.0",
    'credits': "HOANG LAM",
    'description': "Phát Acc Game (.acclq, .acc lq...) kèm Cooldown 5 phút",
    'power': "Thành viên"
}

RES_BASE = "res/res"
HISTORY_FILE = "data/acc_given_history.json"
COOLDOWN_TIME = 300

ACC_MAP = {
    "acclq": "country/VIET_NAM/valid.txt",
    "accfc": "acc_fc/VIET_NAM.txt",
    "accrank": "country/VIET_NAM/rank_dong_bac_vang_bach_kim_lv10_plus.txt",
    "acctrang": "acc_trang/VIET_NAM.txt",
    "accban": "country/VIET_NAM/acc_ban_khong_trang.txt",
    "lq": "country/VIET_NAM/valid.txt",
    "fc": "acc_fc/VIET_NAM.txt",
    "rank": "country/VIET_NAM/rank_dong_bac_vang_bach_kim_lv10_plus.txt",
    "trang": "acc_trang/VIET_NAM.txt"
}

user_cooldowns = {}
state_lock = threading.Lock()
given_history = set()

def load_history():
    global given_history
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding='utf-8') as f:
                given_history = set(json.load(f))
    except: pass

def save_history():
    try:
        os.makedirs("data", exist_ok=True)
        with open(HISTORY_FILE, "w", encoding='utf-8') as f:
            json.dump(list(given_history), f, indent=4)
    except: pass

load_history()

def get_one_acc(category_path):
    full_path = os.path.join(RES_BASE, category_path)
    if not os.path.exists(full_path): return None
    try:
        with open(full_path, "r", encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
            available = [l.strip() for l in lines if l.strip() and l.strip() not in given_history]
            if available:
                return random.choice(available)
    except: pass
    return None

def handle_acc_commands(message, message_object, thread_id, thread_type, author_id, client):
    global user_cooldowns
    author_id = str(author_id)
    parts = message.split()
    cmd_raw = parts[0][1:].lower()

    target_type = None
    if cmd_raw in ACC_MAP:
        target_type = cmd_raw
    elif cmd_raw == "acc" and len(parts) > 1:
        target_type = parts[1].lower()
        if target_type not in ACC_MAP: target_type = None

    if cmd_raw == "acc" and (len(parts) == 1 or "list" in message.lower()):
        msg = "📜 [ KHO ACC GAME ]\n"
        msg += "━━━━━━━━━━━━━━━━━━━━\n"
        msg += "➜ .acclq hoặc .acc lq\n"
        msg += "➜ .accfc hoặc .acc fc\n"
        msg += "➜ .accrank hoặc .acc rank\n"
        msg += "➜ .acctrang hoặc .acc trang\n"
        msg += "━━━━━━━━━━━━━━━━━━━━\n"
        msg += "💡 Cooldown: 5 phút/lần húp."
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
        return

    if target_type and target_type in ACC_MAP:
        now = time.time()
        user_data = user_cooldowns.get(author_id, {})
        last_time = user_data.get(target_type, 0)

        if now - last_time < COOLDOWN_TIME:
            remain = int(COOLDOWN_TIME - (now - last_time))
            client.replyMessage(Message(text=f"⏳ Đợi thêm {remain//60}p {remain%60}s nữa để húp tiếp nhé!"), message_object, thread_id, thread_type)
            return

        acc_data = get_one_acc(ACC_MAP[target_type])
        if not acc_data:
            client.replyMessage(Message(text="⚠️ Kho này hết hàng rồi Đại ca!"), message_object, thread_id, thread_type)
            return

        with state_lock:
            given_history.add(acc_data)
            save_history()
            if author_id not in user_cooldowns: user_cooldowns[author_id] = {}
            user_cooldowns[author_id][target_type] = now

        msg = f"🎁 [ QUÀ TẶNG {target_type.upper()} ] 🎁\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"🔑 Acc: {acc_data}\n"
        msg += f"━━━━━━━━━━━━━━━━━━━━\n"
        msg += f"🔥 Hàng xịn bốc từ res, chúc Đại ca chơi vui!"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    handlers = {k: handle_acc_commands for k in ACC_MAP.keys()}
    handlers['acc'] = handle_acc_commands
    # Đảm bảo các biến thể .acclq cũng chạy
    for k in ["acclq", "accfc", "accrank", "acctrang", "accban"]:
        handlers[k] = handle_acc_commands
    return handlers

def startup_auto_acc(client): pass
