from zlapi.models import Message
import random, json, os, time
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Trả lời nhanh toán học",'power':"Thành viên"}
ACTIVE = {}

def gen_question(level=1):
    ops = ["+","-","*"] if level > 1 else ["+","-"]
    op = random.choice(ops)
    a = random.randint(1, 20*level); b = random.randint(1, 20*level)
    if op == "*": a = random.randint(1,12); b = random.randint(1,12)
    if op == "-" and b > a: a, b = b, a
    q = f"{a} {op} {b}"
    ans = eval(q)
    return q, ans

def handle_toan_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(); key = f"{thread_id}_{author_id}"
    if len(parts) == 1:
        level = 1
    elif parts[1].isdigit():
        if key in ACTIVE:
            # Đây là câu trả lời
            try:
                ans = float(parts[1])
                g = ACTIVE[key]
                if abs(ans - g["ans"]) < 0.01:
                    elapsed = time.time()-g["time"]
                    del ACTIVE[key]
                    client.replyMessage(Message(text=f"✅ Đúng! {g['q']} = {g['ans']}\nTgian: {elapsed:.1f}s"), message_object, thread_id, thread_type)
                else:
                    client.replyMessage(Message(text=f"❌ Sai! Thử lại: {g['q']} = ?"), message_object, thread_id, thread_type)
                return
            except: pass
        level = int(parts[1])
    q, ans = gen_question(level)
    ACTIVE[key] = {"q": q, "ans": ans, "time": time.time()}
    client.replyMessage(Message(text=f"🧮 Tính nhanh:\n{q} = ?\n\nTrả lời: {PREFIX}toan <đáp án>"), message_object, thread_id, thread_type)

def PTA():
    return {'toan': handle_toan_command}
