# -*- coding: utf-8 -*-
from zlapi.models import Message, ThreadType
import os

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Gửi file war 10000 câu cho Đại ca",
    'power': "Chủ sở hữu Bot"
}

def handle_send_war_file(message, message_object, thread_id, thread_type, author_id, client):
    if not client.is_super_admin(author_id):
        return

    file_path = "data/war_content.txt"

    if os.path.exists(file_path):
        client.replyMessage(Message(text="🚀 Đang gửi file 'kho đạn' 10.000 câu cho Đại ca đây!"), message_object, thread_id, thread_type)
        client.sendLocalFile(file_path, thread_id, thread_type)
    else:
        client.replyMessage(Message(text="❌ Lỗi: Không tìm thấy file data/war_content.txt!"), message_object, thread_id, thread_type)

def PTA():
    return {'getwarfile': handle_send_war_file}
