# -*- coding: utf-8 -*-
import os, json, time, threading, re, urllib.parse, sys, random
from zlapi.models import Message, ThreadType
from config import PREFIX, ADMIN
from core.collect_utils import (
    global_hunted_cache, save_hunted_cache, cache_lock,
    load_collect_settings, save_collect_settings,
    EXT_BLACKLIST, DOMAIN_BLACKLIST, STRICT_HOST_WHITELIST, STRICT_EXT_WHITELIST
)
from modules.blacklist import load_blacklist

des = {
    'version': "8.8.1",
    'credits': "HOANG LAM",
    'description': "MÁY HÚT THÔNG MINH (Chặn Voice AAC/AMR + Chặn Web rác)",
    'power': "Chủ sở hữu Bot"
}

scan_state_lock = threading.Lock()
is_scanning = False

def is_valid_download_link(url):
    url_low = url.lower()
    if any(domain in url_low for domain in DOMAIN_BLACKLIST): return False
    if any(host in url_low for host in STRICT_HOST_WHITELIST): return True
    path = url_low.split('?')[0].split('#')[0]
    if any(path.endswith(ext) for ext in STRICT_EXT_WHITELIST): return True
    return False

def sniff_real_filename(url, title_from_zalo="", file_size=0):
    try:
        decoded_url = urllib.parse.unquote(url)
        clean_url = decoded_url.split('?')[0].split('#')[0].strip('/')
        url_name = os.path.basename(clean_url)

        if url_name and "." in url_name and len(url_name) > 4:
            if not any(x in url_name.lower() for x in ["cqsx", "1wup", "bin?dkey", "voice", "audio"]):
                return url_name

        if title_from_zalo and len(title_from_zalo) > 3:
            if not any(x in title_from_zalo.lower() for x in ["cqsx", "1wup", "voice", "audio"]):
                return title_from_zalo

        return None

    except: pass
    return None

def process_single_message(client, msg_obj, source_thread_id, target_group_id, is_history=False):
    try:
        u_from = str(getattr(msg_obj, 'uidFrom', '0'))
        if u_from == str(client.uid) or str(source_thread_id) == str(target_group_id): return False

        m = msg_obj if isinstance(msg_obj, dict) else (msg_obj.toDict() if hasattr(msg_obj, 'toDict') else vars(msg_obj))

        raw_mt = str(m.get('msgType') or getattr(msg_obj, 'msgType', 0))
        if any(x in raw_mt.lower() for x in ['reaction', 'delete', 'undo']): return False
        # Chặn các loại tin nhắn không phải file/link (2: ảnh, 3: video, 4: voice, 1: text nhưng có thể kèm link)
        if str(raw_mt) in ["2", "3", "4", "chat.photo", "chat.video", "chat.voice"]: return False

        data_to_check = []
        if m.get('attachments'):
            for att in m['attachments']:
                if isinstance(att, dict):
                    data_to_check.append(att)

        content_raw = str(m.get('content') or m.get('text') or "")
        if "http" in content_raw:
            found_links = re.findall(r'(https?://[^\s\)\*\"\'\,]+)', content_raw)
            for link in found_links:
                if is_valid_download_link(link):
                    data_to_check.append({'href': link, 'title': "", 'is_raw_link': True})

        found_any = False
        for item in data_to_check:
            href = item.get('href') or item.get('url') or item.get('oriUrl')
            if not href: continue

            f_size = int(item.get('fileSize') or item.get('size') or 0)
            z_title = str(item.get('title') or item.get('name') or "").lower()

            # --- CHỐT CHẶN VOICE & RÁC ---
            if any(bad in z_title for bad in ["voice_", "aac", "amr", "m4a", "opus", "mp3"]): continue
            if any(z_title.endswith(ext) for ext in EXT_BLACKLIST): continue

            real_name = sniff_real_filename(href, z_title, f_size)
            if not real_name: continue # CHẶN HÀNG KHÔNG TÊN (Thường là rác)

            real_name_low = real_name.lower()
            if any(real_name_low.endswith(ext) for ext in EXT_BLACKLIST): continue

            file_uid = item.get('checksum') or item.get('md5') or href
            with cache_lock:
                if file_uid in global_hunted_cache: continue
                global_hunted_cache.add(file_uid)
                save_hunted_cache(global_hunted_cache)

            try:
                res = client.forwardFile(item, target_group_id, ThreadType.GROUP)
                if not (res and isinstance(res, dict) and res.get('error_code') == 0):
                    ext = real_name.split('.')[-1] if '.' in real_name else "zip"
                    client.sendRemoteFile(href, target_group_id, ThreadType.GROUP, fileName=real_name, extension=ext)

                found_any = True
                print(f"💎 [HÀNG VỀ] {real_name}", flush=True)
                if not is_history: time.sleep(0.3)
            except: pass

        return found_any
    except: return False

def handle_getfile_command(message, message_object, thread_id, thread_type, author_id, client):
    global is_scanning
    if not client.is_super_admin(author_id): return
    settings = load_collect_settings()
    parts = message.split()

    if len(parts) > 1 and parts[1].lower() == "scan":
        count_limit = 2000
        if len(parts) > 2 and parts[2].isdigit(): count_limit = int(parts[2])
        with scan_state_lock:
            if is_scanning: return
            is_scanning = True

        target_group = settings.get("share_to_group") or str(thread_id)
        client.replyMessage(Message(text=f"🌪️ [ VÉT CẠN 8.8.1 ] Đang lùng hàng xịn, chặn đứng voice rác..."), message_object, thread_id, thread_type)

        def run_all_scan(active_client, target_gid):
            global is_scanning
            try:
                all_groups_res = active_client.fetchAllGroups()
                tids = list(all_groups_res.gridVerMap.keys())
                total = 0
                for idx, tid in enumerate(tids):
                    if str(tid) == str(target_gid) or str(tid) in load_blacklist(): continue
                    try:
                        last_mid = 0
                        for p in range((count_limit // 50) + 1):
                            history = active_client.getRecentGroup(tid, count=50, lastMsgId=last_mid)
                            if not history or not hasattr(history, 'groupMsgs') or not history.groupMsgs: break
                            for m in history.groupMsgs:
                                if process_single_message(active_client, m, str(tid), target_gid, is_history=True):
                                    total += 1
                            last_mid = history.groupMsgs[-1].get('msgId')
                            time.sleep(1.2)
                    except: pass
                active_client.sendMessage(Message(text=f"✅ [ XONG ] Đã dọn sạch voice và bế {total} hàng Đỉnh về kho!"), target_gid, ThreadType.GROUP)
            finally:
                with scan_state_lock: is_scanning = False

        threading.Thread(target=run_all_scan, args=(client, target_group), daemon=True).start()
        return

    settings.update({"enabled": True, "share_to_group": str(thread_id)})
    save_collect_settings(settings)
    client.replyMessage(Message(text=f"🌪️ MÁY HÚT KIM CƯƠNG v8.8.1\n🚀 Đã CHẶN ĐỨNG voice (.aac, .m4a) và link web rác!"), message_object, thread_id, thread_type)

def PTA(): return {'getfile': handle_getfile_command}

def process_incoming_files(client, message_object, thread_id, thread_type):
    settings = load_collect_settings()
    target_group = settings.get("share_to_group")
    if settings.get("enabled") and target_group and str(thread_id) != str(target_group) and str(thread_id) not in load_blacklist():
        process_single_message(client, message_object, str(thread_id), target_group)
