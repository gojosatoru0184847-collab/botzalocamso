# -*- coding: utf-8 -*-
import os
import json
import time
import threading
import tempfile
from zlapi.models import Message
from config import API_KEY, SECRET_KEY, PREFIX

des = {
    'version': "3.0.0",
    'credits': "HOANG LAM",
    'description': "Lệnh .qr: Treo bot hộ (Nhân bản Bot). Người quét sẽ thành Bot phụ và được cấp quyền Admin.",
    'power': "Admin chính"
}

SUB_BOTS_FILE = "database/sub_bots.json"
os.makedirs("database", exist_ok=True)

def handle_qr_clone(message, message_object, thread_id, thread_type, author_id, client):
    # Kiểm tra quyền Admin chính
    with open('seting.json', 'r', encoding='utf-8') as f:
        config = json.load(f)

    if str(author_id) != str(config.get('admin')):
        return client.replyMessage(Message(text="⚠️ Chỉ Đại ca mới có quyền tạo mã nhân bản Bot!"), message_object, thread_id, thread_type)

    client.replyMessage(Message(text="⌛ Đang khởi tạo mã QR nhân bản..."), message_object, thread_id, thread_type)

    def on_qr_generated(qr_path):
        try:
            with open(qr_path, "rb") as f:
                client.sendLocalImage(
                    qr_path,
                    thread_id=thread_id,
                    thread_type=thread_type,
                    message=Message(text="💠 MÃ QUÉT NHÂN BẢN BOT\n\n1. Dùng Zalo trên điện thoại quét mã này.\n2. Sau khi xác nhận, tài khoản của bạn sẽ biến thành Bot phụ.\n3. Bạn sẽ tự động được cấp quyền Admin Bot.\n\n⚠️ Mã có hiệu lực trong 45 giây.")
                )
        except Exception as e:
            print(f"Lỗi gửi QR: {e}")

    def clone_process():
        try:
            from zlapi import ZaloAPI
            from zlapi import _state

            # Tạo client tạm để login
            temp_client = ZaloAPI.__new__(ZaloAPI)
            temp_client._state = _state.State()
            temp_client._condition = threading.Event()
            temp_client._listening = False

            qr_temp_path = os.path.join(tempfile.gettempdir(), f"qr_clone_{int(time.time())}.png")

            # Tiến hành login với QR
            session_data = temp_client.loginWithQR(
                qr_path=qr_temp_path,
                on_qr_generated=on_qr_generated
            )

            if session_data:
                new_uid = temp_client.uid
                new_cookies = temp_client.getSession()
                new_imei = temp_client._imei

                # 1. Cấp quyền Admin cho người quét
                with open('seting.json', 'r', encoding='utf-8') as f:
                    data = json.load(f)

                if 'adm' not in data: data['adm'] = []
                if str(new_uid) not in [str(x) for x in data['adm']]:
                    data['adm'].append(str(new_uid))
                    with open('seting.json', 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=4, ensure_ascii=False)

                # 2. Lưu session vào database để khởi động lại sau này
                sub_bots = {}
                if os.path.exists(SUB_BOTS_FILE):
                    try:
                        with open(SUB_BOTS_FILE, 'r') as f: sub_bots = json.load(f)
                    except: pass

                sub_bots[str(new_uid)] = {
                    "cookies": new_cookies,
                    "imei": new_imei
                }
                with open(SUB_BOTS_FILE, 'w') as f: json.dump(sub_bots, f)

                client.send(Message(text=f"✅ NHÂN BẢN THÀNH CÔNG!\n🚀 Tài khoản UID: {new_uid} đã trở thành Bot phụ.\n⚙️ Đã tự động cấp quyền Admin cho bạn."), thread_id, thread_type)

                # 3. Chạy Bot phụ ngay lập tức
                # Import Client từ main để có đầy đủ tính năng của bot bạn đang dùng
                from main import Client as BotInstance
                new_bot = BotInstance(API_KEY, SECRET_KEY, new_imei, new_cookies)
                threading.Thread(target=new_bot.listen, daemon=True, name=f"SubBot-{new_uid}").start()

            else:
                client.send(Message(text="❌ Quá trình nhân bản thất bại hoặc hết thời gian."), thread_id, thread_type)

            # Dọn dẹp
            if os.path.exists(qr_temp_path): os.remove(qr_temp_path)

        except Exception as e:
            print(f"Lỗi Clone Process: {e}")
            client.send(Message(text=f"❌ Lỗi hệ thống: {str(e)}"), thread_id, thread_type)

    threading.Thread(target=clone_process, daemon=True).start()

def PTA():
    return {
        'qr': handle_qr_clone
    }
