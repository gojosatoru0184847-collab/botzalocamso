from zlapi.models import Message
import unicodedata

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Bỏ dấu tiếng Việt", 'power': "Thành viên"}

def handle_bodau_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="🔤 Dùng: .bodau <văn bản tiếng Việt>"), message_object, thread_id, thread_type)
        return
    text = parts[1]
    text = unicodedata.normalize('NFKD', text)
    result = ''.join(c for c in text if not unicodedata.combining(c))
    result = result.replace('đ', 'd').replace('Đ', 'D')
    client.replyMessage(Message(text=result), message_object, thread_id, thread_type)

def PTA():
    return {'bodau': handle_bodau_command}
