from zlapi.models import Message, Mention, ThreadType
import requests
import json
import os
import time
import logging
from io import BytesIO
from PIL import Image
import threading
from config import PREFIX

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

des = {
    'version': "2.2.0",
    'credits': "HOANG LAM",
    'description': "Tìm kiếm video/ảnh từ TikTok theo từ khóa (API Fix)",
    'power': "Thành viên"
}

def handle_stiktok_command(message, message_object, thread_id, thread_type, author_id, client):
    text = message.split(maxsplit=1)
    if len(text) < 2 or not text[1].strip():
        client.sendMessage(
            Message(text=f"Vui lòng nhập từ khóa tìm kiếm! Ví dụ: {PREFIX}stiktok cosplay"),
            thread_id, thread_type, ttl=60000
        )
        return
    
    keywords = text[1].strip()
    # API mới ổn định hơn thay cho API cũ đã hỏng
    api_url = f"https://www.tikwm.com/api/feed/search?keywords={keywords}&count=12&cursor=0"
    
    try:
        client.sendMessage(
            Message(text=f"Đang tìm kiếm video TikTok với từ khóa: '{keywords}'..."),
            thread_id, thread_type, ttl=60000
        )
        
        response = requests.get(api_url, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if data.get("code") == 0 and data.get("data") and "videos" in data["data"]:
            videos = data["data"]["videos"]
            if len(videos) > 0:
                # Lấy video đầu tiên từ kết quả trả về
                process_result(client, thread_id, thread_type, author_id, videos[0], keywords)
            else:
                client.sendMessage(
                    Message(text=f"Không tìm thấy kết quả cho từ khóa: '{keywords}'"),
                    thread_id, thread_type, ttl=12000
                )
        else:
            client.sendMessage(
                Message(text=f"Lỗi khi lấy dữ liệu từ API TikTok."),
                thread_id, thread_type, ttl=12000
            )
    
    except Exception as e:
        logger.error(f"Lỗi trong handle_stiktok_command: {str(e)}")
        client.sendMessage(
            Message(text=f"Lỗi hệ thống: {str(e)}"),
            thread_id, thread_type, ttl=12000
        )

def process_result(client, thread_id, thread_type, author_id, item, keywords):
    try:
        title = item.get("title", "Không có tiêu đề")
        play_url = item.get("play") # Link video không logo
        cover_url = item.get("cover")

        author = item.get("author", {})
        nickname = author.get("nickname", "Người dùng TikTok")

        views = item.get("play_count", 0)
        likes = item.get("digg_count", 0)
        comments = item.get("comment_count", 0)

        info_text = f"🔍 Kết quả cho: '{keywords}'\n👤 Tác giả: {nickname}\n📝: {title}\n\n"
        info_text += f"👁️ {views:,} | ❤️ {likes:,} | 💬 {comments:,}"
        
        client.sendMessage(
            Message(text="Đang tải video, vui lòng đợi giây lát..."),
            thread_id, thread_type, ttl=30000
        )
        
        # Mặc định kích thước video TikTok
        video_width = 720
        video_height = 1280
        duration = item.get("duration", 15) * 1000

        client.sendRemoteVideo(
            videoUrl=play_url,
            thumbnailUrl=cover_url,
            duration=duration,
            thread_id=thread_id,
            thread_type=thread_type,
            width=video_width,
            height=video_height,
            message=Message(text=info_text),
            ttl=240000
        )
                
    except Exception as e:
        logger.error(f"Lỗi trong process_result: {str(e)}")
        client.sendMessage(
            Message(text=f"Đã xảy ra lỗi khi xử lý video: {str(e)}"),
            thread_id, thread_type, ttl=12000
        )

def PTA():
    return {
        'stiktok': handle_stiktok_command,
        'searchtiktok': handle_stiktok_command
    }
