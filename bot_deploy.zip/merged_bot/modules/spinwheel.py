from zlapi.models import Message
import random
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Quay vòng quay may mắn",'power':"Thành viên"}

def handle_spinwheel_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text=f"🎡 Dùng: {PREFIX}spinwheel <mục1> | <mục2> | ...\nVí dụ: {PREFIX}spinwheel Pizza | Bún bò | Phở | Cơm tấm"), message_object, thread_id, thread_type)
        return
    items = [x.strip() for x in parts[1].split("|") if x.strip()]
    if len(items) < 2:
        client.replyMessage(Message(text="❌ Cần ít nhất 2 mục (cách nhau bởi |)"), message_object, thread_id, thread_type); return
    winner = random.choice(items)
    list_text = "\n".join(f"  {'🎯' if i==items.index(winner) else '⚪'} {item}" for i,item in enumerate(items))
    msg = f"🎡 VÒNG QUAY MAY MẮN\n━━━━━━━━━━━━━━━\n{list_text}\n━━━━━━━━━━━━━━━\n🏆 Kết quả: {winner}"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'spinwheel': handle_spinwheel_command}
