import os
import requests
import tempfile
from PIL import Image
from zlapi.models import Message

des = {
    'version': "1.1.0",
    'credits': "HOANG LAM",
    'description': "Tra thông tin Anime & Gửi ảnh trực tiếp",
    'power': "Thành viên"
}

def handle_anime_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="🎌 Dùng: .anime <tên anime>"), message_object, thread_id, thread_type)
        return

    name = parts[1]
    temp_path = None

    try:
        r = requests.get(f"https://api.jikan.moe/v4/anime?q={name}&limit=1", timeout=10)
        data = r.json()["data"]
        if not data:
            raise ValueError("Không tìm thấy anime này.")

        a = data[0]
        title = a.get('title', 'N/A')
        msg = (
            f"🎌 {title}\n━━━━━━━━━━━━━━━\n"
            f"• Điểm: {a.get('score','N/A')}\n"
            f"• Số tập: {a.get('episodes','N/A')}\n"
            f"• Trạng thái: {a.get('status','N/A')}\n"
            f"• Thể loại: {', '.join(g['name'] for g in a.get('genres',[]))}\n"
            f"• Tóm tắt: {(a.get('synopsis') or '')[:300]}..."
        )

        # Gửi thông tin văn bản trước
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

        # Xử lý và gửi ảnh
        img_url = a.get("images",{}).get("jpg",{}).get("large_image_url") or a.get("images",{}).get("jpg",{}).get("image_url")
        if img_url:
            response = requests.get(img_url, timeout=15)
            if response.status_code == 200:
                with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tf:
                    tf.write(response.content)
                    temp_path = tf.name

                with Image.open(temp_path) as img:
                    width, height = img.size

                client.sendLocalImage(
                    temp_path,
                    thread_id=thread_id,
                    thread_type=thread_type,
                    width=width,
                    height=height,
                    message=Message(text=f"🖼️ Poster: {title}")
                )

    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {str(e)}"), message_object, thread_id, thread_type)
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)

def PTA():
    return {'anime': handle_anime_command}
