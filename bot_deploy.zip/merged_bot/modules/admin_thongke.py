from zlapi.models import Message
import json, os

des = {'version': "1.0.0", 'credits': "HOANG LAM", 'description': "Thống kê hoạt động nhóm", 'power': "Thành viên"}

STATS_FILE = "modules/cache/data/msg_stats.json"

def _load():
    try:
        with open(STATS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def handle_thongke_command(message, message_object, thread_id, thread_type, author_id, client):
    stats = _load()
    tid = str(thread_id)
    if tid not in stats or not stats[tid]:
        client.replyMessage(Message(text="📊 Chưa có dữ liệu thống kê cho nhóm này."), message_object, thread_id, thread_type)
        return
    top = sorted(stats[tid].items(), key=lambda x: x[1], reverse=True)[:10]
    lines = []
    for i, (uid, count) in enumerate(top, 1):
        try:
            info = client.fetchUserInfo(uid)
            name = info.changed_profiles.get(uid, {}).get('zaloName', uid)
        except:
            name = uid
        lines.append(f"{i}. {name}: {count} tin nhắn")
    msg = "📊 TOP HOẠT ĐỘNG NHÓM\n━━━━━━━━━━━━━━━\n" + "\n".join(lines)
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'thongke': handle_thongke_command, 'topgr': handle_thongke_command}
