from zlapi.models import Message
import random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Công cụ random: số, lựa chọn, xáo trộn", 'power': "Thành viên"}

def handle_random_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 3:
        client.replyMessage(Message(text="🎲 Dùng: .random <min> <max>"), message_object, thread_id, thread_type)
        return
    try:
        a, b = int(parts[1]), int(parts[2])
        result = random.randint(min(a,b), max(a,b))
        client.replyMessage(Message(text=f"🎲 Số ngẫu nhiên: {result}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def handle_chon_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2 or "," not in parts[1]:
        client.replyMessage(Message(text="🎯 Dùng: .chon <lựa chọn 1>,<lựa chọn 2>,..."), message_object, thread_id, thread_type)
        return
    options = [o.strip() for o in parts[1].split(",") if o.strip()]
    if len(options) < 2:
        client.replyMessage(Message(text="❌ Cần ít nhất 2 lựa chọn."), message_object, thread_id, thread_type)
        return
    choice = random.choice(options)
    client.replyMessage(Message(text=f"🎯 Bot chọn: {choice}"), message_object, thread_id, thread_type)

def handle_xaotron_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2 or "," not in parts[1]:
        client.replyMessage(Message(text="🔀 Dùng: .xaotron <item1>,<item2>,..."), message_object, thread_id, thread_type)
        return
    items = [o.strip() for o in parts[1].split(",") if o.strip()]
    random.shuffle(items)
    client.replyMessage(Message(text=f"🔀 Kết quả: {', '.join(items)}"), message_object, thread_id, thread_type)

def handle_coinflip_command(message, message_object, thread_id, thread_type, author_id, client):
    result = random.choice(["Mặt sấp 🪙", "Mặt ngửa 🪙"])
    client.replyMessage(Message(text=f"🪙 Kết quả tung xu: {result}"), message_object, thread_id, thread_type)

def PTA():
    return {
        'random': handle_random_command,
        'chon': handle_chon_command,
        'xaotron': handle_xaotron_command,
        'tungxu': handle_coinflip_command,
        'coinflip': handle_coinflip_command,
    }
