from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Máy tính cơ bản", 'power': "Thành viên"}

def handle_calc_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="🧮 Dùng: .calc <biểu thức>\nVí dụ: .calc 5*(3+2)"), message_object, thread_id, thread_type)
        return
    expr = parts[1]
    allowed = set("0123456789+-*/(). ")
    if not all(c in allowed for c in expr):
        client.replyMessage(Message(text="❌ Biểu thức chỉ được chứa số và +-*/()."), message_object, thread_id, thread_type)
        return
    try:
        result = eval(expr, {"__builtins__": {}}, {})
        client.replyMessage(Message(text=f"🧮 {expr} = {result}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi tính toán: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'calc': handle_calc_command, 'tinh': handle_calc_command}
