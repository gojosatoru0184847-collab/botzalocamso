import json
import re
import os
import tempfile
import requests
import threading
from zlapi.models import Message
from pydub import AudioSegment

des = {
    'version': "1.2.1",
    'credits': "HOANG LAM",
    'description': "Chuyển video thành tin nhắn thoại (Bản sửa lỗi khóa file Windows)",
    'power': "Thành viên"
}

def extract_url(text):
    url_pattern = r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+[/\w\.-]*\??[\w=&]*'
    match = re.search(url_pattern, text)
    return match.group(0) if match else None

def handle_getvoice_command(message, message_object, thread_id, thread_type, author_id, client):
    url = extract_url(message)
    if not url and message_object.quote:
        attach = message_object.quote.attach
        if attach:
            try:
                data = json.loads(attach)
                url = data.get('hdUrl') or data.get('href')
            except: pass
        if not url:
            quote_text = getattr(message_object.quote, 'text', '') or getattr(message_object.quote, 'content', '')
            if isinstance(quote_text, str): url = extract_url(quote_text)

    if not url:
        return client.replyMessage(Message(text="⚠️ Vui lòng reply video hoặc gửi link video."), message_object, thread_id, thread_type)

    client.replyMessage(Message(text="⏳ Đang tải và chuyển đổi âm thanh..."), message_object, thread_id, thread_type)

    temp_video = None
    temp_aac = None

    try:
        # Tải video
        res = requests.get(url, timeout=40, stream=True)
        res.raise_for_status()

        cache_dir = "modules/cache/voice_temp"
        os.makedirs(cache_dir, exist_ok=True)

        fd_v, temp_video = tempfile.mkstemp(suffix=".mp4", dir=cache_dir)
        os.close(fd_v)

        with open(temp_video, 'wb') as f:
            f.write(res.content)
            
        fd_a, temp_aac = tempfile.mkstemp(suffix=".aac", dir=cache_dir)
        os.close(fd_a)

        # Chuyển đổi
        audio = AudioSegment.from_file(temp_video)
        audio.export(temp_aac, format="adts")

        # Gửi trực tiếp qua Zalo
        success = False
        if hasattr(client, 'sendLocalVoice'):
            try:
                res_zalo = client.sendLocalVoice(temp_aac, thread_id, thread_type)
                if res_zalo and (hasattr(res_zalo, 'msgId') or (isinstance(res_zalo, dict) and 'fileId' in res_zalo)):
                    success = True
            except: pass

        if not success:
            # Fallback sang Catbox
            with open(temp_aac, 'rb') as f:
                up = requests.post("https://catbox.moe/user/api.php", data={'reqtype':'fileupload'}, files={'fileToUpload': f}, timeout=25)
                voice_url = up.text.strip()
                if voice_url.startswith('http'):
                    client.sendRemoteVoice(voice_url, thread_id, thread_type)

    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {str(e)}"), message_object, thread_id, thread_type)
    finally:
        # Xóa file tạm với độ trễ
        def cleanup():
            for f in [temp_video, temp_aac]:
                if f and os.path.exists(f):
                    try: os.remove(f)
                    except: pass
        threading.Timer(20, cleanup).start()

def PTA():
    return {'getvoice': handle_getvoice_command}
