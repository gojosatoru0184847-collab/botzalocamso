from zlapi.models import Message
import os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Liệt kê tổng số lệnh đang có", 'power': "Thành viên"}

def handle_tonglenh_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        total = len(client.command_handler.PTA)
        msg = f"📋 Bot hiện có {total} lệnh đang hoạt động.\nGõ .menu để xem chi tiết từng nhóm lệnh."
    except Exception:
        msg = "📋 Không thể lấy số lượng lệnh."
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'tonglenh': handle_tonglenh_command, 'countcmd': handle_tonglenh_command}
