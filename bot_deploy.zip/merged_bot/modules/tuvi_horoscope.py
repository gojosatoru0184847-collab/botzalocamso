from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Xem tử vi 12 con giáp hôm nay", 'power': "Thành viên"}

ZODIAC_VI = {
    "ty": "Tý", "suu": "Sửu", "dan": "Dần", "mao": "Mão", "thin": "Thìn",
    "ti": "Tỵ", "ngo": "Ngọ", "mui": "Mùi", "than": "Thân", "dau": "Dậu",
    "tuat": "Tuất", "hoi": "Hợi"
}

MESSAGES = [
    "Hôm nay là ngày may mắn về tài lộc, hãy chủ động trong công việc.",
    "Tình cảm có dấu hiệu khởi sắc, nên dành thời gian cho người thân.",
    "Cẩn trọng trong giao tiếp, tránh tranh luận không cần thiết.",
    "Sức khỏe ổn định, nên duy trì vận động nhẹ.",
    "Công việc thuận lợi nếu biết lắng nghe góp ý từ đồng nghiệp.",
    "Tài chính cần thận trọng, tránh đầu tư mạo hiểm hôm nay.",
]

def handle_tuvi_command(message, message_object, thread_id, thread_type, author_id, client):
    import random, hashlib
    from datetime import date
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="🔮 Dùng: .tuvi <con giáp>\nVí dụ: .tuvi ty, .tuvi than..."), message_object, thread_id, thread_type)
        return
    zodiac_key = parts[1].lower()
    if zodiac_key not in ZODIAC_VI:
        client.replyMessage(Message(text="❌ Con giáp không hợp lệ. (ty, suu, dan, mao, thin, ti, ngo, mui, than, dau, tuat, hoi)"), message_object, thread_id, thread_type)
        return
    seed = f"{zodiac_key}{date.today()}"
    random.seed(int(hashlib.md5(seed.encode()).hexdigest(), 16))
    msg_text = random.choice(MESSAGES)
    luck = random.randint(60, 100)
    msg = f"🔮 TỬ VI {ZODIAC_VI[zodiac_key].upper()} HÔM NAY\n━━━━━━━━━━━━━━━\n• Vận may: {luck}%\n• {msg_text}"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'tuvi': handle_tuvi_command}
