# -*- coding: utf-8 -*-
import os
import random
import tempfile
from zlapi.models import Message, MultiMsgStyle, MessageStyle
from config import PREFIX, ADMIN
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FONT_PATH = "modules/cache/font/BeVietnamPro-Bold.ttf"
BG_DIR = "modules/cache/backgrounds"
CACHE_DIR = "modules/cache/acclq_temp"

os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(BG_DIR, exist_ok=True)

des = {
    'version': "2.0.3",
    'credits': "HOANG LAM",
    'description': "Gửi ngẫu nhiên tài khoản Liên Quân",
    'power': "Thành viên"
}

ACCOUNT_FILE = "lq.txt"
MAX_ACCOUNTS = 7

def read_accounts(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except:
        return []

def get_font(size):
    try:
        return ImageFont.truetype(FONT_PATH, size)
    except:
        return ImageFont.load_default()

def get_bg(size):
    try:
        imgs = [f for f in os.listdir(BG_DIR) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        if imgs:
            bg = Image.open(os.path.join(BG_DIR, random.choice(imgs))).convert("RGBA").resize(size, Image.LANCZOS)
        else:
            bg = Image.new("RGBA", size, (25, 25, 50, 255))
    except:
        bg = Image.new("RGBA", size, (25, 25, 50, 255))
    return bg

def save_temp(img):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmp:
        img.convert("RGB").save(tmp.name, "JPEG", quality=95)
        return tmp.name

def draw_account_image(name, accounts):
    WIDTH, HEIGHT = 1080, 900
    bg = get_bg((WIDTH, HEIGHT))
    draw = ImageDraw.Draw(bg)

    title_font = get_font(70)
    small_font = get_font(40)
    acc_font = get_font(42)

    title = "Tài Khoản Liên Quân"
    draw.text(
        (WIDTH//2 - title_font.getlength(title)//2, 60),
        title, font=title_font, fill=(255, 255, 255, 255),
        stroke_width=3, stroke_fill=(0, 0, 0, 160)
    )

    name_text = f"👤 {name}"
    draw.text(
        (WIDTH//2 - small_font.getlength(name_text)//2, 150),
        name_text, font=small_font, fill=(220, 30, 30, 255),
        stroke_width=2, stroke_fill=(0, 0, 0, 180)
    )

    box_x0, box_y0, box_x1, box_y1 = 100, 250, WIDTH - 100, HEIGHT - 100
    overlay = Image.new("RGBA", bg.size, (0, 0, 0, 0))
    box = ImageDraw.Draw(overlay)
    box.rounded_rectangle([box_x0, box_y0, box_x1, box_y1], radius=40, fill=(0, 0, 0, 90))
    glow = overlay.filter(ImageFilter.GaussianBlur(8))
    bg.alpha_composite(glow)
    draw.rounded_rectangle([box_x0, box_y0, box_x1, box_y1], radius=40, outline=(173, 216, 230, 230), width=3)

    y = box_y0 + 40
    for i, acc in enumerate(accounts, 1):
        text = f"{i}. {acc}"
        draw.text((box_x0 + 50, y), text, font=acc_font, fill=(240, 240, 255, 255),
                  stroke_width=2, stroke_fill=(0, 0, 0, 150))
        y += acc_font.size + 20
        if y > box_y1 - 80:
            break

    footer = "🤖 Bot by HOANG LAM"
    draw.text((WIDTH//2 - small_font.getlength(footer)//2, HEIGHT - 60),
              footer, font=small_font, fill=(180, 220, 255, 240),
              stroke_width=2, stroke_fill=(0, 0, 0, 150))

    return save_temp(bg)

def handle_send_accounts_command(message, message_object, thread_id, thread_type, author_id, client):
    user_info = client.fetchUserInfo(author_id)
    author_info = user_info.changed_profiles.get(str(author_id), {}) if user_info and user_info.changed_profiles else {}
    name = author_info.get("zaloName", "Người dùng")

    try:
        num = int(message.split()[1])
    except:
        msg = f"{name}\n➜ Dùng: {PREFIX}acclq [số lượng]\nVí dụ: {PREFIX}acclq 7"
        style = MultiMsgStyle([
            MessageStyle(offset=0, length=len(name), style="color", color="#db342e", auto_format=False)
        ])
        client.replyMessage(Message(text=msg, style=style), message_object, thread_id, thread_type, ttl=15000)
        return

    accounts = read_accounts(ACCOUNT_FILE)
    if not accounts:
        msg = f"{name}\n➜ Không thể đọc danh sách tài khoản từ file!"
        style = MultiMsgStyle([
            MessageStyle(offset=0, length=len(name), style="color", color="#db342e", auto_format=False)
        ])
        client.replyMessage(Message(text=msg, style=style), message_object, thread_id, thread_type, ttl=10000)
        return

    if num > MAX_ACCOUNTS:
        try:
            client.replyMessage(Message(text=f"🎮 Số lượng tối đa là {MAX_ACCOUNTS}. Mình sẽ gửi {MAX_ACCOUNTS} tài khoản."), message_object, thread_id, thread_type, ttl=7000)
        except:
            pass
        num = MAX_ACCOUNTS

    num = min(num, len(accounts))
    selected = random.sample(accounts, num)
    img_path = draw_account_image(name, selected)

    try:
        client.sendLocalImage(img_path, thread_id=thread_id, thread_type=thread_type, ttl=60000)
        client.sendReaction(message_object, "🎮", thread_id, thread_type)
    except:
        client.replyMessage(Message(text="⚠️ Gửi ảnh thất bại."), message_object, thread_id, thread_type)
    finally:
        if os.path.exists(img_path):
            os.remove(img_path)

def PTA():
    return {
        'acclq': handle_send_accounts_command
    }