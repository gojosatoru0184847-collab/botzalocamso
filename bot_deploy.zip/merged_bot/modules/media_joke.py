from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Truyện cười ngẫu nhiên", 'power': "Thành viên"}

JOKES = [
    "Tại sao con cá không chơi tennis? Vì sợ bị mắc lưới! 🐟",
    "Sếp hỏi: Sao đi làm muộn? Tôi đáp: Vì đường rất đông. Sếp: Sao người khác đến đúng giờ? Tôi: Vì họ đi sớm hơn đường đông! 😂",
    "Con hỏi: Bố ơi tại sao mưa rơi? Bố: Vì gió không nâng được nó nữa! ☔",
    "Người yêu cũ giống Wifi công cộng: ai cũng từng kết nối, nhưng tín hiệu rất yếu! 📶",
    "Tại sao máy tính bị lạnh? Vì nó để quên Windows mở! 🪟",
]

def handle_joke_command(message, message_object, thread_id, thread_type, author_id, client):
    import random
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Any?lang=en&blacklistFlags=nsfw,racist,sexist", timeout=8)
        data = r.json()
        if data.get("type") == "single":
            msg = "😂 " + data["joke"]
        else:
            msg = f"😂 {data['setup']}\n{data['delivery']}"
    except Exception:
        msg = random.choice(JOKES)
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'joke': handle_joke_command, 'truyencuoi': handle_joke_command}
