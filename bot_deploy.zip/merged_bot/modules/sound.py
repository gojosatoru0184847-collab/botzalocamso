from zlapi.models import Message
import requests
import os

des = {
    'version': "1.1.0",
    'credits': "UltraBot",
    'description': "Tải nhạc từ SoundCloud/YouTube link",
    'power': "Thành viên"
}

def handle_sound_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()
    if len(content) < 2:
        client.replyMessage(Message(text="🎵 Dùng: .sound <link SoundCloud hoặc YouTube>\nVí dụ: .sound https://soundcloud.com/..."), message_object, thread_id, thread_type)
        return
    url = content[1].strip()
    if not url.startswith("https://"):
        client.replyMessage(Message(text="❌ Link không hợp lệ. Cần link bắt đầu bằng https://"), message_object, thread_id, thread_type)
        return
    try:
        client.replyMessage(Message(text="⏳ Đang xử lý tải nhạc..."), message_object, thread_id, thread_type)
        # Dùng API cobalt.tools
        api_url = "https://api.cobalt.tools/api/json"
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        payload = {"url": url, "aFormat": "mp3", "isAudioOnly": True}
        r = requests.post(api_url, json=payload, headers=headers, timeout=30)
        data = r.json()
        if data.get("status") in ("stream", "redirect", "tunnel"):
            audio_url = data.get("url")
            client.sendRemoteVoice(audio_url, thread_id, thread_type)
        else:
            raise ValueError(data.get("text","Không tải được"))
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi tải nhạc: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'sound': handle_sound_command}
