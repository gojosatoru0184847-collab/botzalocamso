from zlapi.models import Message
import json, os, random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Trò chơi đoán chữ Hangman", 'power': "Thành viên"}

WORDS = [
    ("vietnam","quốc gia Đông Nam Á"),("football","môn thể thao vua"),
    ("python","ngôn ngữ lập trình"),("rainbow","hiện tượng thiên nhiên sau mưa"),
    ("elephant","động vật lớn nhất trên cạn"),("galaxy","tập hợp hàng tỷ ngôi sao"),
    ("butterfly","côn trùng có cánh đẹp"),("mountain","địa hình cao nhất"),
    ("chocolate","đồ ăn ngọt từ ca cao"),("internet","mạng lưới toàn cầu"),
]
GAME_FILE = "modules/cache/data/hangman.json"

def _load():
    try:
        with open(GAME_FILE, encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

STAGES = ["😵","😱","😰","😨","😟","😐","🙂"]

def _render(g):
    word = g["word"]
    guessed = set(g["guessed"])
    display = " ".join(c if c in guessed else "_" for c in word)
    wrong = [c for c in guessed if c not in word]
    hp = max(0, 6 - len(wrong))
    return f"{STAGES[hp]} HP: {hp}/6\n{display}\nĐã đoán sai: {', '.join(wrong) or 'chưa có'}"

def _play(message, message_object, thread_id, thread_type, author_id, client):
    games = _load()
    tid = str(thread_id)
    p = message.strip().split(maxsplit=1)

    if len(p) < 2 or p[1].lower() == "new":
        word, hint = random.choice(WORDS)
        games[tid] = {"word": word, "guessed": [], "hint": hint}
        _save(games)
        display = " ".join("_" for _ in word)
        client.replyMessage(Message(text=f"🎭 HANGMAN\nGợi ý: {hint}\n{display}\nGõ .hangman <chữ cái> để đoán"), message_object, thread_id, thread_type)
        return

    if tid not in games:
        client.replyMessage(Message(text="❌ Chưa có game. Gõ .hangman new"), message_object, thread_id, thread_type)
        return

    g = games[tid]
    guess = p[1].strip().lower()

    if len(guess) == 1 and guess.isalpha():
        if guess in g["guessed"]:
            client.replyMessage(Message(text=f"⚠️ Chữ '{guess}' đã đoán rồi!"), message_object, thread_id, thread_type)
            return
        g["guessed"].append(guess)
        wrong = [c for c in g["guessed"] if c not in g["word"]]
        if all(c in g["guessed"] for c in g["word"]):
            del games[tid]; _save(games)
            client.replyMessage(Message(text=f"🎉 Thắng! Từ đúng: '{g['word']}'"), message_object, thread_id, thread_type)
        elif len(wrong) >= 6:
            del games[tid]; _save(games)
            client.replyMessage(Message(text=f"💀 Thua! Từ đúng: '{g['word']}'"), message_object, thread_id, thread_type)
        else:
            _save(games)
            client.replyMessage(Message(text=_render(g)), message_object, thread_id, thread_type)
    else:
        # Đoán cả từ
        if guess == g["word"]:
            del games[tid]; _save(games)
            client.replyMessage(Message(text=f"🎉 Thắng! Từ đúng: '{g['word']}'"), message_object, thread_id, thread_type)
        else:
            g["guessed"].extend([c for c in guess if c not in g["guessed"]])
            _save(games)
            client.replyMessage(Message(text=f"❌ Sai!\n{_render(g)}"), message_object, thread_id, thread_type)

def PTA():
    return {'doanchu': _play}
