from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Giá cổ phiếu / chứng khoán", 'power': "Thành viên"}

def _stock(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="📈 Dùng: .stock <mã CP>\nVí dụ: .stock AAPL (Apple)"), message_object, thread_id, thread_type); return
    symbol = p[1].upper()
    try:
        r = requests.get(
            f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=1d&range=1d",
            headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        data = r.json()
        meta = data["chart"]["result"][0]["meta"]
        price = meta.get("regularMarketPrice", 0)
        prev = meta.get("previousClose", 0)
        change = price - prev
        pct = (change/prev*100) if prev else 0
        icon = "📈" if change >= 0 else "📉"
        msg = (f"{icon} CỔ PHIẾU: {symbol}\n━━━━━━━━━━\n"
               f"• Giá: ${price:,.2f}\n• Thay đổi: {change:+.2f} ({pct:+.2f}%)\n"
               f"• Đóng cửa trước: ${prev:,.2f}")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy mã '{symbol}': {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'stock': _stock, 'cp': _stock}
