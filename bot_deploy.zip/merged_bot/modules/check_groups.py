# -*- coding: utf-8 -*-
import os
import json
import time
from zlapi.models import Message, ThreadType

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Kiểm tra toàn bộ UID nhóm Bot đang tham gia.",
    'power': "Chủ sở hữu Bot"
}

def handle_check_groups(message, message_object, thread_id, thread_type, author_id, client):
    if not client.is_super_admin(author_id):
        return

    client.replyMessage(Message(text="🔎 Đang quét danh sách toàn bộ nhóm..."), message_object, thread_id, thread_type)

    try:
        all_groups = client.fetchAllGroups()
        if not all_groups or not hasattr(all_groups, 'gridVerMap'):
            client.replyMessage(Message(text="❌ Không thể lấy danh sách nhóm!"), message_object, thread_id, thread_type)
            return

        tids = list(all_groups.gridVerMap.keys())
        total = len(tids)

        msg = f"📊 [ TỔNG HỢP NHÓM: {total} ]\n"
        msg += "━━━━━━━━━━━━━━━━━━━━\n"

        # Chỉ lấy 30 nhóm đầu để tránh tin nhắn quá dài bị Zalo chặn
        # Nếu muốn xem thêm có thể làm phân trang hoặc lưu file
        for i, tid in enumerate(tids[:30], 1):
            try:
                # Thử lấy tên nhóm (lưu ý: fetchGroupInfo tốn thời gian nên chỉ lấy vài cái quan trọng)
                msg += f"{i}. {tid}\n"
            except:
                msg += f"{i}. {tid}\n"

        if total > 30:
            msg += f"\n... và {total - 30} nhóm khác."

        msg += "\n━━━━━━━━━━━━━━━━━━━━\n"
        msg += "💡 Đại ca có thể copy UID này để check xem Bot có hụt nhóm nào không nhé!"

        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

        # GỬI FILE FULL DANH SÁCH (Lưu vào file cho Đại ca check cho kỹ)
        file_path = "data/all_group_uids.txt"
        os.makedirs("data", exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(f"TỔNG CỘNG: {total} NHÓM\n\n")
            for tid in tids:
                f.write(f"{tid}\n")

        client.sendLocalFile(file_path, thread_id, ThreadType.GROUP)

    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi khi check: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'checkgr': handle_check_groups, 'checkgroups': handle_check_groups}
