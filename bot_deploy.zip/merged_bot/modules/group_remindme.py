from zlapi.models import Message, ThreadType
import threading, time

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Nhắc nhở sau khoảng thời gian", 'power': "Thành viên"}

def handle_remind_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=2)
    if len(parts) < 3:
        client.replyMessage(Message(text="⏰ Dùng: .remind <số phút> <nội dung>"), message_object, thread_id, thread_type)
        return
    try:
        minutes = float(parts[1])
        if minutes <= 0 or minutes > 1440:
            raise ValueError("Thời gian phải từ 0-1440 phút")
        content = parts[2]
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)
        return

    client.replyMessage(Message(text=f"⏰ Đã đặt nhắc nhở sau {minutes} phút: \"{content}\""), message_object, thread_id, thread_type)

    def reminder():
        time.sleep(minutes * 60)
        try:
            client.send(Message(text=f"⏰ NHẮC NHỞ: {content}"), thread_id=thread_id, thread_type=thread_type)
        except Exception:
            pass

    threading.Thread(target=reminder, daemon=True).start()

def PTA():
    return {'remind': handle_remind_command, 'nhacnho': handle_remind_command}
