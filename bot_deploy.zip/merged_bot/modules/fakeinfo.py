from zlapi.models import Message
import random
from datetime import date

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tạo thông tin giả ngẫu nhiên", 'power': "Thành viên"}

HO = ["Nguyễn","Trần","Lê","Phạm","Hoàng","Vũ","Đặng","Bùi","Đỗ"]
TEN = ["An","Bình","Chi","Dũng","Giang","Hoa","Lan","Minh","Nam","Phương","Quân","Sơn","Tú"]
TINH = ["Hà Nội","TP.HCM","Đà Nẵng","Hải Phòng","Cần Thơ","Huế","Đà Lạt","Vũng Tàu"]

def _fakeinfo(message, message_object, thread_id, thread_type, author_id, client):
    random.seed(f"{author_id}{date.today()}{random.random()}")
    ho, ten = random.choice(HO), random.choice(TEN)
    tuoi = random.randint(18, 45)
    phone = f"0{''.join(str(random.randint(0,9)) for _ in range(9))}"
    email = f"{ten.lower()}{random.randint(1,999)}@gmail.com"
    msg = (f"👤 THÔNG TIN GIẢ\n━━━━━━━━━━\n"
           f"• Họ tên: {ho} {ten}\n• Tuổi: {tuoi}\n"
           f"• Tỉnh: {random.choice(TINH)}\n"
           f"• SĐT: {phone}\n• Email: {email}")
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'fakeinfo': _fakeinfo, 'taoinfo': _fakeinfo}
