from zlapi.models import Message
import random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Công cụ emoji & text decoration", 'power': "Thành viên"}

EMOJI_SETS = {
    "fire": "🔥💥✨⚡🌟💫",
    "love": "❤️💕💖💗💓💞💘",
    "sad": "😢😭😔😞💔🥺😿",
    "happy": "😀😃😄😁🎉🥳😊",
    "cool": "😎🤙💪🎯🔥👑",
    "cute": "🐱🐶🌸🦋🌈🍀",
}

def _random_emoji(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    cat = p[1].lower() if len(p) > 1 else None
    if cat and cat in EMOJI_SETS:
        emojis = EMOJI_SETS[cat]
    else:
        emojis = "".join(EMOJI_SETS.values())
    result = " ".join(random.choice(emojis) for _ in range(10))
    client.replyMessage(Message(text=result), message_object, thread_id, thread_type)

def _decorate(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="✨ Dùng: .decor <text>"), message_object, thread_id, thread_type); return
    text = p[1]
    styles = [
        f"✨ {text} ✨",
        f"🌟━━━ {text} ━━━🌟",
        f"╔══ {text} ══╗",
        f"【 {text} 】",
        f"《 {text} 》",
    ]
    client.replyMessage(Message(text="\n".join(styles)), message_object, thread_id, thread_type)

def _morse(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="📡 Dùng: .morse <text>"), message_object, thread_id, thread_type); return
    MORSE = {'a':'.-','b':'-...','c':'-.-.','d':'-..','e':'.','f':'..-.','g':'--.','h':'....','i':'..','j':'.---',
             'k':'-.-','l':'.-..','m':'--','n':'-.','o':'---','p':'.--.','q':'--.-','r':'.-.','s':'...','t':'-',
             'u':'..-','v':'...-','w':'.--','x':'-..-','y':'-.--','z':'--..',
             '0':'-----','1':'.----','2':'..---','3':'...--','4':'....-','5':'.....','6':'-....','7':'--...','8':'---..','9':'----.'}
    result = " / ".join(" ".join(MORSE.get(c.lower(),'?') for c in word) for word in p[1].split())
    client.replyMessage(Message(text=f"📡 Morse:\n{result}"), message_object, thread_id, thread_type)

def PTA():
    return {'emoji': _random_emoji, 'decor': _decorate, 'morse': _morse}
