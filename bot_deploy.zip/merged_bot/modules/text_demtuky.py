from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đếm số từ / ký tự trong văn bản", 'power': "Thành viên"}

def handle_demtu_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="🔢 Dùng: .demtu <văn bản>"), message_object, thread_id, thread_type)
        return
    text = parts[1]
    words = len(text.split())
    chars = len(text)
    chars_no_space = len(text.replace(" ", ""))
    msg = f"🔢 THỐNG KÊ VĂN BẢN\n• Số từ: {words}\n• Số ký tự: {chars}\n• Ký tự (không khoảng trắng): {chars_no_space}"
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'demtu': handle_demtu_command, 'wordcount': handle_demtu_command}
