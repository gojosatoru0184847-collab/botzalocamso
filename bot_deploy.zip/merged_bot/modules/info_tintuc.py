from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tin tức mới nhất VN", 'power': "Thành viên"}

def handle_tintuc_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        r = requests.get("https://vnexpress.net/rss/tin-moi-nhat.rss", timeout=10)
        import re
        items = re.findall(r"<title>(.*?)</title>", r.text)[1:6]
        items = [i.replace("<![CDATA[", "").replace("]]>", "") for i in items]
        msg = "📰 TIN TỨC MỚI NHẤT\n━━━━━━━━━━━━━━━\n" + "\n".join(f"• {t}" for t in items)
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi lấy tin tức: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'tintuc': handle_tintuc_command, 'news': handle_tintuc_command}
