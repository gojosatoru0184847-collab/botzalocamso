from zlapi.models import Message
import base64

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Encode/Decode Base64", 'power': "Thành viên"}

def handle_base64_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=2)
    if len(parts) < 3:
        client.replyMessage(Message(text="🔢 Dùng: .base64 encode/decode <text>"), message_object, thread_id, thread_type)
        return
    mode, text = parts[1].lower(), parts[2]
    try:
        if mode == "encode":
            result = base64.b64encode(text.encode()).decode()
        elif mode == "decode":
            result = base64.b64decode(text.encode()).decode()
        else:
            raise ValueError("Chỉ hỗ trợ encode/decode")
        client.replyMessage(Message(text=f"🔢 Kết quả:\n{result}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'base64': handle_base64_command}
