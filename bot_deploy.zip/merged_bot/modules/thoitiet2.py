from zlapi.models import Message
import requests
from config import PREFIX

des = {
    'version': "1.0.0",
    'credits': "UltraBot",
    'description': "Thời tiết nhanh bằng wttr.in",
    'power': "Thành viên"
}

def handle_thoitiet2_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    city = parts[1] if len(parts) > 1 else "Ho Chi Minh"
    try:
        url = f"https://wttr.in/{requests.utils.quote(city)}?format=4&lang=vi"
        r = requests.get(url, timeout=10)
        msg = f"🌤 Thời tiết {city}:\n{r.text.strip()}"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'thoitiet2': handle_thoitiet2_command}
