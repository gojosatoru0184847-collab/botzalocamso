import random
from zlapi.models import Message

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Trò chơi mở rộng: Xổ số, Blackjack, Trivia",
    'power': "Thành viên"
}

def h_loto(m, mo, tid, tt, aid, client):
    num = random.randint(0, 99)
    client.send(Message(text=f"🎰 XỔ SỐ HÔM NAY:\nCon số may mắn của bạn là: {num:02d}"), tid, tt)

def h_blackjack(m, mo, tid, tt, aid, client):
    p = random.randint(15, 21)
    d = random.randint(15, 21)
    res = "BẠN THẮNG! 🎉" if p > d else ("BẠN THUA! 💀" if p < d else "HÒA! 🤝")
    client.send(Message(text=f"🃏 BLACKJACK:\n- Bạn: {p} điểm\n- Nhà cái: {d} điểm\n➜ Kết quả: {res}"), tid, tt)

def h_trivia(m, mo, tid, tt, aid, client):
    client.send(Message(text="❓ TRIVIA: Ai là người phát minh ra bóng đèn?\n🅰️ Thomas Edison\nB. Nikola Tesla\nC. Albert Einstein\n➜ Trả lời bằng {PREFIX}trivia A"), tid, tt)

def PTA():
    return {
        'loteria': h_loto,
        'blackjack2': h_blackjack,
        'trivia': h_trivia,
        'puzzleword': h_trivia
    }
