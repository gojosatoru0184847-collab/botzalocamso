# -*- coding: utf-8 -*-
from zlapi.models import Message
import requests
import urllib.parse

des = {
    'version': "1.1.0",
    'credits': "HOANG LAM",
    'description': "Tìm kiếm Google thông minh (Chống chặn xác minh)",
    'power': "Thành Viên"
}

def handle_search_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.split(" ", 1)
    if len(parts) < 2:
        client.replyMessage(Message(text="⚠️ Đại ca gõ: .gg [nội dung tìm kiếm]"), message_object, thread_id, thread_type)
        return

    query = parts[1].strip()
    client.sendReaction(message_object, "🔍", thread_id, thread_type)

    try:
        # Dùng API Google Search qua DuckDuckGo Proxy để không bị chặn
        api_url = f"https://api.vytub.com/google?search={urllib.parse.quote(query)}"
        response = requests.get(api_url, timeout=20)
        
        if response.status_code == 200:
            data = response.json()
            results = data.get('data', [])[:8] # Lấy 8 kết quả đầu

            if results:
                txt = f"🔎 KẾT QUẢ TÌM KIẾM: '{query}'\n━━━━━━━━━━━━━━━━━━━━\n"
                for i, item in enumerate(results, 1):
                    title = item.get('title', '...')
                    link = item.get('link', '')
                    txt += f"{i}. {title}\n🔗 {link}\n\n"

                client.replyMessage(Message(text=txt.strip()), message_object, thread_id, thread_type)
            else:
                client.replyMessage(Message(text="❌ Không tìm thấy thông tin này thưa Đại ca!"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="⚠️ Google đang bận (Mã lỗi API), Đại ca thử lại sau nhé!"), message_object, thread_id, thread_type)

    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi tìm kiếm: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'gg': handle_search_command}
