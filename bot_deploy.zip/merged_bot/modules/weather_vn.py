from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Thời tiết Việt Nam chi tiết (thay thoitiet2)", 'power': "Thành viên"}

VN_CITIES = {
    "hn":"Hanoi","hcm":"Ho Chi Minh City","dn":"Da Nang","hp":"Hai Phong",
    "hue":"Hue","ct":"Can Tho","dl":"Da Lat","vt":"Vung Tau","bmt":"Buon Ma Thuot"
}

def _weather_vn(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    city_key = p[1].strip().lower() if len(p) > 1 else "hn"
    city = VN_CITIES.get(city_key, city_key)
    try:
        r = requests.get(f"https://wttr.in/{requests.utils.quote(city)}?format=j1", timeout=12)
        data = r.json()
        curr = data["current_condition"][0]
        desc = curr["weatherDesc"][0]["value"]
        temp, feels = curr["temp_C"], curr["FeelsLikeC"]
        humid, wind = curr["humidity"], curr["windspeedKmph"]
        tomorrow = data.get("weather",[{},{}])[1] if len(data.get("weather",[])) > 1 else {}
        msg = (f"🌡 THỜI TIẾT {city.upper()}\n━━━━━━━━━━━━━\n"
               f"• Thời tiết: {desc}\n• Nhiệt độ: {temp}°C (cảm {feels}°C)\n"
               f"• Độ ẩm: {humid}%  Gió: {wind}km/h\n"
               f"• Ngày mai: {tomorrow.get('mintempC','?')}°~{tomorrow.get('maxtempC','?')}°C")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'thoitiet': _weather_vn, 'tt': _weather_vn}
