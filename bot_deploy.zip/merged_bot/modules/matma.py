from zlapi.models import Message
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Mã hóa Caesar cipher",'power':"Thành viên"}

def caesar(text, shift, decode=False):
    if decode: shift = -shift
    result = ""
    for c in text:
        if c.isalpha():
            base = ord('A') if c.isupper() else ord('a')
            result += chr((ord(c) - base + shift) % 26 + base)
        else:
            result += c
    return result

def handle_matma_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=3)
    if len(parts) < 4:
        client.replyMessage(Message(text=f"🔐 Dùng:\n{PREFIX}matma encode <shift> <text>\n{PREFIX}matma decode <shift> <text>"), message_object, thread_id, thread_type); return
    action, shift_str, text = parts[1].lower(), parts[2], parts[3]
    if not shift_str.isdigit():
        client.replyMessage(Message(text="❌ Shift phải là số"), message_object, thread_id, thread_type); return
    shift = int(shift_str)
    result = caesar(text, shift, decode=(action=="decode"))
    client.replyMessage(Message(text=f"🔐 Kết quả (Caesar {action}, shift={shift}):\n{result}"), message_object, thread_id, thread_type)

def PTA():
    return {'matma': handle_matma_command}
