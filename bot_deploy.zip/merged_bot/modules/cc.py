from zlapi.models import *
from zlapi import Message, ThreadType
from config import PREFIX, ADMIN
import time

des = {
    'version': "2.0.0",
    'credits': "HOANG LAM",
    'description': "Xoá tin nhắn theo số lượng hoặc theo đuôi file (Vd: .cc .bin)",
    'power': "Quản trị viên Bot"
}

def handle_go_command(message, message_object, thread_id, thread_type, author_id, client):
    if not client.is_super_admin(author_id):
        client.replyMessage(Message(text="⚠️ Chỉ Đại ca mới có quyền dọn dẹp tin nhắn!"), message_object, thread_id, thread_type)
        return

    parts = message.split()
    if len(parts) < 2:
        client.replyMessage(Message(text=f"🚦 Cách dùng:\n- {PREFIX}cc [số lượng]\n- {PREFIX}cc [đuôi file] (Vd: .cc .bin)"), message_object, thread_id, thread_type)
        return

    target = parts[1].lower()
    num_to_delete = 0
    extension_to_delete = None

    if target.isdigit():
        num_to_delete = int(target)
    elif target.startswith("."):
        extension_to_delete = target
        num_to_delete = 100 # Mặc định quét 100 tin để tìm đuôi đó
    elif target == "all":
        num_to_delete = 100

    if num_to_delete > 100: num_to_delete = 100

    try:
        group_data = client.getRecentGroup(thread_id, count=100)
        if not group_data or not hasattr(group_data, 'groupMsgs') or not group_data.groupMsgs:
            client.replyMessage(Message(text="❌ Không tìm thấy tin nhắn nào để xóa!"), message_object, thread_id, thread_type)
            return
        messages = group_data.groupMsgs[::-1]
    except Exception as e:
        client.replyMessage(Message(text=f"⚠️ Lỗi kết nối: {str(e)}"), message_object, thread_id, thread_type)
        return

    deleted_count = 0
    processed_count = 0

    for msg in messages:
        if extension_to_delete:
            # Xóa theo đuôi file
            attachments = msg.get('attachments', [])
            content = str(msg.get('content', '')).lower()

            is_target = False
            for att in attachments:
                title = str(att.get('title', '') or att.get('name', '')).lower()
                if title.endswith(extension_to_delete):
                    is_target = True
                    break

            if not is_target and extension_to_delete in content:
                is_target = True

            if is_target:
                m_id = msg.get('msgId')
                u_from = str(msg.get('uidFrom', '0'))
                cli_id = msg.get('cliMsgId')
                user_id = u_from if u_from != '0' else author_id
                try:
                    client.deleteGroupMsg(m_id, user_id, cli_id, thread_id)
                    deleted_count += 1
                    time.sleep(0.05)
                except: pass
        else:
            # Xóa theo số lượng
            if deleted_count >= num_to_delete: break
            m_id = msg.get('msgId')
            u_from = str(msg.get('uidFrom', '0'))
            cli_id = msg.get('cliMsgId')
            user_id = u_from if u_from != '0' else author_id
            try:
                client.deleteGroupMsg(m_id, user_id, cli_id, thread_id)
                deleted_count += 1
                time.sleep(0.05)
            except: pass

        processed_count += 1
        if not extension_to_delete and processed_count >= num_to_delete: break

    msg_res = f"✅ Đã dọn dẹp sạch sẽ {deleted_count} tin nhắn"
    if extension_to_delete: msg_res += f" chứa đuôi '{extension_to_delete}'"
    msg_res += " cho Đại ca!"

    client.sendMessage(Message(text=msg_res), thread_id, thread_type, ttl=10000)

def PTA():
    return {
        'cc': handle_go_command,
        'del': handle_go_command
    }
