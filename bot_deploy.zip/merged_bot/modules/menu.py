# -*- coding: utf-8 -*-
import os, importlib, tempfile, random, json, hashlib, time, threading
from zlapi.models import Message
from config import PREFIX
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# =============== CẤU HÌNH ===============
FONT_BOLD        = "modules/cache/font/BeVietnamPro-Bold.ttf"
FONT_REGULAR     = "modules/cache/font/BeVietnamPro-Regular.ttf"
EMOJI_FONT       = "modules/cache/font/NotoEmoji-Bold.ttf"
BG_DIR           = "background"
CACHE_DIR        = "modules/cache/menu_temp"

PAGE_SIZE        = 6

os.makedirs(CACHE_DIR, exist_ok=True)

def get_font(size, bold=True):
    try: return ImageFont.truetype(FONT_BOLD if bold else FONT_REGULAR, size)
    except: return ImageFont.load_default()

def get_emoji_font(size):
    try: return ImageFont.truetype(EMOJI_FONT, size)
    except: return ImageFont.load_default()

def get_bg_image(size):
    try:
        imgs = [f for f in os.listdir(BG_DIR) if f.lower().endswith(('.jpg','.png','.jpeg'))]
        if imgs:
            img = Image.open(os.path.join(BG_DIR, random.choice(imgs)))
            img = img.convert("RGBA")
            target_w, target_h = size
            w, h = img.size
            if w/h > target_w/target_h:
                new_w = int(h * (target_w/target_h))
                img = img.crop(((w-new_w)//2, 0, (w+new_w)//2, h))
            else:
                new_h = int(w * (target_h/target_w))
                img = img.crop((0, (h-new_h)//2, w, (h+new_h)//2))

            img = img.resize(size, Image.LANCZOS)
            return img
    except: pass
    return Image.new("RGBA", size, (15, 18, 30, 255))

def autosave(img, quality=95):
    temp_fd, temp_path = tempfile.mkstemp(suffix=".jpg", dir=CACHE_DIR)
    os.close(temp_fd)
    img.convert("RGB").save(temp_path, "JPEG", quality=quality, optimize=True)
    return temp_path

def _smart_resize(img, target_w, target_h):
    w, h = img.size
    scale = min(target_w / w, target_h / h, 1.0)
    if scale < 1:
        return img.resize((int(w*scale), int(h*scale)), Image.LANCZOS)
    return img

def draw_menu_image(items, page, total_pages, total_cmds):
    W, H = 1600, 1000
    HEADER_H, FOOTER_H = 220, 120
    bg = get_bg_image((W, H))
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d_overlay = ImageDraw.Draw(overlay)
    for x in range(int(W*0.7)):
        alpha = int(220 * (1 - x/(W*0.7)))
        d_overlay.line([(x, 0), (x, H)], fill=(10, 15, 30, alpha))
    bg.alpha_composite(overlay)
    draw = ImageDraw.Draw(bg, "RGBA")
    f_title, f_sub, f_card_title, f_card_alias, f_card_desc, f_emoji = get_font(90), get_font(32), get_font(42), get_font(28), get_font(24, False), get_emoji_font(60)
    draw.text((80, 60), "ULTRA BOT SYSTEM", font=f_title, fill=(0, 255, 255))
    draw.text((85, 160), f"⚡ COMMAND CENTER | PAGE {page}/{total_pages} | {total_cmds} ACTIVE", font=f_sub, fill=(200, 230, 255, 200))
    draw.rounded_rectangle([80, 200, 600, 206], radius=5, fill=(0, 255, 255, 180))
    COL_W, CARD_H, GAP_X, GAP_Y = 700, 180, 60, 30
    START_X, current_y = 80, HEADER_H + 40
    icons = ["⚡", "🛡️", "🧬", "🧪", "🚀", "🛰️", "🎮", "👾", "🤖", "💎", "🔋", "📡", "🔑", "🔐", "🏮", "🔮", "🔥", "🧊", "🌊"]
    for idx, (name, data) in enumerate(items):
        col, row = idx // 3, idx % 3
        x, y = START_X + col * (COL_W + GAP_X), current_y + row * (CARD_H + GAP_Y)
        draw.rounded_rectangle([x, y, x+COL_W, y+CARD_H], radius=25, fill=(20, 25, 45, 190), outline=(0, 255, 255, 150), width=3)
        draw.rectangle([x, y+30, x+10, y+CARD_H-30], fill=(0, 255, 255, 255))
        ic_s = 100
        ix, iy = x + 35, y + (CARD_H - ic_s) // 2
        draw.rounded_rectangle([ix, iy, ix+ic_s, iy+ic_s], radius=15, fill=(0, 200, 255, 30), outline=(0, 255, 255, 80), width=1)
        ic = icons[idx % len(icons)]; draw.text((ix + ic_s//2 - 30, iy + 15), ic, font=f_emoji, fill=(255,255,255))
        tx, ty = ix + ic_s + 30, y + 25
        draw.text((tx, ty), name.replace("_", " ").upper(), font=f_card_title, fill=(255, 255, 255))
        ty += 55; draw.text((tx, ty), f"▶ {PREFIX}{data['aliases'][0]}", font=f_card_alias, fill=(0, 255, 150))
        ty += 40; desc = data['description']; draw.text((tx, ty), desc[:37] + "..." if len(desc) > 40 else desc, font=f_card_desc, fill=(180, 200, 220))
    draw.text((80, H - 70), "STABILITY: 100% | BOT BY HOANG LAM", font=f_sub, fill=(0, 255, 255, 150))
    page_info = f"PAGE {page} OF {total_pages}"; draw.text((W - f_sub.getlength(page_info) - 80, H - 70), page_info, font=f_sub, fill=(255, 255, 255, 150))
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tf:
        bg.convert("RGB").save(tf.name, "JPEG", quality=98, optimize=True)
        return tf.name

def get_all_modules():
    info = {}
    for fname in sorted(os.listdir('modules')):
        if not fname.endswith('.py') or fname == '__init__.py': continue
        try:
            mod_name = fname[:-3]; mod = importlib.import_module(f'modules.{mod_name}')
            if hasattr(mod, 'PTA'):
                cmds = mod.PTA()
                if cmds:
                    d = getattr(mod, 'des', {}); info[mod_name] = {'aliases': list(cmds.keys()), 'version': d.get('version', '1.0'), 'description': d.get('description', 'Bot Command'), 'power': d.get('power', 'Thành viên')}
        except: pass
    return info

def handle_menu(message, message_object, thread_id, thread_type, author_id, client):
    try:
        parts = message.split(); all_mods = get_all_modules(); actual_total_cmds = sum(len(v['aliases']) for v in all_mods.values())
        page = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 1
        filtered = all_mods
        if len(parts) > 1 and not parts[1].isdigit():
            term = parts[1].lower(); filtered = {k:v for k,v in all_mods.items() if term in k.lower() or any(term in a.lower() for a in v['aliases'])}
            if not filtered: return client.replyMessage(Message(text=f"❌ Không thấy lệnh '{term}'!"), message_object, thread_id, thread_type)
        total_pages = (len(filtered) + PAGE_SIZE - 1) // PAGE_SIZE
        if page > total_pages: page = total_pages
        if page < 1: page = 1
        start = (page - 1) * PAGE_SIZE; items = list(filtered.items())[start : start + PAGE_SIZE]
        img_path = draw_menu_image(items, page, total_pages, actual_total_cmds)
        with Image.open(img_path) as img: w, h = img.size
        client.sendLocalImage(img_path, thread_id, thread_type, width=w, height=h)
        if os.path.exists(img_path): os.remove(img_path)
        client.sendReaction(message_object, "📋", thread_id, thread_type)
    except Exception as e: print(f"Lỗi Menu Anime v11: {e}")

def PTA():
    return {'menu': handle_menu}

__all__ = ['handle_menu', 'get_font', 'get_bg_image', 'autosave', '_smart_resize']
