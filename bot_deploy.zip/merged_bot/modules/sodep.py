from zlapi.models import Message
import random
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Sinh số điện thoại đẹp ngẫu nhiên",'power':"Thành viên"}

PREFIXES_VN = ["032","033","034","035","036","037","038","039","096","097","098","086","089","090","093","070","079","077","076","078","089","088","091","094"]
PATTERNS = [
    lambda: "".join([str(random.randint(0,9))]*7),
    lambda: "".join([str(i%10) for i in range(random.randint(0,9), random.randint(0,9)+7)]),
    lambda: "".join([str(random.randint(0,9)) for _ in range(7)]),
]

def handle_sodep_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    n = min(int(parts[1]),10) if len(parts)>1 and parts[1].isdigit() else 5
    nums = []
    for _ in range(n):
        pre = random.choice(PREFIXES_VN)
        suffix = "".join([str(random.randint(0,9)) for _ in range(7)])
        nums.append(pre + suffix)
    msg = f"📱 {n} SỐ ĐẸP NGẪU NHIÊN:\n" + "\n".join(f"• {n}" for n in nums)
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'sodep': handle_sodep_command}
