from zlapi.models import Message
import json

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Format / validate JSON", 'power': "Thành viên"}

def handle_jsonfmt_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text="📋 Dùng: .jsonfmt <json string>"), message_object, thread_id, thread_type)
        return
    try:
        parsed = json.loads(parts[1])
        formatted = json.dumps(parsed, indent=2, ensure_ascii=False)
        client.replyMessage(Message(text=f"📋 JSON hợp lệ:\n{formatted[:1500]}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ JSON không hợp lệ: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'jsonfmt': handle_jsonfmt_command}
