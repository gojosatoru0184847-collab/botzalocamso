from zlapi.models import Message
import requests, json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tra cứu mạng xã hội & thông tin online", 'power': "Thành viên"}

def _github(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🐙 Dùng: .github <username>"), message_object, thread_id, thread_type); return
    user = p[1].strip().lstrip("@")
    try:
        r = requests.get(f"https://api.github.com/users/{user}", timeout=10)
        d = r.json()
        if d.get("message") == "Not Found": raise ValueError("User không tồn tại")
        msg = (f"🐙 GITHUB: {d.get('login')}\n━━━━━━━━━━\n"
               f"• Tên: {d.get('name','N/A')}\n• Bio: {d.get('bio','N/A')}\n"
               f"• Repos: {d.get('public_repos',0)}\n• Followers: {d.get('followers',0)}\n"
               f"• Following: {d.get('following',0)}\n• Link: {d.get('html_url')}")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def _npm(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="📦 Dùng: .npm <package>"), message_object, thread_id, thread_type); return
    pkg = p[1].strip()
    try:
        r = requests.get(f"https://registry.npmjs.org/{pkg}", timeout=10)
        d = r.json()
        latest = d.get("dist-tags", {}).get("latest","N/A")
        desc = d.get("description","N/A")
        dl_url = f"https://www.npmjs.com/package/{pkg}"
        msg = (f"📦 NPM: {pkg}\n━━━━━━━━━━\n• Phiên bản mới nhất: {latest}\n"
               f"• Mô tả: {desc}\n• Link: {dl_url}")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy package: {e}"), message_object, thread_id, thread_type)

def _pypi(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🐍 Dùng: .pypi <package>"), message_object, thread_id, thread_type); return
    pkg = p[1].strip()
    try:
        r = requests.get(f"https://pypi.org/pypi/{pkg}/json", timeout=10)
        d = r.json()
        info = d.get("info",{})
        msg = (f"🐍 PyPI: {info.get('name')}\n━━━━━━━━━━\n"
               f"• Phiên bản: {info.get('version')}\n• Mô tả: {info.get('summary','N/A')}\n"
               f"• Tác giả: {info.get('author','N/A')}\n• Link: {info.get('project_url')}")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Không tìm thấy: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'github': _github, 'ghuser': _github, 'npm': _npm, 'pypi': _pypi}
