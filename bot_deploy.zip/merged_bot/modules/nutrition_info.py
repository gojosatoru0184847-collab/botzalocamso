from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Thông tin dinh dưỡng thực phẩm", 'power': "Thành viên"}

def _nutrition(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split(maxsplit=1)
    if len(p) < 2:
        client.replyMessage(Message(text="🥗 Dùng: .nutrition <tên thức ăn>\nVí dụ: .nutrition apple"), message_object, thread_id, thread_type); return
    food = p[1].strip()
    try:
        r = requests.get(
            f"https://api.calorieninjas.com/v1/nutrition?query={food}",
            headers={"X-Api-Key": "demo"}, timeout=10)
        items = r.json().get("items", [])
        if not items:
            raise ValueError("Không tìm thấy thực phẩm")
        item = items[0]
        msg = (f"🥗 DINH DƯỠNG: {item.get('name','')}\n━━━━━━━━━━━━━━\n"
               f"• Khẩu phần: {item.get('serving_size_g',0)}g\n"
               f"• Calo: {item.get('calories',0)} kcal\n"
               f"• Protein: {item.get('protein_g',0)}g\n"
               f"• Carbs: {item.get('carbohydrates_total_g',0)}g\n"
               f"• Chất béo: {item.get('fat_total_g',0)}g\n"
               f"• Đường: {item.get('sugar_g',0)}g\n"
               f"• Chất xơ: {item.get('fiber_g',0)}g")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'nutrition': _nutrition, 'dinhduong': _nutrition, 'calo2': _nutrition}
