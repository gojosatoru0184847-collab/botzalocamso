from zlapi.models import Message
import json, os
from config import ADMIN

des = {'version': "1.0.0", 'credits': "HOANG LAM", 'description': "Backup danh sách thành viên nhóm", 'power': "Quản trị viên Bot"}

def handle_backupnhom_command(message, message_object, thread_id, thread_type, author_id, client):
    if str(author_id) != ADMIN and str(author_id) not in getattr(client, 'ADM', []):
        client.replyMessage(Message(text="⚠️ Chỉ admin bot mới dùng được lệnh này."), message_object, thread_id, thread_type)
        return
    try:
        group_info = client.fetchGroupInfo(thread_id)
        gdata = group_info.gridInfoMap.get(thread_id, {})
        members = gdata.get("memberIds", []) or gdata.get("currentMems", [])
        backup_dir = "modules/cache/backups"
        os.makedirs(backup_dir, exist_ok=True)
        path = os.path.join(backup_dir, f"backup_{thread_id}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"name": gdata.get("name"), "members": members}, f, ensure_ascii=False, indent=2)
        client.replyMessage(Message(text=f"✅ Đã backup {len(members)} thành viên vào {path}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi backup: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'backupnhom': handle_backupnhom_command}
