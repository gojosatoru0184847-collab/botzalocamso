from zlapi.models import Message
import random, json, os
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Chơi đoán chữ Hangman",'power':"Thành viên"}
WORDS = ["python","robot","zalobot","laptop","gaming","android","server","command","module","database",
         "keyboard","monitor","browser","network","discord","facebook","internet","password","username","software"]
GAME_FILE = "modules/cache/hangman.json"

STAGES = ["😵","😨","😰","😟","😐","😊","🙂"]

def load():
    try:
        with open(GAME_FILE, encoding='utf-8') as f: return json.load(f)
    except: return {}
def save(d):
    os.makedirs("modules/cache",exist_ok=True)
    with open(GAME_FILE,"w", encoding='utf-8') as f: json.dump(d,f)

def handle_hangman_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(); games = load(); key = f"{thread_id}_{author_id}"
    if len(parts) == 1:
        word = random.choice(WORDS)
        games[key] = {"word": word, "guessed": [], "wrong": 0, "max": 6}
        save(games)
        display = " ".join("_" for _ in word)
        client.replyMessage(Message(text=f"🔤 HANGMAN\nTừ: {display} ({len(word)} chữ)\nĐoán: {PREFIX}hangman <chữ cái>"), message_object, thread_id, thread_type)
    else:
        if key not in games:
            client.replyMessage(Message(text=f"❌ Chưa bắt đầu! Gõ {PREFIX}hangman"), message_object, thread_id, thread_type); return
        g = games[key]; letter = parts[1][0].lower()
        word = g["word"]; guessed = g["guessed"]
        if letter in guessed:
            client.replyMessage(Message(text=f"⚠️ Đã đoán '{letter}' rồi!"), message_object, thread_id, thread_type); return
        guessed.append(letter)
        if letter not in word: g["wrong"] += 1
        display = " ".join(c if c in guessed else "_" for c in word)
        stage = STAGES[min(g["wrong"], len(STAGES)-1)]
        save(games)
        if "_" not in display:
            del games[key]; save(games)
            client.replyMessage(Message(text=f"🎉 Thắng! Từ là: {word.upper()}"), message_object, thread_id, thread_type)
        elif g["wrong"] >= g["max"]:
            del games[key]; save(games)
            client.replyMessage(Message(text=f"💀 Thua! Từ đúng là: {word.upper()}"), message_object, thread_id, thread_type)
        else:
            wrong_letters = [x for x in guessed if x not in word]
            client.replyMessage(Message(text=f"{stage} {display}\nSai: {', '.join(wrong_letters)} ({g['wrong']}/{g['max']})"), message_object, thread_id, thread_type)

def PTA():
    return {'hangman': handle_hangman_command}
