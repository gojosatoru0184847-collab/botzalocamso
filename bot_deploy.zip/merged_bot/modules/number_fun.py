from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đổi số: La Mã, nhị phân, hex, đọc số", 'power': "Thành viên"}

def _to_roman(n):
    vals = [(1000,'M'),(900,'CM'),(500,'D'),(400,'CD'),(100,'C'),(90,'XC'),
            (50,'L'),(40,'XL'),(10,'X'),(9,'IX'),(5,'V'),(4,'IV'),(1,'I')]
    r = ""
    for v,s in vals:
        while n >= v: r += s; n -= v
    return r

def _roman(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🔢 Dùng: .roman <1-3999>"), message_object, thread_id, thread_type); return
    try:
        n = int(p[1])
        if 1 <= n <= 3999:
            client.replyMessage(Message(text=f"🏛 {n} = {_to_roman(n)}"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="❌ Chỉ hỗ trợ 1-3999"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập số nguyên"), message_object, thread_id, thread_type)

def _bases(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🔢 Dùng: .bin <số>"), message_object, thread_id, thread_type); return
    try:
        n = int(p[1])
        client.replyMessage(Message(
            text=f"🔢 {n}\n• Nhị phân: {bin(n)[2:]}\n• Bát phân: {oct(n)[2:]}\n• Hex: {hex(n)[2:].upper()}"
        ), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập số hợp lệ"), message_object, thread_id, thread_type)

def PTA():
    return {'roman': _roman, 'lavietma': _roman, 'bin': _bases, 'hexnum': _bases}
