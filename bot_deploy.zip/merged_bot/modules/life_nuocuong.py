from zlapi.models import Message

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tính lượng nước cần uống mỗi ngày", 'power': "Thành viên"}

def handle_nuocuong_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 2:
        client.replyMessage(Message(text="💧 Dùng: .nuocuong <cân nặng kg>"), message_object, thread_id, thread_type)
        return
    try:
        weight = float(parts[1])
        liters = weight * 0.033
        glasses = liters * 1000 / 250
        msg = f"💧 Bạn nên uống khoảng {liters:.1f} lít nước/ngày\n(~{glasses:.0f} ly 250ml)"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'nuocuong': handle_nuocuong_command}
