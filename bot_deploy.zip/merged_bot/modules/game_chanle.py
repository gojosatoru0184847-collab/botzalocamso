from zlapi.models import Message
import random, json, os

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chơi chẵn lẻ cược tiền", 'power': "Thành viên"}

MONEY_FILE = 'modules/cache/money.json'

def _load_money():
    try:
        with open(MONEY_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save_money(d):
    with open(MONEY_FILE, 'w', encoding='utf-8') as f: json.dump(d, f, indent=4)

def handle_chanle_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 3:
        client.replyMessage(Message(text="🎲 Dùng: .chanle <chan/le> <số tiền>"), message_object, thread_id, thread_type)
        return

    choice = parts[1].lower()
    if choice not in ("chan", "le"):
        client.replyMessage(Message(text="❌ Chỉ chọn 'chan' hoặc 'le'"), message_object, thread_id, thread_type)
        return

    try:
        bet = int(parts[2])
    except:
        client.replyMessage(Message(text="❌ Số tiền không hợp lệ"), message_object, thread_id, thread_type)
        return

    money = _load_money()
    uid = str(author_id)
    balance = money.get(uid, 0)

    if bet <= 0 or bet > balance:
        client.replyMessage(Message(text=f"❌ Số dư không đủ. Hiện có: {balance}"), message_object, thread_id, thread_type)
        return

    dice = random.randint(1, 6)
    result = "chan" if dice % 2 == 0 else "le"
    win = (result == choice)

    if win:
        money[uid] = balance + bet
        msg = f"🎲 Xúc xắc ra: {dice} ({result})\n✅ Bạn THẮNG +{bet}\nSố dư: {money[uid]}"
    else:
        money[uid] = balance - bet
        msg = f"🎲 Xúc xắc ra: {dice} ({result})\n❌ Bạn THUA -{bet}\nSố dư: {money[uid]}"

    _save_money(money)
    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'chanle': handle_chanle_command}
