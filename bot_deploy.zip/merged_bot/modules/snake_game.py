from zlapi.models import Message
import json, os, random

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chơi Snake qua text (mini)", 'power': "Thành viên"}

GAME_FILE = "modules/cache/data/snake.json"
W, H = 10, 6

def _load():
    try:
        with open(GAME_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

def _save(d):
    os.makedirs(os.path.dirname(GAME_FILE), exist_ok=True)
    with open(GAME_FILE, 'w', encoding='utf-8') as f: json.dump(d, f)

def _render(snake, food, score):
    grid = [['⬜']*W for _ in range(H)]
    for x,y in snake[1:]:
        if 0<=x<W and 0<=y<H: grid[y][x] = '🟩'
    hx,hy = snake[0]
    if 0<=hx<W and 0<=hy<H: grid[hy][hx] = '🐍'
    fx,fy = food
    if 0<=fx<W and 0<=fy<H: grid[fy][fx] = '🍎'
    rows = [''.join(r) for r in grid]
    return f"Score: {score}\n" + '\n'.join(rows) + "\n⬆️/⬇️/⬅️/➡️ → .snake u/d/l/r"

def _snake(message, message_object, thread_id, thread_type, author_id, client):
    games = _load()
    tid = str(thread_id)
    p = message.strip().split()
    direction = p[1].lower() if len(p) > 1 else "new"

    if direction == "new" or tid not in games:
        snake = [[W//2, H//2]]
        food = [random.randint(0,W-1), random.randint(0,H-1)]
        games[tid] = {"snake": snake, "food": food, "dir": "r", "score": 0}
        _save(games)
        client.replyMessage(Message(text=f"🐍 SNAKE GAME BẮT ĐẦU!\n{_render(snake, food, 0)}"), message_object, thread_id, thread_type)
        return

    g = games[tid]
    DIR_MAP = {"u":[0,-1],"d":[0,1],"l":[-1,0],"r":[1,0],
               "up":[0,-1],"down":[0,1],"left":[-1,0],"right":[1,0]}
    if direction not in DIR_MAP:
        client.replyMessage(Message(text=_render(g["snake"], g["food"], g["score"])), message_object, thread_id, thread_type)
        return

    dx, dy = DIR_MAP[direction]
    hx, hy = g["snake"][0]
    nx, ny = hx+dx, hy+dy

    if nx<0 or nx>=W or ny<0 or ny>=H or [nx,ny] in g["snake"]:
        score = g["score"]
        del games[tid]; _save(games)
        client.replyMessage(Message(text=f"💀 GAME OVER! Score: {score}\nGõ .snake new để chơi lại."), message_object, thread_id, thread_type)
        return

    g["snake"].insert(0, [nx,ny])
    if [nx,ny] == g["food"]:
        g["score"] += 10
        while True:
            nf = [random.randint(0,W-1), random.randint(0,H-1)]
            if nf not in g["snake"]: break
        g["food"] = nf
    else:
        g["snake"].pop()

    _save(games)
    client.replyMessage(Message(text=_render(g["snake"], g["food"], g["score"])), message_object, thread_id, thread_type)

def PTA():
    return {'snake': _snake}
