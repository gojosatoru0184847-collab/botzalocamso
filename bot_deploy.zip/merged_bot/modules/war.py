# -*- coding: utf-8 -*-
import os, json, time, threading, random
from zlapi.models import Message, Mention, MultiMsgStyle, MessageStyle
from config import PREFIX
from modules.var import global_war_state, state_lock

des = {
    'version': "3.0.0",
    'credits': "HOANG LAM",
    'description': "War thống nhất - Kho đạn 10k câu",
    'power': "Chủ sở hữu Bot"
}

def load_10k_content():
    try:
        if os.path.exists("war_content.txt"):
            with open("war_content.txt", "r", encoding="utf-8") as f:
                return [line.strip() for line in f if line.strip()]
    except: pass
    return ["Sủa tiếp đi! 🐶", "Trình còi! 🔥"]

def war_worker(client, thread_id, thread_type, delay):
    while global_war_state.get(thread_id):
        content = load_10k_content()
        text = random.choice(content)
        styles = MultiMsgStyle([
            MessageStyle(offset=0, length=len(text), style="font", size="500", auto_format=False),
            MessageStyle(offset=0, length=len(text), style="bold", auto_format=False),
            MessageStyle(offset=0, length=len(text), style="color", color="#ff0000", auto_format=False)
        ])
        try: client.sendMessage(Message(text=text, style=styles), thread_id, thread_type)
        except: break
        time.sleep(max(0.1, delay + random.uniform(0.01, 0.05)))

def handle_war_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(client, 'is_super_admin') or not client.is_super_admin(author_id):
        return

    parts = message.split()
    if len(parts) < 2:
        client.replyMessage(Message(text=f"⚔️ Dùng: {PREFIX}war on [delay] / off"), message_object, thread_id, thread_type)
        return

    action = parts[1].lower()

    if action == "on":
        delay = 0.5
        if len(parts) > 2:
            try: delay = float(parts[2])
            except: pass

        with state_lock:
            if global_war_state.get(thread_id):
                client.replyMessage(Message(text="🚦 Đang có hỏa lực khác đang chạy!"), message_object, thread_id, thread_type)
                return
            global_war_state[thread_id] = True

        for _ in range(3):
            threading.Thread(target=war_worker, args=(client, thread_id, thread_type, delay), daemon=True).start()

        client.replyMessage(Message(text=f"🚀 [ WAR 10K ] ĐÃ KÍCH HOẠT!"), message_object, thread_id, thread_type)

    elif action == "off":
        with state_lock: global_war_state[thread_id] = False
        client.replyMessage(Message(text="🛑 ĐÃ TẮT TOÀN BỘ WAR/VAR."), message_object, thread_id, thread_type)

def PTA():
    return {'war': handle_war_command}
