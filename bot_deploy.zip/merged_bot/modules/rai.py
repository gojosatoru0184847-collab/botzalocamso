import json
import os
import time
import threading
import logging
import requests
from pathlib import Path
from zlapi.models import Message, ThreadType
from config import ADMIN, PREFIX

# Cấu hình logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='auto_rai.log',
    encoding='utf-8'
)

# Trạng thái toàn cục
rai_state = {}  # {thread_id: {running: bool, thread: Thread}}
rai_all_state = {'running': False}
rai_sent_cache = [] # [{msgId, cliMsgId, threadId}]
state_lock = threading.Lock()
MESSAGE_DELAY = 0.3
NETWORK_TIMEOUT = 10

# Thông tin mô-đun
des = {
    'version': '1.0.7',
    'credits': 'Trần Mạnh Quân',
    'description': 'Tự động rải tin nhắn, ảnh, video, danh thiếp.',
    'power': 'Quản trị viên Bot'
}

# Đường dẫn file
RAI_JSON_PATH = Path("data/rai.json")

# Khởi tạo file JSON khi bot khởi động
def init_rai_json():
    default_data = {
        "message": "",
        "card": {},
        "time": {"time": 10},
        "images": [],
        "videos": [],
        "disbox": []
    }
    with state_lock:
        if not RAI_JSON_PATH.exists():
            RAI_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
            with RAI_JSON_PATH.open("w", encoding="utf-8") as f:
                json.dump(default_data, f, indent=4, ensure_ascii=False)
            logging.info("Đã tạo file rai.json với dữ liệu mặc định.")
        else:
            logging.info("File rai.json đã tồn tại, không cần tạo mới.")

# Hàm xử lý JSON
def load_rai_data() -> dict:
    with state_lock:
        try:
            with RAI_JSON_PATH.open("r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    return json.loads(content)
            return {
                "message": "",
                "card": {},
                "time": {"time": 10},
                "images": [],
                "videos": [],
                "disbox": []
            }
        except Exception as e:
            logging.error(f"Lỗi đọc JSON {RAI_JSON_PATH}: {e}")
            return {
                "message": "",
                "card": {},
                "time": {"time": 10},
                "images": [],
                "videos": [],
                "disbox": []
            }

def save_rai_data(data: dict) -> None:
    with state_lock:
        try:
            with RAI_JSON_PATH.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logging.error(f"Lỗi ghi JSON {RAI_JSON_PATH}: {e}")

def load_disbox() -> list:
    return load_rai_data().get("disbox", [])

def save_disbox(disbox_ids: list) -> None:
    data = load_rai_data()
    data["disbox"] = disbox_ids
    save_rai_data(data)

def load_rai_message() -> str:
    return load_rai_data().get("message", "").strip()

def save_rai_message(message_text: str) -> None:
    data = load_rai_data()
    data["message"] = message_text
    save_rai_data(data)

def load_card() -> dict:
    return load_rai_data().get("card", {})

def save_card(card_data: dict) -> None:
    data = load_rai_data()
    data["card"] = card_data
    save_rai_data(data)

def load_rai_time() -> int:
    return load_rai_data().get("time", {"time": 10})["time"]

def save_rai_time(minutes: int) -> None:
    data = load_rai_data()
    data["time"] = {"time": minutes}
    save_rai_data(data)

def load_images() -> list:
    return load_rai_data().get("images", [])

def save_images(image_links: list) -> None:
    data = load_rai_data()
    data["images"] = image_links
    save_rai_data(data)

def load_videos() -> list:
    return load_rai_data().get("videos", [])

def save_videos(video_data: list) -> None:
    data = load_rai_data()
    data["videos"] = video_data
    save_rai_data(data)

# Tải ảnh và video
def download_images(link_list: list, save_folder: str = "temp_images") -> list:
    os.makedirs(save_folder, exist_ok=True)
    paths = []
    for idx, link in enumerate(link_list):
        try:
            link = f"https://{link}" if not link.startswith(('http://', 'https://')) else link
            res = requests.get(link, timeout=NETWORK_TIMEOUT)
            res.raise_for_status()
            file_path = f"{save_folder}/img_{idx}_{int(time.time())}.jpg"
            with open(file_path, "wb") as f:
                f.write(res.content)
            paths.append(file_path)
        except Exception as e:
            logging.error(f"Lỗi tải ảnh {link}: {e}")
    return paths

def download_attachment(attachment_url: str, save_folder: str = "temp_images") -> str:
    os.makedirs(save_folder, exist_ok=True)
    try:
        attachment_url = f"https://{attachment_url}" if not attachment_url.startswith(('http://', 'https://')) else attachment_url
        res = requests.get(attachment_url, timeout=NETWORK_TIMEOUT)
        res.raise_for_status()
        file_path = os.path.join(save_folder, f"attachment_{int(time.time())}.jpg")
        with open(file_path, "wb") as f:
            f.write(res.content)
        return file_path
    except Exception as e:
        logging.error(f"Lỗi tải attachment {attachment_url}: {e}")
        return None

# Gửi tin nhắn
def send_message(client, text: str = None, card_data: dict = None, message_object=None, thread_id: str = None, thread_type=None) -> bool:
    try:
        def track_sent(res, tid):
            if res:
                msg_info = None
                if hasattr(res, 'msgId'):
                    msg_info = {'msgId': res.msgId, 'cliMsgId': res.cliMsgId, 'threadId': tid}
                elif isinstance(res, dict) and 'msgId' in res:
                    msg_info = {'msgId': res['msgId'], 'cliMsgId': res['cliMsgId'], 'threadId': tid}

                if msg_info:
                    with state_lock:
                        rai_sent_cache.append(msg_info)
                        if len(rai_sent_cache) > 2000:
                            del rai_sent_cache[0]

        image_links = load_images()
        local_image_paths = download_images(image_links)
        if local_image_paths:
            res = client.sendMultiLocalImage(local_image_paths, thread_id=thread_id, thread_type=thread_type, ttl=3600000)
            track_sent(res, thread_id)
            for path in local_image_paths:
                try:
                    os.remove(path)
                except:
                    pass
            time.sleep(MESSAGE_DELAY)

        video_data_list = load_videos()
        for video_data in video_data_list:
            video_url = video_data.get("normalUrl", "")
            if not video_url:
                continue
            video_url = f"https://{video_url}" if not video_url.startswith(('http://', 'https://')) else video_url
            try:
                requests.head(video_url, timeout=NETWORK_TIMEOUT, allow_redirects=True).raise_for_status()
                res = client.sendRemoteVideo(
                    videoUrl=video_url,
                    thumbnailUrl=video_data.get("thumb", video_url),
                    duration=video_data.get("duration", 10000),
                    width=video_data.get("width", 720),
                    height=video_data.get("height", 720),
                    thread_id=thread_id,
                    thread_type=thread_type,
                    ttl=3600000
                )
                track_sent(res, thread_id)
                time.sleep(MESSAGE_DELAY)
            except Exception as e:
                logging.error(f"Lỗi gửi video {video_url}: {e}")
                continue

        if text:
            msg = Message(text=text)  # Không áp dụng style để giữ chữ bình thường
            if message_object:
                res = client.replyMessage(msg, message_object, thread_id=thread_id, thread_type=thread_type, ttl=3600000)
            else:
                res = client.sendMessage(msg, thread_id=thread_id, thread_type=thread_type, ttl=3600000)
            track_sent(res, thread_id)
            time.sleep(MESSAGE_DELAY)

        if card_data and card_data.get('uid') and card_data.get('content'):
            try:
                user_info_res = client.fetchUserInfo(card_data['uid'])
                if user_info_res and hasattr(user_info_res, 'changed_profiles'):
                    user_info = user_info_res.changed_profiles.get(str(card_data['uid']), {})
                else:
                    user_info = {}
                avatar_url = user_info.get('avatar', '') if user_info else ''
                res = client.sendBusinessCard(
                    userId=card_data['uid'],
                    qrCodeUrl=avatar_url,
                    phone=card_data['content'],
                    thread_id=thread_id,
                    thread_type=thread_type,
                    ttl=3600000
                )
                track_sent(res, thread_id)
                time.sleep(MESSAGE_DELAY)
            except:
                pass
        return True
    except Exception as e:
        logging.error(f"Lỗi gửi tin nhắn tới nhóm {thread_id}: {e}")
        return False

# Vòng lặp rải
def rai_loop(client, thread_id: str):
    try:
        while rai_state.get(thread_id, {}).get('running', False):
            msg_text = load_rai_message().strip()
            card_data = load_card()
            if msg_text or card_data.get('uid') or load_images() or load_videos():
                send_message(client, msg_text, card_data, thread_id=thread_id, thread_type=ThreadType.GROUP)
            time.sleep(load_rai_time() * 60)
    except Exception as e:
        logging.error(f"Lỗi trong rai_loop nhóm {thread_id}: {e}")
    finally:
        with state_lock:
            if thread_id in rai_state:
                rai_state[thread_id]['running'] = False
                if 'thread' in rai_state[thread_id]:
                    del rai_state[thread_id]['thread']
                del rai_state[thread_id]

def rai_all_loop(client):
    try:
        all_groups = client.fetchAllGroups()
        group_ids = list(all_groups.gridVerMap.keys()) if all_groups and hasattr(all_groups, 'gridVerMap') else []
        if not group_ids:
            return
        while rai_all_state.get('running', False):
            msg_text = load_rai_message().strip()
            card_data = load_card()
            if not (msg_text or card_data.get('uid') or load_images() or load_videos()):
                time.sleep(load_rai_time() * 60)
                continue
            disbox_ids = load_disbox()
            for tid in group_ids:
                if tid not in disbox_ids:
                    send_message(client, msg_text, card_data, thread_id=tid, thread_type=ThreadType.GROUP)
            time.sleep(load_rai_time() * 60)
    except Exception as e:
        logging.error(f"Lỗi trong rai_all_loop: {e}")
    finally:
        with state_lock:
            rai_all_state['running'] = False
            if 'thread' in rai_all_state:
                del rai_all_state['thread']

# Menu trợ giúp (không dùng định dạng chữ nhỏ, bỏ lưu ý)
def rai_help_text() -> str:
    return f"""《 HỆ THỐNG BOT AUTO RẢI 》
➤ Bật/Tắt:
• {PREFIX}rai on → Bật rải trong nhóm hiện tại
• {PREFIX}rai off → Tắt rải trong nhóm hoặc all
• {PREFIX}rai all → Bật rải tất cả nhóm
• {PREFIX}rai status → Xem trạng thái
➤ Disbox:
• {PREFIX}rai disbox → Thêm nhóm vào danh sách chặn
• {PREFIX}rai undisbox → Gỡ nhóm khỏi danh sách chặn
➤ Nội dung:
• {PREFIX}rai set [nội dung] → Đặt nội dung rải
• {PREFIX}rai card set [uid] [nội dung] → Đặt danh thiếp
• {PREFIX}rai card clear → Xóa danh thiếp
➤ Ảnh:
• {PREFIX}rai image add [url/đính kèm] → Thêm ảnh
• {PREFIX}rai image list → Xem danh sách ảnh
• {PREFIX}rai image remove [số] → Xóa ảnh
• {PREFIX}rai image clear → Xóa tất cả ảnh
➤ Video:
• {PREFIX}rai video add [url] → Thêm video
• {PREFIX}rai video list → Xem danh sách video
• {PREFIX}rai video remove [số] → Xóa video
• {PREFIX}rai video clear → Xóa tất cả video
➤ Thời gian:
• {PREFIX}rai time set [phút] → Đặt thời gian rải
➤ Thu hồi:
• {PREFIX}rai undo → Thu hồi toàn bộ tin nhắn rải gần đây"""

# Kiểm tra admin
def is_admin(author_id):
    return author_id == ADMIN

# Xử lý lệnh
def handle_rai_command(message, message_object, thread_id: str, thread_type, author_id: str, client):
    # Kiểm tra admin im lặng
    if not is_admin(author_id):
        return

    try:
        # Khởi tạo trạng thái
        with state_lock:
            if thread_id not in rai_state:
                rai_state[thread_id] = {'running': False}

        # Xử lý tin nhắn
        message_text = message_object.text.strip() if hasattr(message_object, 'text') and message_object.text else message
        parts = message_text.split(maxsplit=3)
        if len(parts) < 2:
            client.replyMessage(Message(text=rai_help_text()), message_object, thread_id, thread_type, ttl=120000)
            return

        action = parts[1].lower()
        attachments = message_object.attachments if hasattr(message_object, 'attachments') else []

        # Lệnh set nội dung
        if action == "set" and len(parts) >= 3:
            content = ' '.join(parts[2:])
            save_rai_message(content)
            client.replyMessage(Message(text=f"✔️ Đã lưu nội dung: {content}"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh xử lý danh thiếp
        if action == "card":
            if len(parts) < 3:
                client.replyMessage(Message(text=f"😵‍💫 Cú pháp: {PREFIX}rai card set <uid> <nội dung> hoặc {PREFIX}rai card clear"), message_object, thread_id, thread_type, ttl=120000)
                return
            sub_action = parts[2].lower()
            if sub_action == "clear":
                save_card({})
                client.replyMessage(Message(text="✔️ Đã xóa danh thiếp!"), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "set" and len(parts) >= 4:
                sub_parts = ' '.join(parts[3:]).split(maxsplit=1)
                if len(sub_parts) >= 2:
                    uid, content = sub_parts[0].strip(), sub_parts[1].strip()
                    if uid.isdigit() and content:
                        save_card({'uid': uid, 'content': content})
                        client.replyMessage(Message(text=f"✔️ Đã lưu danh thiếp: UID {uid}, Nội dung: {content}"), message_object, thread_id, thread_type, ttl=120000)
                        return
                client.replyMessage(Message(text=f"😵‍💫 Cú pháp: {PREFIX}rai card set <uid> <nội dung>"), message_object, thread_id, thread_type, ttl=120000)
                return

        # Lệnh xử lý ảnh
        if action == "image":
            if len(parts) < 3 or parts[2].lower() not in ["add", "clear", "list", "remove"]:
                client.replyMessage(Message(text=f"😵‍💫 Cú pháp: {PREFIX}rai image add <link> hoặc clear/list/remove <số>"), message_object, thread_id, thread_type, ttl=120000)
                return
            sub_action = parts[2].lower()
            image_links = load_images()
            if sub_action == "clear":
                save_images([])
                client.replyMessage(Message(text="✔️ Đã xóa tất cả ảnh!"), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "list":
                if not image_links:
                    client.replyMessage(Message(text="😵‍💫 Danh sách ảnh trống!"), message_object, thread_id, thread_type, ttl=120000)
                    return
                list_text = "📷 Danh sách ảnh:\n" + "\n".join(f"{i+1}. {link}" for i, link in enumerate(image_links))
                client.replyMessage(Message(text=list_text), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "remove" and len(parts) >= 4:
                try:
                    index = int(parts[3]) - 1
                    if 0 <= index < len(image_links):
                        removed = image_links.pop(index)
                        save_images(image_links)
                        client.replyMessage(Message(text=f"✔️ Đã xóa ảnh số {index + 1}: {removed}"), message_object, thread_id, thread_type, ttl=120000)
                        return
                    client.replyMessage(Message(text="😵‍💫 Số thứ tự không hợp lệ!"), message_object, thread_id, thread_type, ttl=120000)
                except ValueError:
                    client.replyMessage(Message(text="😵‍💫 Số thứ tự phải là số nguyên!"), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "add":
                added = False
                if attachments:
                    for attachment in attachments:
                        if isinstance(attachment, dict) and attachment.get('type') == 'image' and 'url' in attachment:
                            url = attachment['url']
                            if url not in image_links:
                                image_links.append(url)
                                save_images(image_links)
                                added = True
                elif len(parts) >= 4:
                    url = parts[3].strip()
                    if url not in image_links:
                        image_links.append(url)
                        save_images(image_links)
                        added = True
                if added:
                    client.replyMessage(Message(text=f"✔️ Đã thêm ảnh: {url if 'url' in locals() else 'đính kèm'}"), message_object, thread_id, thread_type, ttl=120000)
                else:
                    client.replyMessage(Message(text="😵‍💫 Ảnh đã có hoặc link không hợp lệ!"), message_object, thread_id, thread_type, ttl=120000)
                return

        # Lệnh xử lý video
        if action == "video":
            if len(parts) < 3 or parts[2].lower() not in ["add", "clear", "list", "remove"]:
                client.replyMessage(Message(text=f"😵‍💫 Cú pháp: {PREFIX}rai video add <link> hoặc clear/list/remove <số>"), message_object, thread_id, thread_type, ttl=120000)
                return
            sub_action = parts[2].lower()
            video_list = load_videos()
            if sub_action == "clear":
                save_videos([])
                client.replyMessage(Message(text="✔️ Đã xóa tất cả video!"), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "list":
                if not video_list:
                    client.replyMessage(Message(text="😵‍💫 Danh sách video trống!"), message_object, thread_id, thread_type, ttl=120000)
                    return
                list_text = "🎥 Danh sách video:\n" + "\n".join(f"{i+1}. {v['normalUrl']}" for i, v in enumerate(video_list))
                client.replyMessage(Message(text=list_text), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "remove" and len(parts) >= 4:
                try:
                    index = int(parts[3]) - 1
                    if 0 <= index < len(video_list):
                        removed = video_list.pop(index)['normalUrl']
                        save_videos(video_list)
                        client.replyMessage(Message(text=f"✔️ Đã xóa video số {index + 1}: {removed}"), message_object, thread_id, thread_type, ttl=120000)
                        return
                    client.replyMessage(Message(text="😵‍💫 Số thứ tự không hợp lệ!"), message_object, thread_id, thread_type, ttl=120000)
                except ValueError:
                    client.replyMessage(Message(text="😵‍💫 Số thứ tự phải là số nguyên!"), message_object, thread_id, thread_type, ttl=120000)
                return
            if sub_action == "add" and len(parts) >= 4:
                video_url = parts[3].strip()
                video_url = f"https://{video_url}" if not video_url.startswith(('http://', 'https://')) else video_url
                video_data = {"normalUrl": video_url, "thumb": video_url, "duration": 10000, "width": 720, "height": 720}
                if video_url not in [v["normalUrl"] for v in video_list]:
                    video_list.append(video_data)
                    save_videos(video_list)
                    client.replyMessage(Message(text=f"✔️ Đã thêm video: {video_url}"), message_object, thread_id, thread_type, ttl=120000)
                else:
                    client.replyMessage(Message(text="😵‍💫 Video đã có!"), message_object, thread_id, thread_type, ttl=120000)
                return

        # Lệnh đặt thời gian
        if action == "time" and len(parts) >= 4 and parts[2].lower() == "set":
            try:
                minutes = int(parts[3])
                if minutes >= 1:
                    save_rai_time(minutes)
                    client.replyMessage(Message(text=f"✔️ Đã đặt thời gian: {minutes} phút"), message_object, thread_id, thread_type, ttl=120000)
                    return
                client.replyMessage(Message(text="😵‍💫 Thời gian tối thiểu là 1 phút!"), message_object, thread_id, thread_type, ttl=120000)
            except ValueError:
                client.replyMessage(Message(text="😵‍💫 Số phút phải là số nguyên!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh chặn nhóm
        if action == "disbox":
            disbox_ids = load_disbox()
            if thread_id not in disbox_ids:
                disbox_ids.append(thread_id)
                save_disbox(disbox_ids)
                client.replyMessage(Message(text="✔️ Đã thêm nhóm vào danh sách chặn"), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="😵‍💫 Nhóm đã trong danh sách chặn!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh bỏ chặn nhóm
        if action == "undisbox":
            disbox_ids = load_disbox()
            if thread_id in disbox_ids:
                disbox_ids.remove(thread_id)
                save_disbox(disbox_ids)
                client.replyMessage(Message(text="✔️ Đã gỡ nhóm khỏi danh sách chặn"), message_object, thread_id, thread_type, ttl=120000)
            else:
                client.replyMessage(Message(text="😵‍💫 Nhóm không có trong danh sách chặn!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh xem trạng thái
        if action == "status":
            msg_text = load_rai_message().strip()
            card_data = load_card()
            time_interval = load_rai_time()
            disbox_ids = load_disbox()
            image_links = load_images()
            video_list = load_videos()
            status = (
                f"📊 Trạng thái Auto Rải:\n"
                f"• Nội dung: {msg_text or 'Chưa thiết lập'}\n"
                f"• Danh thiếp: {'Đã thiết lập' if card_data.get('uid') else 'Chưa thiết lập'}\n"
                f"  UID: {card_data.get('uid', 'Chưa thiết lập')}\n"
                f"  Nội dung: {card_data.get('content', 'Chưa thiết lập')}\n"
                f"• Ảnh: {len(image_links)} ảnh\n"
                f"• Video: {len(video_list)} video\n"
                f"• Thời gian: {time_interval} phút\n"
                f"• Rải nhóm: {'Bật' if rai_state.get(thread_id, {}).get('running', False) else 'Tắt'}\n"
                f"• Rải ALL: {'Bật' if rai_all_state.get('running', False) else 'Tắt'}\n"
                f"• Nhóm chặn: {len(disbox_ids)} nhóm\n"
            )
            client.replyMessage(Message(text=status), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh bật rải trong nhóm
        if action == "on":
            disbox_ids = load_disbox()
            if thread_id in disbox_ids:
                client.replyMessage(Message(text="⛔ Nhóm này bị chặn rải!"), message_object, thread_id, thread_type, ttl=120000)
                return
            if not (load_rai_message().strip() or load_card().get('uid') or load_images() or load_videos()):
                client.replyMessage(Message(text="😵‍💫 Chưa có nội dung để rải!"), message_object, thread_id, thread_type, ttl=120000)
                return
            with state_lock:
                if rai_state.get(thread_id, {}).get('running', False):
                    client.replyMessage(Message(text="⛔ Rải đã bật trong nhóm này!"), message_object, thread_id, thread_type, ttl=120000)
                    return
                rai_state[thread_id] = {'running': True}
            thread = threading.Thread(target=rai_loop, args=(client, thread_id), daemon=True)
            with state_lock:
                rai_state[thread_id]['thread'] = thread
            thread.start()
            client.replyMessage(Message(text="✔️ Đã bật rải trong nhóm này!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh bật rải tất cả nhóm
        if action == "all":
            if not (load_rai_message().strip() or load_card().get('uid') or load_images() or load_videos()):
                client.replyMessage(Message(text="😵‍💫 Chưa có nội dung để rải!"), message_object, thread_id, thread_type, ttl=120000)
                return
            with state_lock:
                if rai_all_state.get('running', False):
                    client.replyMessage(Message(text="⛔ Rải ALL đã bật!"), message_object, thread_id, thread_type, ttl=120000)
                    return
                rai_all_state['running'] = True
            thread = threading.Thread(target=rai_all_loop, args=(client,), daemon=True)
            with state_lock:
                rai_all_state['thread'] = thread
            thread.start()
            client.replyMessage(Message(text="✔️ Đã bật rải ALL nhóm!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh tắt rải
        if action == "off":
            with state_lock:
                if rai_all_state.get('running', False):
                    rai_all_state['running'] = False
                    client.replyMessage(Message(text="✔️ Đã dừng rải ALL!"), message_object, thread_id, thread_type, ttl=120000)
                elif rai_state.get(thread_id, {}).get('running', False):
                    rai_state[thread_id]['running'] = False
                    client.replyMessage(Message(text="✔️ Đã dừng rải trong nhóm này!"), message_object, thread_id, thread_type, ttl=120000)
                else:
                    client.replyMessage(Message(text="😵‍💫 Rải chưa được bật!"), message_object, thread_id, thread_type, ttl=120000)
            return

        # Lệnh thu hồi (undo)
        if action == "undo":
            if not rai_sent_cache:
                client.replyMessage(Message(text="⚠️ KHÔNG TÌM THẤY LỊCH SỬ TIN NHẮN RẢI GẦN ĐÂY ĐỂ THU HỒI."), message_object, thread_id, thread_type, ttl=120000)
                return

            with state_lock:
                to_undo = list(rai_sent_cache)
                rai_sent_cache.clear()

            client.replyMessage(Message(text=f"⏳ ĐANG THU HỒI {len(to_undo)} TIN NHẮN RẢI GẦN ĐÂY..."), message_object, thread_id, thread_type, ttl=120000)

            success_undo = 0
            for msg in to_undo:
                try:
                    client.deleteGroupMsg(msg['msgId'], client.uid, msg['cliMsgId'], msg['threadId'])
                    success_undo += 1
                    time.sleep(0.1)
                except:
                    pass

            client.replyMessage(Message(text=f"✅ ĐÃ THU HỒI THÀNH CÔNG {success_undo}/{len(to_undo)} TIN NHẮN RẢI."), message_object, thread_id, thread_type, ttl=120000)
            return

        # Hiển thị menu nếu lệnh không hợp lệ
        client.replyMessage(Message(text=rai_help_text()), message_object, thread_id, thread_type, ttl=120000)

    except Exception as e:
        logging.error(f"Lỗi xử lý lệnh rai: {e}")
        try:
            client.replyMessage(Message(text=f"❌ Lỗi: {str(e)}"), message_object, thread_id, thread_type, ttl=120000)
        except:
            pass

def PTA():
    # Gọi init_rai_json khi bot khởi động
    init_rai_json()
    return {
        'rai': handle_rai_command,
    }