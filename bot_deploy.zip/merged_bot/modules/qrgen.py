from zlapi.models import Message
import requests, os
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tạo QR code từ text/link",'power':"Thành viên"}

def handle_qrgen_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=1)
    if len(parts) < 2:
        client.replyMessage(Message(text=f"📱 Dùng: {PREFIX}qrgen <text hoặc link>"), message_object, thread_id, thread_type); return
    content = parts[1]
    try:
        url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={requests.utils.quote(content)}"
        r = requests.get(url, timeout=15)
        path = f"modules/cache/qr_{hash(content)}.png"
        with open(path,"wb") as f: f.write(r.content)
        client.sendLocalImage(path, thread_id=thread_id, thread_type=thread_type, message=Message(text=f"📱 QR Code: {content[:50]}"))
        os.remove(path)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'qrgen': handle_qrgen_command}
