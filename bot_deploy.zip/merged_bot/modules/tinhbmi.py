from zlapi.models import Message
from config import PREFIX

des = {'version':"1.0.0",'credits':"UltraBot",'description':"Tính chỉ số BMI",'power':"Thành viên"}

def handle_tinhbmi_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split()
    if len(parts) < 3:
        client.replyMessage(Message(text=f"⚖️ Dùng: {PREFIX}tinhbmi <cân nặng kg> <chiều cao cm>\nVí dụ: {PREFIX}tinhbmi 65 170"), message_object, thread_id, thread_type); return
    try:
        w, h = float(parts[1]), float(parts[2])/100
        bmi = w/(h*h)
        if bmi < 18.5: status = "😟 Thiếu cân"
        elif bmi < 25: status = "😊 Bình thường"
        elif bmi < 30: status = "⚠️ Thừa cân"
        else: status = "🔴 Béo phì"
        ideal_low = 18.5*h*h; ideal_high = 24.9*h*h
        msg = (f"⚖️ CHỈ SỐ BMI\n━━━━━━━━━━━━━━━\n"
               f"• Cân nặng: {parts[1]} kg\n• Chiều cao: {parts[2]} cm\n"
               f"• BMI: {bmi:.1f}\n• Đánh giá: {status}\n"
               f"• Cân nặng lý tưởng: {ideal_low:.1f} - {ideal_high:.1f} kg")
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập số hợp lệ"), message_object, thread_id, thread_type)

def PTA():
    return {'tinhbmi': handle_tinhbmi_command}
