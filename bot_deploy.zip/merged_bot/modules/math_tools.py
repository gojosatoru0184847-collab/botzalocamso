from zlapi.models import Message
import math

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Công cụ toán học nâng cao", 'power': "Thành viên"}

def _prime(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🔢 Dùng: .nguyen_to <số>"), message_object, thread_id, thread_type)
        return
    try:
        n = int(p[1])
        if n < 2:
            client.replyMessage(Message(text=f"❌ {n} không phải số nguyên tố."), message_object, thread_id, thread_type)
            return
        is_prime = n > 1 and all(n % i != 0 for i in range(2, int(math.sqrt(n))+1))
        client.replyMessage(Message(text=f"🔢 {n} {'LÀ' if is_prime else 'KHÔNG là'} số nguyên tố."), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập số hợp lệ."), message_object, thread_id, thread_type)

def _factorial(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🔢 Dùng: .giaithua <số>"), message_object, thread_id, thread_type)
        return
    try:
        n = int(p[1])
        if n < 0 or n > 20:
            client.replyMessage(Message(text="❌ Chỉ hỗ trợ 0-20"), message_object, thread_id, thread_type)
            return
        client.replyMessage(Message(text=f"🔢 {n}! = {math.factorial(n):,}"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập số hợp lệ."), message_object, thread_id, thread_type)

def _gcd_lcm(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 3:
        client.replyMessage(Message(text="🔢 Dùng: .gcd <a> <b>"), message_object, thread_id, thread_type)
        return
    try:
        a, b = int(p[1]), int(p[2])
        g = math.gcd(a, b)
        l = abs(a*b) // g if g else 0
        client.replyMessage(Message(text=f"🔢 ƯCLN({a},{b}) = {g}\n🔢 BCNN({a},{b}) = {l}"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Nhập 2 số hợp lệ."), message_object, thread_id, thread_type)

def _sqrt(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 2:
        client.replyMessage(Message(text="🔢 Dùng: .sqrt <số>"), message_object, thread_id, thread_type)
        return
    try:
        n = float(p[1])
        client.replyMessage(Message(text=f"🔢 √{n} = {math.sqrt(n):.6f}"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Không tính được căn bậc 2 của số âm."), message_object, thread_id, thread_type)

def _percent(message, message_object, thread_id, thread_type, author_id, client):
    p = message.strip().split()
    if len(p) < 3:
        client.replyMessage(Message(text="🔢 Dùng: .phan_tram <phần trăm> <tổng>\nVí dụ: .phan_tram 15 200000"), message_object, thread_id, thread_type)
        return
    try:
        pct, total = float(p[1]), float(p[2])
        result = pct * total / 100
        client.replyMessage(Message(text=f"🔢 {pct}% của {total:,.0f} = {result:,.2f}"), message_object, thread_id, thread_type)
    except:
        client.replyMessage(Message(text="❌ Lỗi nhập liệu."), message_object, thread_id, thread_type)

def PTA():
    return {
        'nguyen_to': _prime, 'isprime': _prime,
        'giaithua': _factorial, 'factorial': _factorial,
        'gcd': _gcd_lcm, 'ucln': _gcd_lcm,
        'sqrt': _sqrt, 'canbac2': _sqrt,
        'phan_tram': _percent, 'percent': _percent,
    }
