from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Đọc nội dung QR code từ ảnh (reply ảnh)", 'power': "Thành viên"}

def handle_readqr_command(message, message_object, thread_id, thread_type, author_id, client):
    quote = message_object.quote if hasattr(message_object, 'quote') else None
    if not quote:
        client.replyMessage(Message(text="📷 Vui lòng reply (quote) vào ảnh chứa QR để đọc."), message_object, thread_id, thread_type)
        return
    try:
        img_url = getattr(quote, 'attach', None) or getattr(quote, 'href', None)
        if not img_url:
            raise ValueError("Không tìm thấy ảnh trong tin nhắn quote")
        api_url = f"https://api.qrserver.com/v1/read-qr-code/?fileurl={img_url}"
        r = requests.get(api_url, timeout=10)
        data = r.json()
        content = data[0]["symbol"][0].get("data")
        if content:
            client.replyMessage(Message(text=f"📷 Nội dung QR:\n{content}"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text="❌ Không đọc được QR trong ảnh này."), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'readqr': handle_readqr_command, 'docqr': handle_readqr_command}
