from zlapi.models import Message
import requests

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Chuyển ảnh thành ASCII art", 'power': "Thành viên"}

def _ascii_art(message, message_object, thread_id, thread_type, author_id, client):
    quote = getattr(message_object, 'quote', None)
    if not quote:
        client.replyMessage(Message(text="🎨 Reply vào ảnh và gõ .ascii để chuyển thành ASCII art."), message_object, thread_id, thread_type); return
    try:
        from PIL import Image
        from io import BytesIO
        img_url = None
        if hasattr(quote, 'attach'):
            a = quote.attach
            if isinstance(a, str) and a.startswith('http'): img_url = a
            elif isinstance(a, dict): img_url = a.get('href') or a.get('url')
        if not img_url and hasattr(quote, 'href'): img_url = quote.href
        if not img_url: raise ValueError("Không tìm thấy URL ảnh")
        resp = requests.get(img_url, timeout=15)
        img = Image.open(BytesIO(resp.content)).convert('L')
        img = img.resize((40, 20))
        chars = "@#S%?*+;:,. "
        result = []
        for y in range(img.height):
            row = ""
            for x in range(img.width):
                px = img.getpixel((x,y))
                row += chars[int(px / 255 * (len(chars)-1))]
            result.append(row)
        client.replyMessage(Message(text="\n".join(result)), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'ascii': _ascii_art, 'asciiart': _ascii_art}
