from zlapi.models import Message
import hashlib

des = {'version': "1.0.0", 'credits': "UltraBot", 'description': "Tạo hash MD5/SHA256", 'power': "Thành viên"}

def handle_hash_command(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.strip().split(maxsplit=2)
    if len(parts) < 3:
        client.replyMessage(Message(text="🔐 Dùng: .hash md5/sha256 <text>"), message_object, thread_id, thread_type)
        return
    algo, text = parts[1].lower(), parts[2]
    try:
        if algo == "md5":
            result = hashlib.md5(text.encode()).hexdigest()
        elif algo == "sha256":
            result = hashlib.sha256(text.encode()).hexdigest()
        elif algo == "sha1":
            result = hashlib.sha1(text.encode()).hexdigest()
        else:
            raise ValueError("Chỉ hỗ trợ md5/sha1/sha256")
        client.replyMessage(Message(text=f"🔐 {algo.upper()}: {result}"), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(Message(text=f"❌ Lỗi: {e}"), message_object, thread_id, thread_type)

def PTA():
    return {'hash': handle_hash_command}
