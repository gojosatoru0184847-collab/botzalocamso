from zlapi.models import *
import time
import json

des = {
    'version': "1.0.2",
    'credits': "HOANG LAM",
    'description': "Tự động kết bạn tất cả thành viên trong các nhóm mà bot tham gia.",
    'power': "mem and admin"
}

def block_user(message, message_object, thread_id, thread_type, author_id, self):
    """
    Xử lý lệnh chặn người dùng.
    """
    try:
        if thread_type == ThreadType.USER:
            user_id = thread_id
        elif message_object.mentions:
            user_id = message_object.mentions[0]['uid']
        else:
            self.replyMessage(
                Message(text="🚦 Vui lòng tag người dùng để chặn hoặc dùng lệnh trong chat riêng."),
                message_object, thread_id, thread_type, ttl=60000
            )
            return

        user_info = self.fetchUserInfo(user_id)
        profile = user_info.changed_profiles.get(user_id, {})
        user_name = profile.get('zaloName', 'Không xác định')

        self.blockUser(user_id)
        self.replyMessage(
            Message(text=f"🚦 Đã chặn {user_name}."),
            message_object, thread_id, thread_type, ttl=60000
        )
    except Exception as e:
        self.replyMessage(
            Message(text=f"🚦 Không thể chặn người dùng. Lỗi: {str(e)}"),
            message_object, thread_id, thread_type, ttl=60000
        )

def unblock_user(message, message_object, thread_id, thread_type, author_id, self):
    """
    Xử lý lệnh bỏ chặn người dùng.
    """
    try:
        if thread_type == ThreadType.USER:
            user_id = thread_id
        elif message_object.mentions:
            user_id = message_object.mentions[0]['uid']
        else:
            self.replyMessage(
                Message(text="🚦 Vui lòng tag người dùng để bỏ chặn hoặc dùng trong chat riêng."),
                message_object, thread_id, thread_type, ttl=60000
            )
            return

        user_info = self.fetchUserInfo(user_id)
        profile = user_info.changed_profiles.get(user_id, {})
        user_name = profile.get('zaloName', 'Không xác định')

        self.unblockUser(user_id)
        self.replyMessage(
            Message(text=f"🚦 Đã bỏ chặn {user_name}."),
            message_object, thread_id, thread_type, ttl=60000
        )
    except Exception as e:
        self.replyMessage(
            Message(text=f"🚦 Không thể bỏ chặn người dùng. Lỗi: {str(e)}"),
            message_object, thread_id, thread_type, ttl=60000
        )

def add_friend(message, message_object, thread_id, thread_type, author_id, self):
    """
    Xử lý lệnh gửi lời mời kết bạn.
    """
    try:
        if thread_type == ThreadType.USER:
            user_id = thread_id
        else:
            if not message_object.mentions:
                self.replyMessage(
                    Message(text="🚦 Vui lòng tag người dùng để kết bạn. Ví dụ: @Lý Đức"),
                    message_object, thread_id, thread_type, ttl=60000
                )
                return
            user_id = message_object.mentions[0]['uid']

        if user_id == self.uid:
            self.replyMessage(
                Message(text="🚦 Không thể gửi lời mời kết bạn cho chính mình."),
                message_object, thread_id, thread_type, ttl=60000
            )
            return

        user_info = self.fetchUserInfo(user_id)
        profile = user_info.changed_profiles.get(user_id, {})
        user_name = profile.get('zaloName', 'Không xác định')

        self.sendFriendRequest(user_id, "Xin chào, mình muốn kết bạn!")
        self.replyMessage(
            Message(text=f"🚦 Đã gửi lời mời kết bạn đến {user_name}."),
            message_object, thread_id, thread_type, ttl=60000
        )
    except Exception as e:
        self.replyMessage(
            Message(text=f"🚦 Không thể kết bạn người dùng. Lỗi: {str(e)}"),
            message_object, thread_id, thread_type, ttl=60000
        )

def remove_friend(message, message_object, thread_id, thread_type, author_id, self):
    """
    Xử lý lệnh xóa kết bạn.
    """
    try:
        if thread_type == ThreadType.USER:
            user_id = thread_id
        else:
            if not message_object.mentions:
                self.replyMessage(
                    Message(text="🚦 Vui lòng tag người dùng để xóa kết bạn. Ví dụ: @Lý Đức"),
                    message_object, thread_id, thread_type, ttl=60000
                )
                return
            user_id = message_object.mentions[0]['uid']

        if user_id == self.uid:
            self.replyMessage(
                Message(text="🚦 Không thể xóa kết bạn chính mình."),
                message_object, thread_id, thread_type, ttl=60000
            )
            return

        user_info = self.fetchUserInfo(user_id)
        profile = user_info.changed_profiles.get(user_id, {})
        user_name = profile.get('zaloName', 'Không xác định')

        self.unfriendUser(user_id)
        self.replyMessage(
            Message(text=f"🚦 Đã xóa kết bạn với {user_name}."),
            message_object, thread_id, thread_type, ttl=60000
        )
    except Exception as e:
        self.replyMessage(
            Message(text=f"🚦 Không thể xóa kết bạn người dùng. Lỗi: {str(e)}"),
            message_object, thread_id, thread_type, ttl=60000
        )

def add_group_friends(message, message_object, thread_id, thread_type, author_id, self):
    """
    Lệnh này sẽ kết bạn với tất cả thành viên trong nhóm.
    """
    if thread_type != ThreadType.GROUP:
        self.replyMessage(
            Message(text="🚦 Lệnh này chỉ hoạt động trong nhóm."),
            message_object, thread_id, thread_type, ttl=60000
        )
        return

    try:
        group_info = self.fetchGroupInfo(thread_id).gridInfoMap.get(thread_id)
        if not group_info:
            self.replyMessage(
                Message(text="🚦 Không thể lấy thông tin nhóm."),
                message_object, thread_id, thread_type, ttl=60000
            )
            return

        members = group_info.get('memVerList', [])
        total_members = len(members)
        if total_members == 0:
            self.replyMessage(
                Message(text="🚦 Nhóm không có thành viên nào."),
                message_object, thread_id, thread_type, ttl=60000
            )
            return

        self.replyMessage(
            Message(text=f"🚦 Đang gửi lời mời kết bạn đến {total_members} thành viên trong nhóm..."),
            message_object, thread_id, thread_type, ttl=60000
        )

        success = fail = batch = 0
        limit = 50

        for mem in members:
            user_id = mem.get('uid') if isinstance(mem, dict) else mem.split('_')[0]
            if user_id == self.uid:
                continue

            try:
                user_info = self.fetchUserInfo(user_id)
                profile = user_info.changed_profiles.get(user_id, {})
                user_name = profile.get('zaloName', 'Không xác định')

                self.sendFriendRequest(user_id, f"Xin chào {user_name}, mình muốn kết bạn!")

                success += 1
                batch += 1
                time.sleep(0.1 if batch < 10 else 0.5)

                if batch >= 10:
                    batch = 0

                if success >= limit:
                    self.replyMessage(
                        Message(text=f"🚦 Đã đạt giới hạn {limit} lời mời. Dừng lại để tránh bị chặn."),
                        message_object, thread_id, thread_type, ttl=60000
                    )
                    break
            except Exception as e:
                fail += 1
                print(f"Lỗi khi gửi yêu cầu kết bạn cho {user_id}: {str(e)}")
                time.sleep(0.2)

        self.replyMessage(
            Message(text=f"🚦 Hoàn tất: {success} thành công, {fail} thất bại."),
            message_object, thread_id, thread_type, ttl=60000
        )
    except Exception as e:
        self.replyMessage(
            Message(text=f"🚦 Lỗi khi xử lý lệnh nhóm: {str(e)}"),
            message_object, thread_id, thread_type, ttl=60000
        )


def handle_invalid_command(message, message_object, thread_id, thread_type, author_id, self):
    """
    Xử lý lệnh không hợp lệ.
    """
    self.replyMessage(
        Message(text="🚦 Lệnh không hợp lệ. Vui lòng sử dụng các lệnh: add, remove, block, unblock, addgr"),
        message_object, thread_id, thread_type, ttl=60000
    )

def PTA():
    """
    Trả về dictionary chứa các lệnh xử lý.
    """
    return {
        'block': block_user,
        'unblock': unblock_user,
        'add': add_friend,
        'remove': remove_friend,
        'addgr': add_group_friends,
        'kb': add_group_friends # ĐẶT ALIAS THEO Ý ĐẠI CA
    }
