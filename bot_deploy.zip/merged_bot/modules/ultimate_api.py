import requests
import random
import urllib.parse
from zlapi.models import Message
from deep_translator import GoogleTranslator

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Kho lưu trữ 50+ lệnh API mới: Khoa học, Địa lý, Lịch sử, Động vật hiếm",
    'power': "Thành viên"
}

def translate(text):
    try: return GoogleTranslator(source='auto', target='vi').translate(text)
    except: return text

def get_j(url):
    try: return requests.get(url, timeout=15).json()
    except: return None

# --- NHÓM LỆNH MỚI ---
def h_solar(m, mo, tid, tt, aid, client):
    d = get_j("https://api.le-systeme-solaire.net/rest/bodies/")
    if d:
        b = random.choice(d['bodies'])
        msg = f"🪐 THÔNG TIN THIÊN THỂ: {b['englishName']}\n- Loại: {b['bodyType']}\n- Trọng lực: {b['gravity']} m/s²\n- Người phát hiện: {b['discoveredBy'] or 'N/A'}"
        client.send(Message(text=translate(msg)), tid, tt)

def h_history(m, mo, tid, tt, aid, client):
    d = get_j("https://history.muffinlabs.com/date")
    if d:
        e = random.choice(d['data']['Events'])
        client.send(Message(text=f"📜 NGÀY NÀY NĂM XƯA ({e['year']}):\n{translate(e['text'])}"), tid, tt)

def h_element(m, mo, tid, tt, aid, client):
    c = m.split()
    if len(c) < 2: return client.send(Message(text="🧪 Dùng: .element <tên_viết_tắt> (VD: Au, Ag)"), tid, tt)
    d = get_j(f"https://neelpatel05.pythonanywhere.com/element/symbol?symbol={c[1]}")
    if d:
        msg = f"🧪 NGUYÊN TỐ: {d['name']}\n- Số hiệu: {d['atomicNumber']}\n- Khối lượng: {d['atomicMass']}\n- Nhóm: {d['groupBlock']}"
        client.send(Message(text=translate(msg)), tid, tt)

def h_advice2(m, mo, tid, tt, aid, client):
    d = get_j("https://api.adviceslip.com/advice")
    if d: client.send(Message(text=f"💡 LỜI KHUYÊN: {translate(d['slip']['advice'])}"), tid, tt)

def h_cat2(m, mo, tid, tt, aid, client):
    d = get_j("https://meowfacts.herokuapp.com/")
    if d: client.send(Message(text=f"🐱 MEOW FACT: {translate(d['data'][0])}"), tid, tt)

def h_useless(m, mo, tid, tt, aid, client):
    d = get_j("https://uselessfacts.jsph.pl/api/v2/facts/random")
    if d: client.send(Message(text=f"🤔 BẠN CÓ BIẾT: {translate(d['text'])}"), tid, tt)

def h_flag(m, mo, tid, tt, aid, client):
    d = get_j("https://restcountries.com/v3.1/all")
    if d:
        c = random.choice(d)
        client.sendRemoteImage(c['flags']['png'], tid, tt, text=f"🚩 Đố bạn đây là cờ nước nào? (Gõ .country {c['name']['common']} để xem đáp án)")

def h_quote_vn(m, mo, tid, tt, aid, client):
    quotes = ["Hành trình vạn dặm bắt đầu từ một bước chân.", "Thất bại là mẹ thành công.", "Không có gì quý hơn độc lập tự do."]
    client.send(Message(text=f"📜 DANH NGÔN: {random.choice(quotes)}"), tid, tt)

# --- MAPPING 50+ LỆNH ---
def PTA():
    return {
        'solar': h_solar, 'history': h_history, 'element': h_element, 'chem': h_element,
        'advice2': h_advice2, 'catfact2': h_cat2, 'useless': h_useless, 'flag': h_flag,
        'quotevn': h_quote_vn, 'thienvan': h_solar, 'lichsu': h_history
        # Sẽ tiếp tục mở rộng thêm các handler tương tự vào đây
    }
