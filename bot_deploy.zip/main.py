# -*- coding: utf-8 -*-
import json, os, time, sys, random, re, io, threading, logging, urllib.parse, queue, signal
from concurrent.futures import ThreadPoolExecutor
import requests
from colorama import Fore, Style, init

# Ép mã hóa UTF-8 toàn diện
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

from zlapi import ZaloAPI
from zlapi.models import *
from config import API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES, ADMIN, PREFIX
from PTA import CommandHandler
from logging_utils import Logging
from event.event import handleGroupEvent

# VERSION SIÊU TỐC - SOLO ACC v9.4.0
VERSION = "9.4.0"

# --- DUMMY WEB SERVER CHO RENDER ---
import http.server
import socketserver

def run_dummy_server():
    port = int(os.environ.get("PORT", 8080))
    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass # Tắt log để đỡ rác console
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"Bot Zalo is running!")

    class ReusableTCPServer(socketserver.TCPServer):
        allow_reuse_address = True

    with ReusableTCPServer(("", port), QuietHandler) as httpd:
        print(f"[*] Dummy web server đang lắng nghe tại port {port} (Dành cho Render/Replit)")
        httpd.serve_forever()

# Khởi chạy server ẩn
threading.Thread(target=run_dummy_server, daemon=True).start()
# -----------------------------------

# Import handlers
from modules.autojoin import AutoJoinHandler, process_message_for_autojoin
from modules.bot import BotStatusHandler
from commands.bcmd import BcmdHandler
from commands.lockbot import LockBotHandler
from commands.whitelist import WhitelistHandler
from modules.menu import handle_menu as handle_menu_commands
from modules.getfile import process_incoming_files as process_mod_files
from modules.tele_getfile import run_tele_thread as start_tele_bot
from modules.auto_acc import startup_auto_acc
from modules.blacklist import load_blacklist

init(autoreset=True)
logger = Logging()

# PHÂN LUỒNG SIÊU TỐC
cmd_executor = ThreadPoolExecutor(max_workers=50)
bg_executor = ThreadPoolExecutor(max_workers=20)

# Silent Mode
logging.getLogger('telethon').setLevel(logging.CRITICAL)
logging.getLogger('urllib3').setLevel(logging.CRITICAL)
logging.getLogger('requests').setLevel(logging.CRITICAL)

class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        self.uid = "0"
        self.prefix = PREFIX
        self.settings = self.load_settings() or {}
        self.ADMIN = str(self.settings.get("admin") or ADMIN)
        self.ADM = [str(uid) for uid in self.settings.get("adm", [])]
        self.duyetbox_data = self.load_duyetbox_data() or []
        self.duyetbox_cache = set(str(gid) for gid in self.duyetbox_data)

        # 1. ĐĂNG NHẬP
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)

        # 2. LẤY UID CHÍNH XÁC
        try:
            info = self.fetchAccountInfo()
            if info and hasattr(info, 'profile'):
                self.uid = str(info.profile.get('userId', '0'))

            # Nếu ADMIN chưa đặt hoặc là placeholder, dùng chính UID của bot
            placeholders = ["YOUR_ADMIN_UID_HERE", "7937063360273684610", "0", "None", ""]
            if not self.ADMIN or self.ADMIN in placeholders:
                self.ADMIN = self.uid

            print(Fore.GREEN + f"🚀 Bot Solo SIÊU TỐC Online! UID: {self.uid}", flush=True)
            print(Fore.CYAN + f"👑 Quyền Admin Chính: {self.ADMIN}", flush=True)
        except Exception as e:
            print(Fore.YELLOW + f"⚠️ Cảnh báo: Không thể lấy UID chính xác: {e}")

        # 3. KHỞI TẠO HANDLER
        self.bcmd_handler = BcmdHandler(self)
        self.lockbot_handler = LockBotHandler(self)
        self.whitelist_handler = WhitelistHandler(self)
        self.autojoin_handler = AutoJoinHandler(self)
        self.bot_status_handler = BotStatusHandler(self)
        self.command_handler = CommandHandler(self)

    def load_duyetbox_data(self):
        try:
            path = "modules/cache/duyetboxdata.json"
            if os.path.exists(path):
                with open(path, "r") as f: return json.load(f)
        except: return []

    def load_settings(self):
        try:
            with open("seting.json", "r", encoding='utf-8') as f: return json.load(f)
        except: return {}

    def is_super_admin(self, author_id):
        aid = str(author_id) if author_id else "None"
        # Tự động nhận diện admin nếu UID trùng với bot hoặc nằm trong danh sách ADM
        return (aid == str(self.uid) or
                aid == str(self.ADMIN) or
                aid in [str(x) for x in self.ADM] or
                aid == "None" or
                aid == "0")

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        if not author_id or str(author_id) in ["None", "0"]: author_id = self.uid

        # --- KIỂM TRA MUTE (KHÓA MÕM) ---
        from modules.mute import load_mute_list
        mute_list = load_mute_list()
        if str(thread_id) in mute_list:
            muted_users = mute_list[str(thread_id)]
            if str(author_id) in muted_users:
                # Nếu bị mute, bot sẽ tự động thu hồi tin nhắn của người đó
                try:
                    self.deleteMessage(mid, thread_id, thread_type)
                except: pass
                return # Dừng xử lý các lệnh khác

        # --- XỬ LÝ TÁC VỤ NGẦM (Luôn chạy cho mọi tin nhắn, kể cả không có text) ---
        from modules.blacklist import load_blacklist
        if str(thread_id) not in load_blacklist():
            # Xử lý lấy file tự động
            bg_executor.submit(process_mod_files, self, message_object, thread_id, thread_type)
            # Xử lý tự động join nhóm (nếu có link trong text)
            msg_text_for_join = message.text if isinstance(message, Message) else str(message)
            if msg_text_for_join:
                bg_executor.submit(process_message_for_autojoin, self, message_object, thread_id, thread_type, author_id, msg_text_for_join, mid, logger)

        msg_text = message.text if isinstance(message, Message) else str(message)
        if not msg_text: return

        # Kiểm tra Prefix nhanh
        is_cmd = msg_text.startswith(self.prefix) or msg_text.startswith(".")

        # Đẩy vào executor cho lệnh
        cmd_executor.submit(self._handle_ultra_fast, str(author_id), msg_text, message_object, thread_id, thread_type, mid, is_cmd)

    def _handle_ultra_fast(self, author_id, message_text, message_object, thread_id, thread_type, mid, is_cmd):
        try:
            is_me = self.is_super_admin(author_id)

            if is_cmd:
                msg_low = message_text.lower()
                parts = msg_low[1:].strip().split() if message_text.startswith(".") else msg_low[len(self.prefix):].strip().split()
                if parts:
                    cmd_name = parts[0]
                    if is_me:
                        if cmd_name == "ping":
                            self.replyMessage(Message(text="⚡️ SIÊU TỐC: 0.001s!"), message_object, thread_id, thread_type)
                            return
                        if cmd_name == "uid":
                            self.replyMessage(Message(text=f"👤 UID: {author_id}"), message_object, thread_id, thread_type)
                            return

                    is_approved = str(thread_id) in self.duyetbox_cache
                    if is_me or is_approved:
                        if cmd_name == "bot" and "on" in msg_low and is_me:
                            self.bot_status_handler.handle_bot_command(message_text, message_object, thread_id, thread_type, author_id)
                            self.duyetbox_cache = set(str(gid) for gid in self.load_duyetbox_data())
                            return
                        self.command_handler.handle_command(message_text, author_id, message_object, thread_id, thread_type)
        except Exception as e:
            logger.error(f"Error in _handle_ultra_fast: {e}")

    def onGroupEvent(self, event_type, event_data, thread_id, author_id):
        bg_executor.submit(handleGroupEvent, self, event_type, event_data, thread_id, author_id)

def shutdown(signum, frame):
    sys.exit(0)

signal.signal(signal.SIGINT, shutdown)
signal.signal(signal.SIGTERM, shutdown)

def start_bot():
    retry_count = 0
    max_retries = 20

    while retry_count < max_retries:
        try:
            with open("seting.json", "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    raise ValueError("seting.json is empty")
                cfg = json.loads(content)

            client = Client(API_KEY, SECRET_KEY, cfg.get("imei"), cfg.get("session_cookies"))

            if not getattr(sys, '_tele_started', False):
                threading.Thread(target=start_tele_bot, args=(client,), daemon=True, name="TeleThread").start()
                threading.Thread(target=startup_auto_acc, args=(client,), daemon=True, name="AutoAccThread").start()
                setattr(sys, '_tele_started', True)

            print(Fore.CYAN + "📡 Bot is listening for messages...")
            client.listen(type="websocket", thread=False, run_forever=True, reconnect=10)
            break

        except Exception as e:
            retry_count += 1
            wait_time = min(60, retry_count * 5)
            import traceback
            print(Fore.RED + f"🛑 LỖI KHỞI ĐỘNG (Lần {retry_count}/{max_retries}): {e}")

            if "getaddrinfo failed" in str(e) or "connection" in str(e).lower():
                print(Fore.YELLOW + f"🌐 Lỗi mạng hoặc DNS. Đang thử lại sau {wait_time}s...")
            else:
                traceback.print_exc()

            if retry_count < max_retries:
                time.sleep(wait_time)
            else:
                print(Fore.RED + "❌ Đã đạt giới hạn số lần thử lại. Bot sẽ dừng.")
                sys.exit(1)

if __name__ == "__main__":
    start_bot()
