import sys
import io

# Đảm bảo môi trường luôn là UTF-8
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except:
        pass

class Logging:
    def __init__(self, theme="default", text_color="white", log_text_color="black"):
        self.reset = "\x1b[0m"
        self.red = "\x1b[41m"
        self.blue = "\x1b[44m"
        self.green = "\x1b[42m"
        self.white = "\x1b[37m"
        self.black = "\x1b[30m"
        self.orange = "\x1b[43m"
        self.yellow = "\x1b[43m"
        self.magenta = "\x1b[45m"
        self.light_pink_bg = "\x1b[48;2;255;182;193m"
        self.textcolor = "\x1b[37m"
        self.log_text_color = "\x1b[30m"
        self.purple = "\x1b[48;2;196;181;253m"
        self.cyan = "\x1b[48;2;139;233;253m"

    def format_log(self, level: str, color: str, text: str, icon: str = "") -> None:
        try:
            icon_part = f" {icon}" if icon else ""
            log_msg = f"{color} {self.log_text_color}{level}{icon_part} {self.reset} {self.textcolor}{text}{self.reset}"
            print(log_msg)
        except:
            try:
                # Nếu vẫn lỗi, in dạng đơn giản nhất không màu, không icon
                print(f"[{level}] {str(text).encode('ascii', 'ignore').decode('ascii')}")
            except:
                pass
    
    def logger(self, text1: str, text: str) -> None:
        try:
            print(f"{self.light_pink_bg}{self.black} {text1} {self.reset} {self.textcolor}{text}{self.reset}")
        except:
            pass
    
    def restart(self, text: str) -> None: self.format_log("RESTART", self.green, str(text), "🔄")
    def success(self, text: str) -> None: self.format_log("SUCCESS", self.green, str(text), "✅")
    def error(self, text: str) -> None: self.format_log("ERROR", self.red, str(text), "❌")
    def prefixcmd(self, text: str) -> None: self.format_log("PREFIX", self.cyan, str(text), "🤖")
    def warning(self, text: str) -> None: self.format_log("WARN", self.orange, str(text), "⚠️")
    def log(self, text: str) -> None: self.format_log("LOG", self.green, str(text), "📝")
    def info(self, text: str) -> None: self.format_log("INFO", self.blue, str(text), "🚦")
    def debug(self, text: str) -> None: self.format_log("DEBUG", self.purple, str(text), "🐛")
    def loading(self, text: str) -> None: self.format_log("LOAD", self.magenta, str(text), "⏳")
    def complete(self, text: str) -> None: self.format_log("DONE", self.green, str(text), "🎉")
