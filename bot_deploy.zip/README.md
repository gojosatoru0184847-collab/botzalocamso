# 🤖 ULTRA BOT ZALO — 317 Lệnh · 191 Modules · 0 Lỗi

Bot Zalo quản lý nhóm toàn diện, gộp từ 25 bot nguồn mở.

---

## ⚙️ CẤU HÌNH (seting.json)

```json
{
  "prefix": ".",
  "name_bot": "ULTRA BOT",
  "admin": "YOUR_ADMIN_UID",
  "imei": "",
  "session_cookies": {}
}
```

## 🚀 KHỞI ĐỘNG

```bash
pip install -r requirements.txt
python main.py
```

Chưa có session → Bot hiện **QR trên terminal** → Quét bằng Zalo.

---

## 📋 TỔNG HỢP 317 LỆNH

### 🔧 QUẢN LÝ NHÓM (Admin)
kick · ban · unban · mute · unmute · admin · kickall · delall · leave · join · make
welcome · tagall · tagam · groupinfo · findmem · duyetmem · thread · stg · lgr
rename · outgrp · tb · testwelcome · backupnhom · setdesc · countmem · pinlink

### 🛡 BẢO VỆ NHÓM (Commands/)
antisp · antilink · anticard · antifile · antiphoto · antivideo · antistk
antiundo · antiricon · antiall · cam · whitelist · lbot · unlbot · bot · bcmd · afk

### 🎮 GAMES
taixiu · baucua · roulette · chanle · xidach · caro · noitu · bingo · hangman · wordle
wordlevn · quiz · doanso · xucxac · doanchu · doantu · kbb · snake · memory · react

### 🔮 TỬ VI / GIẢI TRÍ
tuvi · xinxam · boibai · boibai · tinhduyen · spinwheel · fakeinfo

### 📡 TRA CỨU / API
thoitiet · thoitiet2 · tt · weather · tygia · giavang · coin · stock
ipinfo · whois · wikivn · anime · movie · tiktokinfo · iginfo · github · npm · pypi
nutrition · covid · amlich · tintuc · tinnhanh · tracuu_bks · tudien

### 🔧 TIỆN ÍCH
calc · tinh · bmi · tinhtuoi · calo · nuocuong · convert · gioqt · countdown
base64 · hash · jsonfmt · regextest · color · textcase · daonguoc · demtu · bodau
encode · decode · mahoa · giama · morse · decor · emoji · shorten · rutgon
roman · bin · hexnum · genpass · mkpass · genpin · uuid · random · chon · xaotron
qrgen · readqr · ocr · ascii · speedtest · nettest · sysinfo · ping · uptime

### 📝 GHI CHÚ / CÔNG VIỆC
ghichu · listnote · xoagc · todo · remind · nhacnho · poll · binhchon

### 📊 HỆ THỐNG TIỀN / XP
money · mybank · xp · level · topxp · topchat

### 🎵 MEDIA
yt · scl · sound · voice · getvoice · lyrics · loi · stk · gt

### 📢 TỰ ĐỘNG HÓA
adv · autojoin · autosend · atlk · rai · tba

### 🌐 MẠNG XÃ HỘI
shareao · iginfo · tiktokinfo · searchtiktok · stiktok · github · npm · pypi
