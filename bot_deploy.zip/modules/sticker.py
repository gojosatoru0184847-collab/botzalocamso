import requests
import subprocess
import json
import urllib.parse
import os
from io import BytesIO
from PIL import Image, ImageDraw
from zlapi.models import Message, MultiMsgStyle, MessageStyle
from zlapi._threads import ThreadType
import time
import random

des = {
    'version': "2.2.0",
    'credits': "HOANG LAM",
    'description': "Tạo sticker từ ảnh, GIF, video (Zalo Compatible).",
    'power': "Thành viên"
}

def get_file_type(url):
    try:
        response = requests.head(url, allow_redirects=True, timeout=5)
        content_type = response.headers.get("Content-Type", "").lower()
        if "image" in content_type:
            return "image"
        elif "video" in content_type:
            return "video"
        return "unknown"
    except requests.RequestException:
        return "unknown"

def upload_to_quax(file_path):
    """Máy chủ upload cực mạnh và ổn định cho Zalo"""
    try:
        url = 'https://qu.ax/upload.php'
        with open(file_path, 'rb') as f:
            files = {'files[]': f}
            response = requests.post(url, files=files, timeout=15)

        if response.status_code == 200:
            data = response.json()
            if data.get('success') and data.get('files'):
                return data['files'][0].get('url')
        return None
    except Exception as e:
        print(f"Lỗi Quax: {e}")
        return None

def upload_to_tmpfiles(file_path):
    try:
        with open(file_path, "rb") as f:
            files = {'file': f}
            response = requests.post("https://tmpfiles.org/api/v1/upload", files=files, timeout=15)
        if response.status_code == 200:
            data = response.json()
            url = data.get('data', {}).get('url')
            if url:
                # Link trực tiếp cho Zalo
                return url.replace("https://tmpfiles.org/", "https://tmpfiles.org/dl/")
        return None
    except:
        return None

def convert_media_and_upload(media_url, file_type, unique_id):
    script_dir = os.path.dirname(__file__)
    temp_dir = os.path.join(script_dir, 'cache', 'temp')
    os.makedirs(temp_dir, exist_ok=True)

    temp_input = os.path.join(temp_dir, f"stk_in_{unique_id}")
    temp_webp = os.path.join(temp_dir, f"stk_out_{unique_id}.webp")
    files_to_cleanup = [temp_input, temp_webp]

    try:
        # Tải media về
        response = requests.get(media_url, stream=True, timeout=15)
        response.raise_for_status()
        with open(temp_input, "wb") as f:
            for chunk in response.iter_content(8192):
                f.write(chunk)

        if file_type == "image":
            with Image.open(temp_input).convert("RGBA") as img:
                # Resize chuẩn Sticker Zalo (512x512)
                img.thumbnail((512, 512), Image.Resampling.LANCZOS)
                width, height = img.size

                # Tạo canvas vuông để sticker không bị méo
                new_img = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
                new_img.paste(img, ((512 - width) // 2, (512 - height) // 2))

                # Nén WebP chất lượng tốt nhưng dung lượng thấp (< 1MB)
                new_img.save(temp_webp, format="WEBP", quality=80, lossless=False)
        else: # video/gif
            subprocess.run([
                "ffmpeg", "-y", "-i", temp_input,
                "-vf", "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000",
                "-c:v", "libwebp_anim",
                "-loop", "0",
                "-r", "12", # Giảm fps để dung lượng cực nhẹ
                "-an",
                "-lossless", "0",
                "-q:v", "60", # Nén mạnh hơn cho video
                "-loglevel", "error",
                temp_webp
            ], check=True)

        # Lấy kích thước thật
        with Image.open(temp_webp) as stk_img:
            stk_w, stk_h = stk_img.size

        # Thử upload qua Quax (Ưu tiên số 1 cho Zalo)
        url = upload_to_quax(temp_webp)
        if not url:
            url = upload_to_tmpfiles(temp_webp)

        return url, stk_w, stk_h

    except Exception as e:
        print(f"Lỗi xử lý Sticker: {e}")
        raise e
    finally:
        for f in files_to_cleanup:
            if os.path.exists(f):
                try: os.remove(f)
                except: pass

def handle_stk_command(message, message_object, thread_id, thread_type, author_id, client):
    if not getattr(message_object, 'quote', None) or not getattr(message_object, 'quote', None).attach:
        client.replyMessage(
            Message(text="➜ Vui lòng reply vào ảnh/gif/video để tạo sticker."),
            message_object, thread_id, thread_type, ttl=30000
        )
        return

    try:
        attach_data = json.loads(getattr(message_object, 'quote', None).attach)
    except:
        client.replyMessage(Message(text="➜ Dữ liệu không hợp lệ."), message_object, thread_id, thread_type)
        return

    media_url = attach_data.get('hdUrl') or attach_data.get('href')
    if not media_url:
        client.replyMessage(Message(text="➜ Không tìm thấy URL."), message_object, thread_id, thread_type)
        return

    media_url = urllib.parse.unquote(media_url.replace("\\/", "/"))
    file_type = get_file_type(media_url)

    if file_type not in ["image", "video"]:
        client.replyMessage(Message(text="➜ Chỉ hỗ trợ Ảnh, GIF hoặc Video ngắn."), message_object, thread_id, thread_type)
        return

    client.sendReaction(message_object, "⏳", thread_id, thread_type)

    try:
        unique_id = f"{thread_id}_{int(time.time())}"
        webp_url, stk_w, stk_h = convert_media_and_upload(media_url, file_type, unique_id)
        
        if not webp_url:
            raise Exception("Lỗi server upload. Vui lòng thử lại.")

        # LOG URL để debug nếu cần
        print(f"🚀 STICKER READY: {webp_url}")

        res = client.sendCustomSticker(
            animationImgUrl=webp_url,
            staticImgUrl=webp_url,
            thread_id=thread_id,
            thread_type=thread_type,
            width=stk_w,
            height=stk_h
        )

        if res and (isinstance(res, dict) and res.get('error_code') != 0):
            raise Exception(f"Zalo từ chối sticker (Code {res.get('error_code')})")

        client.sendReaction(message_object, "✅", thread_id, thread_type)

    except Exception as e:
        client.replyMessage(Message(text=f"➜ Lỗi: {e}"), message_object, thread_id, thread_type)
        client.sendReaction(message_object, "❌", thread_id, thread_type)

def PTA():
    return {'stk': handle_stk_command}
