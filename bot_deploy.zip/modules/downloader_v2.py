# -*- coding: utf-8 -*-
import os
import sys
import threading
import time
import requests
import subprocess
import shutil
from zlapi.models import Message, ThreadType
from config import PREFIX

# Thêm đường dẫn tới folder 'files' để import được các module của Claude
FILES_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "files")
if FILES_DIR not in sys.path:
    sys.path.append(FILES_DIR)

# Import các module từ folder files
try:
    from cmd_nhac import run as run_nhac
    from cmd_gg import run as run_gg
    from cmd_tiktok import run as run_tiktok
    from cmd_scl import run as run_scl
    from cmd_zingmp3 import run as run_zingmp3
    from cmd_soda import run as run_soda
    from cmd_fb import run as run_fb
    from cmd_dl import run as run_dl
except Exception as e:
    print(f"⚠️ [DL v2 ERROR] Không thể nạp module từ 'files': {e}")
    def stub(*args, **kwargs): return {"type": "text", "content": f"❌ Lỗi: {e}"}
    run_nhac = run_gg = run_tiktok = run_scl = run_zingmp3 = run_soda = run_fb = run_dl = stub

# Đường dẫn ffmpeg có sẵn trong project
FFMPEG_EXE = os.path.join(os.getcwd(), "ffmpeg.exe")

def convert_to_aac_voice(input_path):
    output_path = os.path.splitext(input_path)[0] + "_voice.aac"
    try:
        cmd = [
            FFMPEG_EXE, "-y", "-i", input_path,
            "-c:a", "aac", "-b:a", "64k", "-ar", "44100", "-ac", "1",
            "-f", "adts", output_path
        ]
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if os.path.exists(output_path):
            return output_path
    except Exception as e:
        print(f"❌ [FFMPEG] Lỗi convert AAC: {e}")
    return input_path

def upload_to_host(file_path):
    try:
        with open(file_path, 'rb') as f:
            r = requests.post("https://catbox.moe/user/api.php",
                             data={"reqtype": "fileupload"},
                             files={"fileToUpload": f},
                             timeout=30)
            r.raise_for_status()
            return r.text.strip()
    except Exception as e:
        print(f"❌ [UPLOAD] Lỗi đẩy file: {e}")
        return None

def handle_claude_dl(message, message_object, thread_id, thread_type, author_id, client, handler_func, cmd_name):
    parts = message.split(" ", 1)
    args = parts[1].strip() if len(parts) > 1 else ""

    if not args:
        client.replyMessage(Message(text=f"⚠️ Đại ca thiếu link hoặc từ khóa rồi! Dùng: {PREFIX}{cmd_name} [link/nội dung]"), message_object, thread_id, thread_type)
        return

    client.sendReaction(message_object, "⏳", thread_id, thread_type)

    def worker():
        try:
            result = handler_func(args, message=message_object)
            if not result: return

            if result.get("type") == "text":
                client.replyMessage(Message(text=result["content"]), message_object, thread_id, thread_type)

            elif result.get("type") == "file":
                caption = result.get("caption", "")
                final_url = result.get("url")
                file_path = result.get("path")
                is_video = (".mp4" in str(final_url or file_path).lower() or cmd_name in ["tt", "fb"])

                if not is_video:
                    if not file_path and final_url:
                        client.replyMessage(Message(text=f"📥 Đang chuẩn bị tin nhắn thoại cho Đại ca..."), message_object, thread_id, thread_type)
                        tmp_path = os.path.join(os.getcwd(), f"temp_voice_{int(time.time())}.mp3")
                        with requests.get(final_url, stream=True) as r:
                            with open(tmp_path, 'wb') as f:
                                for chunk in r.iter_content(chunk_size=8192): f.write(chunk)
                        file_path = tmp_path
                    if file_path and os.path.exists(file_path):
                        aac_path = convert_to_aac_voice(file_path)
                        final_url = upload_to_host(aac_path)
                        if aac_path != file_path:
                            try: os.remove(aac_path)
                            except: pass
                elif not final_url and file_path and os.path.exists(file_path):
                    client.replyMessage(Message(text=f"📤 Đang bế video về cho Đại ca..."), message_object, thread_id, thread_type)
                    final_url = upload_to_host(file_path)

                if not final_url:
                    client.replyMessage(Message(text="❌ Lỗi: Không thể lấy link để gửi về Zalo."), message_object, thread_id, thread_type)
                    return

                if is_video:
                    client.replyMessage(Message(text=f"🎬 Đang bế video về cho Đại ca..."), message_object, thread_id, thread_type)
                    client.sendRemoteFile(final_url, thread_id, thread_type, fileName=f"{caption[:30]}.mp4")
                else:
                    client.replyMessage(Message(text=f"🎤 Tin nhắn thoại: {caption}"), message_object, thread_id, thread_type)
                    client.sendRemoteVoice(final_url, thread_id, thread_type)

                if file_path and os.path.exists(file_path):
                    def deep_cleanup():
                        time.sleep(10)
                        try:
                            parent_dir = os.path.dirname(file_path)
                            if "downloads" in parent_dir.lower() and os.path.basename(parent_dir) != "downloads":
                                shutil.rmtree(parent_dir, ignore_errors=True)
                                print(f"🧹 [CLEANUP] Đã dọn sạch thư mục: {parent_dir}")
                            else:
                                if os.path.exists(file_path): os.remove(file_path)
                        except Exception as ce:
                            print(f"⚠️ [CLEANUP] Lỗi dọn dẹp: {ce}")
                    threading.Thread(target=deep_cleanup, daemon=True).start()
        except Exception as e:
            client.replyMessage(Message(text=f"❌ Hệ thống tải gặp lỗi: {e}"), message_object, thread_id, thread_type)

    threading.Thread(target=worker, daemon=True).start()

def handle_tiktok(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_tiktok, "tt")
def handle_fb(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_fb, "fb")
def handle_scl(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_scl, "scl")
def handle_zing(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_zingmp3, "zing")
def handle_nhac(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_nhac, "nhac")
def handle_soda(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_soda, "soda")
def handle_dl(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_dl, "dl")
def handle_gg(m, mo, tid, tt, aid, c): handle_claude_dl(m, mo, tid, tt, aid, c, run_gg, "gg")

def PTA():
    return {
        'tt': handle_tiktok,
        'tiktok': handle_tiktok,
        'fb': handle_fb,
        'scl': handle_scl,
        'zing': handle_zing,
        'nhac': handle_nhac,
        'mp3': handle_nhac,
        'soda': handle_soda,
        'dl': handle_dl,
        'gg': handle_gg
    }

des = {
    'version': "2.3.0",
    'credits': "CLAUDE & HOANG LAM",
    'description': "Hệ thống tải đa phương tiện v2 (FIXED ALL)",
    'power': "Thành viên"
}
