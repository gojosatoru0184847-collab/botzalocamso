# -*- coding: utf-8 -*-
import os, json, time, threading, re, urllib.parse, sys, random
from zlapi.models import Message, ThreadType
from config import PREFIX, ADMIN
from core.collect_utils import (
    save_hunted_cache, load_hunted_cache,
    load_collect_settings as original_load_settings, save_collect_settings,
    EXT_BLACKLIST, DOMAIN_BLACKLIST, STRICT_HOST_WHITELIST, STRICT_EXT_WHITELIST,
    global_hunted_cache, cache_lock
)
from modules.blacklist import load_blacklist

des = {
    'version': "9.2.0",
    'credits': "HOANG LAM",
    'description': "MÁY HÚT SIÊU TỐC (Cache & Bypass Voice)",
    'power': "Chủ sở hữu Bot"
}

scan_state_lock = threading.Lock()
is_scanning = False

# Cache cho settings để tăng tốc
_settings_cache = None
_last_settings_load = 0

def load_collect_settings_cached():
    global _settings_cache, _last_settings_load
    now = time.time()
    if _settings_cache is not None and (now - _last_settings_load < 30):
        return _settings_cache

    _settings_cache = original_load_settings()
    _last_settings_load = now
    return _settings_cache

def is_valid_download_link(url):
    url_low = url.lower()
    if any(domain in url_low for domain in DOMAIN_BLACKLIST): return False
    if any(host in url_low for host in STRICT_HOST_WHITELIST): return True
    path = url_low.split('?')[0].split('#')[0]
    if any(path.endswith(ext) for ext in STRICT_EXT_WHITELIST): return True
    return False

def sniff_real_filename(url, title_from_zalo="", file_size=0):
    try:
        decoded_url = urllib.parse.unquote(url)
        clean_url = decoded_url.split('?')[0].split('#')[0].strip('/')
        url_name = os.path.basename(clean_url)

        if url_name and "." in url_name and len(url_name) > 4:
            # Chặn các tên file rác hoặc quá phổ biến từ link web
            bad_names = ["cqsx", "1wup", "bin?dkey", "voice", "audio", "index.html", "index.htm", "login", "auth"]
            if not any(x in url_name.lower() for x in bad_names):
                return url_name

        if title_from_zalo and len(title_from_zalo) > 3:
            if not any(x in title_from_zalo.lower() for x in ["cqsx", "1wup", "voice", "audio", "index.html"]):
                return title_from_zalo
        return None
    except: pass
    return None

def process_single_message(client, msg_obj, source_thread_id, target_group_id, is_history=False):
    try:
        u_from = str(getattr(msg_obj, 'uidFrom', '0'))
        # Không tự hút của chính mình hoặc từ chính nhóm kho
        if u_from == str(client.uid) or str(source_thread_id) == str(target_group_id): return False

        m = msg_obj if isinstance(msg_obj, dict) else (msg_obj.toDict() if hasattr(msg_obj, 'toDict') else vars(msg_obj))

        raw_mt = str(m.get('msgType') or getattr(msg_obj, 'msgType', 0))
        if any(x in raw_mt.lower() for x in ['reaction', 'delete', 'undo']): return False

        # CHẶN RÁC: Chỉ tập trung vào File (Type 46/2/5) và Link. Bỏ qua ảnh/video thường.
        if str(raw_mt) in ["3", "4", "chat.photo", "chat.video"]: return False

        data_to_check = []
        # 1. Thu thập từ attachments
        if m.get('attachments'):
            for att in m['attachments']:
                if isinstance(att, dict): data_to_check.append(att)

        # 2. Thu thập từ content (cho share.file - msgType 46)
        if raw_mt == "46" or raw_mt == "share.file":
            content = m.get('content')
            if isinstance(content, dict):
                data_to_check.append(content)
            elif isinstance(content, str):
                try:
                    data_to_check.append(json.loads(content))
                except: pass

        # 3. Thu thập link từ text
        content_raw = str(m.get('content') or m.get('text') or "")
        if "http" in content_raw:
            # Tìm link tải (không lấy link zalo, link fb, link tiktok)
            found_links = re.findall(r'(https?://[^\s\)\*\"\'\,]+)', content_raw)
            for link in found_links:
                if is_valid_download_link(link):
                    data_to_check.append({'href': link, 'title': "", 'is_raw_link': True})

        found_any = False
        for item in data_to_check:
            href = item.get('href') or item.get('url') or item.get('oriUrl') or item.get('normalUrl')
            if not href: continue

            f_size = int(item.get('fileSize') or item.get('size') or item.get('totalSize') or 0)
            z_title = str(item.get('title') or item.get('name') or "").lower()

            # Xử lý nested params cho share.file nếu thiếu info ở ngoài
            if not f_size or not z_title:
                params_raw = item.get('params')
                if isinstance(params_raw, str):
                    try:
                        p = json.loads(params_raw)
                        f_size = f_size or int(p.get('totalSize') or p.get('size') or 0)
                        z_title = z_title or str(p.get('title') or p.get('name') or "").lower()
                    except: pass

            # LỌC FILE RÁC: Chỉ lấy file xịn theo whitelist
            from core.collect_utils import STRICT_EXT_WHITELIST
            is_valid_ext = any(z_title.endswith(ext) for ext in STRICT_EXT_WHITELIST)
            if not is_valid_ext and not item.get('is_raw_link'):
                continue

            # Chặn voice và audio rác
            if any(bad in z_title for bad in ["voice_", "aac", "amr", "m4a", "opus", "mp3"]): continue
            if any(z_title.endswith(ext) for ext in EXT_BLACKLIST): continue

            real_name = sniff_real_filename(href, z_title, f_size)
            if not real_name: continue

            real_name_low = real_name.lower()
            if any(real_name_low.endswith(ext) for ext in EXT_BLACKLIST): continue

            # LỌC TRÙNG LẶP (ĐÃ TẮT THEO YÊU CẦU: Hàng về bao nhiêu bế bấy nhiêu)
            # file_uid = item.get('checksum') or item.get('md5') or f"{real_name}_{f_size}"
            # with cache_lock:
            #     if file_uid in global_hunted_cache:
            #         # print(f"⏭️ [BỎ QUA] Trùng lặp: {real_name}")
            #         continue
            #     global_hunted_cache.add(file_uid)
            #     save_hunted_cache(global_hunted_cache)

            try:
                # Đảm bảo item có đủ thông tin để forward
                if 'type' not in item: item['type'] = 'file'

                # THỰC HIỆN BẾ HÀNG
                res = client.forwardFile(item, target_group_id, ThreadType.GROUP)

                # Nếu forward thất bại (hoặc không hỗ trợ), dùng link tải trực tiếp
                if not (res and isinstance(res, dict) and res.get('error_code') == 0):
                    ext = real_name.split('.')[-1] if '.' in real_name else "zip"
                    res = client.sendRemoteFile(href, target_group_id, ThreadType.GROUP, fileName=real_name, extension=ext)

                # Kiểm tra kết quả gửi cuối cùng
                if res and (isinstance(res, dict) and res.get('error_code') == 0) or (hasattr(res, 'msgId')):
                    found_any = True
                    print(f"💎 [HÀNG VỀ] {real_name}", flush=True)
                    # ✅ ÉP XUNG: Nghỉ ít hơn để bế hàng nhanh hơn
                    time.sleep(0.8)
                else:
                    err_code = res.get('error_code') if isinstance(res, dict) else "Unknown"
                    err_msg = res.get('error_message') if isinstance(res, dict) else "Unknown"
                    print(f"❌ [LỖI GỬI] Zalo từ chối bế '{real_name}': Code {err_code} - {err_msg}")
                    time.sleep(1.0)
            except Exception as e:
                print(f"❌ [HÚT FILE] Lỗi hệ thống khi bế '{real_name}': {e}")
        return found_any
    except Exception as e:
        print(f"❌ [HÚT FILE] Lỗi parse tin nhắn: {e}")
        return False

def handle_getfile_command(message, message_object, thread_id, thread_type, author_id, client):
    global is_scanning
    if not client.is_super_admin(author_id): return
    settings = load_collect_settings_cached()
    parts = message.split()

    checkpoint_file = "data/scan_checkpoint.json"

    if len(parts) > 1 and parts[1].lower() == "scan":
        count_limit = 2000
        if len(parts) > 2 and parts[2].isdigit(): count_limit = int(parts[2])

        # Hỗ trợ lệnh .getfile scan resume
        resume_index = 0
        if len(parts) > 2 and parts[2].lower() == "resume":
            if os.path.exists(checkpoint_file):
                try:
                    with open(checkpoint_file, "r") as f:
                        data = json.load(f)
                        resume_index = data.get("last_index", 0)
                        count_limit = data.get("count_limit", 2000)
                except: pass

        with scan_state_lock:
            if is_scanning:
                client.replyMessage(Message(text="⚠️ Máy hút đang bận quét rồi đệ ơi!"), message_object, thread_id, thread_type)
                return
            is_scanning = True

        target_group = settings.get("share_to_group") or str(thread_id)
        msg_start = f"🌪️ [ VÉT CẠN SIÊU TỐC ] Bắt đầu từ nhóm {resume_index + 1}..."
        client.replyMessage(Message(text=msg_start), message_object, thread_id, thread_type)

        def run_all_scan(active_client, target_gid, start_from, limit):
            global is_scanning
            try:
                all_groups_res = active_client.fetchAllGroups()
                tids = list(all_groups_res.gridVerMap.keys())
                total_hunted = 0
                num_groups = len(tids)
                print(f"🔍 [SCAN] Bắt đầu quét {num_groups} nhóm (Bắt đầu từ {start_from})...", flush=True)

                for idx in range(start_from, num_groups):
                    tid = tids[idx]
                    if str(tid) == str(target_gid) or str(tid) in load_blacklist(): continue

                    # Lưu checkpoint
                    try:
                        os.makedirs("data", exist_ok=True)
                        with open(checkpoint_file, "w") as f:
                            json.dump({"last_index": idx, "count_limit": limit}, f)
                    except: pass

                    print(f"📂 [SCAN] ({idx+1}/{num_groups}) Nhóm: {tid}", flush=True)

                    try:
                        last_mid = 0
                        for p in range((limit // 50) + 1):
                            # Hiện tiến trình từng trang để đệ biết bot không bị đơ
                            print(f"   ∟ Đang lướt trang {p+1}/{(limit // 50) + 1}...", end="\r", flush=True)

                            try:
                                history = active_client.getRecentGroup(tid, count=50, lastMsgId=last_mid)
                            except Exception as e:
                                print(f"\n❌ [ZALO LỖI] Nhóm {tid} bị Zalo chặn kết nối. Đang bỏ qua...")
                                break

                            if not history or not hasattr(history, 'groupMsgs') or not history.groupMsgs:
                                print(f"\n   ∟ Đã hết tin nhắn ở nhóm này.")
                                break

                            page_found_any = False
                            for m in history.groupMsgs:
                                if process_single_message(active_client, m, str(tid), target_gid, is_history=True):
                                    total_hunted += 1
                                    page_found_any = True

                            last_mid = history.groupMsgs[-1].get('msgId')

                            if page_found_any:
                                # Nếu có hàng, nghỉ lâu hơn để tránh Ghosting
                                time.sleep(1.5)
                            else:
                                time.sleep(0.1) # Cực nhanh nếu không có hàng

                        print(f"\n✅ [DONE] Đã quét xong nhóm: {tid}")

                    except Exception as e:
                        print(f"⚠️ [SCAN ERROR] Tại nhóm {tid}: {e}")

                print(f"✅ [SCAN] HOÀN TẤT! Tổng cộng bế được {total_hunted} hàng.", flush=True)
                active_client.sendMessage(Message(text=f"✅ [ XONG ] Đã bế {total_hunted} hàng về kho!\n🔄 Đang khởi động lại hệ thống..."), target_gid, ThreadType.GROUP)

                # Xóa checkpoint khi hoàn thành
                if os.path.exists(checkpoint_file): os.remove(checkpoint_file)

                time.sleep(3)
                python = sys.executable
                os.execl(python, python, *sys.argv)
            finally:
                with scan_state_lock: is_scanning = False

        threading.Thread(target=run_all_scan, args=(client, target_group, resume_index, count_limit), daemon=True).start()
        return

    settings.update({"enabled": True, "share_to_group": str(thread_id)})
    save_collect_settings(settings)
    global _settings_cache
    _settings_cache = settings
    client.replyMessage(Message(text=f"🌪️ MÁY HÚT SIÊU TỐC v9.2.0\n🚀 Đã tối ưu Cache và Phân luồng!"), message_object, thread_id, thread_type)

def PTA(): return {'getfile': handle_getfile_command}

def process_incoming_files(client, message_object, thread_id, thread_type):
    settings = load_collect_settings_cached()
    target_group = settings.get("share_to_group")
    if settings.get("enabled") and target_group and str(thread_id) != str(target_group):
        if str(thread_id) not in load_blacklist():
            process_single_message(client, message_object, str(thread_id), target_group)
