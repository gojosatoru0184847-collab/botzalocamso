# -*- coding: utf-8 -*-
import os
import gc
import shutil
import time
import threading
from zlapi.models import Message
from config import PREFIX

def handle_fixlag(message, message_object, thread_id, thread_type, author_id, client):
    if not client.is_super_admin(author_id): return

    client.replyMessage(Message(text="🛠️ Đang tiến hành tối ưu hóa và giảm lag cho hệ thống..."), message_object, thread_id, thread_type)

    summary = []

    # 1. Dừng hỏa lực (War/Var)
    try:
        from modules.var import global_war_state
        war_count = len([k for k, v in global_war_state.items() if v])
        if war_count > 0:
            for k in global_war_state: global_war_state[k] = False
            summary.append(f"✅ Đã dập tắt {war_count} luồng hỏa lực (War/Var).")
    except: pass

    # 2. Dừng nhây tag
    try:
        import modules.nhaytag
        if hasattr(modules.nhaytag, 'is_nhaytag_running') and modules.nhaytag.is_nhaytag_running:
            modules.nhaytag.is_nhaytag_running = False
            summary.append("✅ Đã dừng tác vụ nhây tag.")
    except: pass

    # 3. Dừng ADS
    try:
        import modules.ads
        if hasattr(modules.ads, 'ads_running') and modules.ads.ads_running:
            modules.ads.ads_running = False
            summary.append("✅ Đã dừng tự động rải ADS.")
    except: pass

    # 4. Dọn dẹp cache lệnh
    try:
        if hasattr(client, 'scl_user_states'): client.scl_user_states.clear()
        if hasattr(client, 'yt_user_states'): client.yt_user_states.clear()
        summary.append("✅ Đã làm trống bộ nhớ đệm lệnh (Music/Youtube).")
    except: pass

    # 5. Dọn dẹp file rác
    cache_path = "modules/cache"
    dl_path = "files/downloads"
    files_removed = 0

    def safe_clear(path):
        count = 0
        if os.path.exists(path):
            for item in os.listdir(path):
                if item in ["font", "duyetboxdata.json", "blacklist_groups.json"]: continue
                item_path = os.path.join(path, item)
                try:
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                        count += 1
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path, ignore_errors=True)
                        count += 1
                except: pass
        return count

    files_removed += safe_clear(cache_path)
    files_removed += safe_clear(dl_path)
    if files_removed > 0:
        summary.append(f"✅ Đã dọn dẹp {files_removed} tệp tin tạm và rác.")

    # 6. Giải phóng RAM
    gc.collect()
    summary.append("✅ Đã giải phóng bộ nhớ RAM (Garbage Collection).")

    if not summary:
        res_msg = "✨ Hệ thống hiện tại đang ở trạng thái tối ưu nhất rồi thưa Đại ca!"
    else:
        res_msg = "⚡ TỐI ƯU HỆ THỐNG HOÀN TẤT ⚡\n━━━━━━━━━━━━━━━━━━━━\n" + "\n".join(summary)

    client.replyMessage(Message(text=res_msg), message_object, thread_id, thread_type)

def PTA():
    return {
        'fixlag': handle_fixlag,
        'clean': handle_fixlag,
        'toiuu': handle_fixlag
    }

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Tối ưu hóa hệ thống, dừng các tác vụ rác và dọn dẹp bộ nhớ.",
    'power': "Quản trị viên Bot"
}
