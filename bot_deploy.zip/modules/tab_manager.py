# -*- coding: utf-8 -*-
import time
from zlapi.models import Message, ThreadType
from config import PREFIX

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Chuyển nhóm qua tab Khác hoặc Ưu tiên",
    'power': "Quản trị viên Bot"
}

def handle_tab_command(message, message_object, thread_id, thread_type, author_id, client):
    if not client.is_super_admin(author_id):
        client.replyMessage(Message(text="⚠️ Chỉ Admin mới có quyền dùng lệnh này!"), message_object, thread_id, thread_type)
        return

    parts = message.split()
    if len(parts) < 2:
        msg = f"🔍 Hướng dẫn Tab Manager:\n" \
              f"➜ {PREFIX}tab khac: Chuyển nhóm này vào tab Khác\n" \
              f"➜ {PREFIX}tab uutien: Chuyển nhóm này vào tab Ưu tiên\n" \
              f"➜ {PREFIX}tab khacall: Chuyển TẤT CẢ các nhóm hiện có vào tab Khác"
        client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)
        return

    action = parts[1].lower()

    if action == "khac":
        res = client.updateCategory(thread_id, category=1)
        if res.get("error_code") == 0:
            client.replyMessage(Message(text="✅ Đã lôi nhóm này qua tab Khác thành công!"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text=f"❌ Lỗi: {res.get('error_message') or res.get('error_code')}"), message_object, thread_id, thread_type)

    elif action == "uutien":
        res = client.updateCategory(thread_id, category=0)
        if res.get("error_code") == 0:
            client.replyMessage(Message(text="✅ Đã đưa nhóm này trở lại tab Ưu tiên!"), message_object, thread_id, thread_type)
        else:
            client.replyMessage(Message(text=f"❌ Lỗi: {res.get('error_message') or res.get('error_code')}"), message_object, thread_id, thread_type)

    elif action == "khacall":
        client.replyMessage(Message(text="⏳ Đang tiến hành lôi tất cả nhóm qua tab Khác..."), message_object, thread_id, thread_type)
        try:
            all_groups = client.fetchAllGroups()
            group_ids = list(all_groups.gridVerMap.keys())

            success_count = 0
            for g_id in group_ids:
                try:
                    res = client.updateCategory(g_id, category=1)
                    if res.get("error_code") == 0:
                        success_count += 1
                    time.sleep(0.3) # Delay để tránh spam API
                except:
                    pass

            client.replyMessage(Message(text=f"✅ Đã dọn dẹp xong! Lôi thành công {success_count}/{len(group_ids)} nhóm qua tab Khác."), message_object, thread_id, thread_type)
        except Exception as e:
            client.replyMessage(Message(text=f"❌ Lỗi hệ thống: {e}"), message_object, thread_id, thread_type)

    else:
        client.replyMessage(Message(text="❌ Lệnh không hợp lệ. Gõ '.tab' để xem hướng dẫn."), message_object, thread_id, thread_type)

def PTA():
    return {
        'tab': handle_tab_command
    }
