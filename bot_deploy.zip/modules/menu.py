# -*- coding: utf-8 -*-
import os, importlib, tempfile, random, json, hashlib, time, threading, requests
from io import BytesIO
from zlapi.models import Message
from config import PREFIX
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# =============== CẤU HÌNH ===============
FONT_BOLD        = "modules/cache/font/BeVietnamPro-Bold.ttf"
FONT_REGULAR     = "modules/cache/font/BeVietnamPro-Regular.ttf"
EMOJI_FONT       = "modules/cache/font/NotoEmoji-Bold.ttf"
BG_DIR           = "background" # Thư mục chứa ảnh Anime / Gái
CACHE_DIR        = "modules/cache/menu_temp"

PAGE_SIZE        = 6 # 6 lệnh mỗi trang phù hợp kích thước ngang

os.makedirs(CACHE_DIR, exist_ok=True)

des = {
    'version': "11.0.0",
    'credits': "HOANG LAM",
    'description': "Menu Anime Hình Chữ Nhật Siêu Cấp: Thiết kế hầm hố, ảnh Anime cực nét.",
    'power': "Thành viên"
}

# =============== UTILS ===============
def get_font(size, bold=True):
    try: return ImageFont.truetype(FONT_BOLD if bold else FONT_REGULAR, size)
    except: return ImageFont.load_default()

def get_emoji_font(size):
    try: return ImageFont.truetype(EMOJI_FONT, size)
    except: return ImageFont.load_default()

def get_bg_image(size):
    try:
        # --- ƯU TIÊN 1: Lấy ảnh trong máy (folder background) ---
        if os.path.exists(BG_DIR):
            imgs = [f for f in os.listdir(BG_DIR) if f.lower().endswith(('.jpg','.png','.jpeg'))]
            beauty_keywords = ("img_", "zalo_", "girl", "beauty", "gai")
            beauty_pool = [f for f in imgs if f.lower().startswith(beauty_keywords)]

            selected_local = beauty_pool if beauty_pool else imgs
            if selected_local:
                img_path = os.path.join(BG_DIR, random.choice(selected_local))
                img = Image.open(img_path).convert("RGBA")

                target_w, target_h = size
                w, h = img.size
                if w/h > target_w/target_h:
                    new_w = int(h * (target_w/target_h))
                    img = img.crop(((w-new_w)//2, 0, (w+new_w)//2, h))
                else:
                    new_h = int(w * (target_h/target_w))
                    img = img.crop((0, (h-new_h)//2, w, (h+new_h)//2))
                return img.resize(size, Image.LANCZOS)

        # --- DỰ PHÒNG: Nếu máy không có ảnh thì lấy ảnh mạng ---
        apis = [
            "https://api-gai-xinh.vercel.app/image",
            "https://api.vinh05.io.vn/images/gai",
            "https://picsum.photos/1600/1000"
        ]
        random.shuffle(apis)
        for api_url in apis:
            try:
                res = requests.get(api_url, timeout=4)
                if res.status_code == 200:
                    img = Image.open(BytesIO(res.content)).convert("RGBA")
                    target_w, target_h = size
                    w, h = img.size
                    if w/h > target_w/target_h:
                        new_w = int(h * (target_w/target_h))
                        img = img.crop(((w-new_w)//2, 0, (w+new_w)//2, h))
                    else:
                        new_h = int(w * (target_h/target_w))
                        img = img.crop((0, (h-new_h)//2, w, (h+new_h)//2))
                    return img.resize(size, Image.LANCZOS)
            except Exception:
                continue
    except Exception:
        pass
    return Image.new("RGBA", size, (15, 18, 30, 255))

def autosave(img, quality=95):
    temp_fd, temp_path = tempfile.mkstemp(suffix=".jpg", dir=CACHE_DIR)
    os.close(temp_fd)
    img.convert("RGB").save(temp_path, "JPEG", quality=quality, optimize=True)
    return temp_path

def _smart_resize(img, target_w, target_h):
    w, h = img.size
    scale = min(target_w / w, target_h / h, 1.0)
    if scale < 1:
        return img.resize((int(w*scale), int(h*scale)), Image.LANCZOS)
    return img

# =============== CORE DRAWING ===============
def draw_menu_image(items, page, total_pages, total_cmds):
    W, H = 1600, 1000

    bg = get_bg_image((W, H))

    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d_overlay = ImageDraw.Draw(overlay)

    for y in range(H):
        alpha = int(70 + 40 * (y / H))
        d_overlay.line([(0, y), (W, y)], fill=(2, 5, 10, alpha))

    for x in range(10):
        alpha = int(200 * (1 - x/10))
        d_overlay.line([(x, 0), (x, H)], fill=(0, 255, 255, alpha))

    bg.alpha_composite(overlay)
    draw = ImageDraw.Draw(bg, "RGBA")

    f_title = get_font(120)
    f_sub = get_font(36)
    f_card_title = get_font(52)
    f_card_alias = get_font(34)
    f_card_desc = get_font(28, False)
    f_footer = get_font(32)
    f_emoji = get_emoji_font(85)

    # ── 🛰️ HEADER ──
    draw.text((84, 74), "ULTRA BOT SYSTEM", font=f_title, fill=(0, 0, 0, 100))
    draw.text((80, 70), "ULTRA BOT SYSTEM", font=f_title, fill=(0, 255, 255))

    info_txt = f"⚡ TERMINAL MODE | PAGE {page}/{total_pages} | {total_cmds} COMMANDS"
    draw.text((85, 195), info_txt, font=f_sub, fill=(255, 255, 255, 220))

    draw.rounded_rectangle([80, 245, 600, 252], radius=3, fill=(0, 255, 255, 255))
    draw.rounded_rectangle([620, 245, 680, 252], radius=3, fill=(255, 0, 255, 200))

    # ── 📦 LIST DRAWING ──
    COL_W = 720
    CARD_H = 210
    GAP_X = 60
    GAP_Y = 40
    START_X, START_Y = 80, 310

    icons = ["💎", "💠", "⚡", "🛡️", "🧬", "🚀", "🛰️", "🎮", "🤖", "📡"]

    for idx, (name, data) in enumerate(items):
        col = idx // 3
        row = idx % 3
        x = START_X + col * (COL_W + GAP_X)
        y = START_Y + row * (CARD_H + GAP_Y)

        draw.rounded_rectangle([x, y, x+COL_W, y+CARD_H], radius=25, fill=(5, 10, 25, 110), outline=(255, 255, 255, 40), width=1)

        ic_box_s = 140
        ix, iy = x + 25, y + (CARD_H - ic_box_s) // 2
        draw.rounded_rectangle([ix, iy, ix+ic_box_s, iy+ic_box_s], radius=20, fill=(255, 255, 255, 15), outline=(255, 255, 255, 40), width=1)

        ic = icons[idx % len(icons)]
        draw.text((ix + 25, iy + 25), ic, font=f_emoji, fill=(255,255,255))

        tx = ix + ic_box_s + 30
        ty = y + 25
        t_text = name.replace("_", " ").upper()
        draw.text((tx, ty), t_text, font=f_card_title, fill=(255, 255, 255))

        ty += 70
        alias = f"{PREFIX}{data['aliases'][0]}"
        draw.text((tx, ty), alias, font=f_card_alias, fill=(0, 255, 220))

        ty += 45
        desc = data['description']
        if len(desc) > 38: desc = desc[:35] + "..."
        draw.text((tx, ty), desc, font=f_card_desc, fill=(220, 230, 250, 220))

    # ── 🏁 FOOTER ──
    footer_y = H - 80

    draw.text((80, footer_y), "STATUS: OPTIMIZED", font=f_footer, fill=(0, 255, 255, 120))

    creator = f"DEVELOPED BY {des['credits']}"
    cw = f_footer.getlength(creator)
    draw.text(((W-cw)//2, footer_y), creator, font=f_footer, fill=(255, 255, 255, 100))

    page_info = f"PAGE {page} OF {total_pages}"
    pw = f_footer.getlength(page_info)
    draw.text((W - pw - 80, footer_y), page_info, font=f_footer, fill=(0, 255, 255, 150))

    return autosave(bg)

def get_all_modules():
    info = {}
    folders = ['modules', 'commands', 'modules/noprefix']
    for folder in folders:
        if not os.path.exists(folder): continue
        mod_prefix = folder.replace('/', '.')
        for fname in sorted(os.listdir(folder)):
            if not fname.endswith('.py') or fname == '__init__.py': continue
            try:
                mod_name = fname[:-3]
                mod = importlib.import_module(f'{mod_prefix}.{mod_name}')
                if hasattr(mod, 'PTA'):
                    cmds = mod.PTA()
                    if not cmds: continue
                    d = getattr(mod, 'des', {})
                    if mod_name in info:
                        info[mod_name]['aliases'] = list(set(info[mod_name]['aliases'] + list(cmds.keys())))
                    else:
                        info[mod_name] = {
                            'aliases': list(cmds.keys()),
                            'version': d.get('version', '1.0'),
                            'description': d.get('description', 'Bot Command'),
                            'power': d.get('power', 'Thành viên')
                        }
            except Exception: pass
    return info

def handle_menu(message, message_object, thread_id, thread_type, author_id, client):
    try:
        parts = message.split()
        all_mods = get_all_modules()
        actual_total_cmds = sum(len(v['aliases']) for v in all_mods.values())

        page = 1
        if len(parts) > 1 and parts[1].isdigit():
            page = int(parts[1])

        filtered = all_mods
        if len(parts) > 1 and not parts[1].isdigit():
            term = parts[1].lower()
            filtered = {k:v for k,v in all_mods.items() if term in k.lower() or any(term in a.lower() for a in v['aliases'])}
            if not filtered:
                return client.replyMessage(Message(text=f"❌ Không thấy lệnh '{term}'!"), message_object, thread_id, thread_type)

        total_pages = (len(filtered) + PAGE_SIZE - 1) // PAGE_SIZE
        if page > total_pages: page = total_pages
        if page < 1: page = 1

        start = (page - 1) * PAGE_SIZE
        items = list(filtered.items())[start : start + PAGE_SIZE]

        img_path = draw_menu_image(items, page, total_pages, actual_total_cmds)

        if not img_path or not os.path.exists(img_path):
            return client.replyMessage(Message(text="❌ Lỗi tạo ảnh menu."), message_object, thread_id, thread_type)

        with Image.open(img_path) as img:
            w, h = img.size

        print(f"[MENU] Đang gửi menu Anime hình chữ nhật: {img_path} ({w}x{h})")
        res = client.sendLocalImage(img_path, thread_id, thread_type, width=w, height=h)

        if os.path.exists(img_path):
            try: os.remove(img_path)
            except: pass

        client.sendReaction(message_object, "📋", thread_id, thread_type)

    except Exception as e:
        print(f"Lỗi Menu Anime v11: {e}")

def PTA():
    return {'menu': handle_menu}

__all__ = ['handle_menu', 'get_font', 'get_bg_image', 'autosave', '_smart_resize']
