# -*- coding: utf-8 -*-
import os, random, tempfile
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from zlapi.models import Message
from modules.menu import get_font, get_bg_image, autosave, _smart_resize

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Đo độ Gay/Les của bạn bè trong nhóm.",
    'power': "Thành viên"
}

def draw_stat_table(title_text, value, user_name, color_theme):
    WIDTH, HEIGHT = 800, 600
    bg = get_bg_image((WIDTH, HEIGHT)).convert("RGBA")
    overlay = Image.new("RGBA", bg.size, (0, 0, 0, 100))
    bg.alpha_composite(overlay)

    draw = ImageDraw.Draw(bg)

    f_title = get_font(60)
    f_name = get_font(45)
    f_val = get_font(80)
    f_desc = get_font(30, False)

    # Title
    draw.text((WIDTH//2 - f_title.getlength(title_text)//2, 80), title_text, font=f_title, fill=color_theme)

    # Card
    card_margin = 80
    draw.rounded_rectangle([card_margin, 180, WIDTH-card_margin, 450], radius=30, fill=(40, 40, 60, 180), outline=color_theme, width=3)

    # User Name
    name_display = f"Đối tượng: {user_name}"
    draw.text((WIDTH//2 - f_name.getlength(name_display)//2, 220), name_display, font=f_name, fill=(255, 255, 255))

    # Value
    val_text = f"{value}%"
    draw.text((WIDTH//2 - f_val.getlength(val_text)//2, 300), val_text, font=f_val, fill=color_theme)

    # Footer
    footer = "Kết quả chỉ mang tính chất giải trí • Bot by HOANG LAM"
    draw.text((WIDTH//2 - f_desc.getlength(footer)//2, HEIGHT - 80), footer, font=f_desc, fill=(200, 200, 200))

    path = autosave(_smart_resize(bg, 720, 540))
    return path

def get_target_info(message, message_object, author_id, client):
    target_id = author_id
    target_name = "Bạn"

    # Check if mention
    if message_object.mention:
        mentions = message_object.mention
        # message_object.mention is usually a list or dict depending on zlapi version
        # Let's assume list of dicts with 'uid'
        if isinstance(mentions, list) and len(mentions) > 0:
            target_id = mentions[0].get('uid')
        elif isinstance(mentions, dict):
            # Some versions might have it as a dict
            target_id = list(mentions.keys())[0] if mentions else author_id

    try:
        info = client.fetchUserInfo(target_id)
        if info and hasattr(info, 'changed_profiles'):
            target_name = info.changed_profiles.get(str(target_id), {}).get('zaloName', 'Người dùng')
    except:
        pass

    return target_id, target_name

def handle_gay(message, message_object, thread_id, thread_type, author_id, client):
    try:
        _, name = get_target_info(message, message_object, author_id, client)
        val = random.randint(0, 100)
        img_path = draw_stat_table("MÁY ĐO ĐỘ GAY", val, name, (255, 105, 180)) # Pink/HotPink
        client.sendLocalImage(img_path, thread_id, thread_type)
        if os.path.exists(img_path): os.remove(img_path)
    except Exception as e:
        print(f"Lỗi lệnh .gay: {e}")

def handle_les(message, message_object, thread_id, thread_type, author_id, client):
    try:
        _, name = get_target_info(message, message_object, author_id, client)
        val = random.randint(0, 100)
        img_path = draw_stat_table("MÁY ĐO ĐỘ LES", val, name, (255, 165, 0)) # Orange
        client.sendLocalImage(img_path, thread_id, thread_type)
        if os.path.exists(img_path): os.remove(img_path)
    except Exception as e:
        print(f"Lỗi lệnh .les: {e}")

def PTA():
    return {
        'gay': handle_gay,
        'ga': handle_gay,
        'les': handle_les,
        'le': handle_les
    }
