from zlapi.models import Message, ZaloAPIException, ThreadType
from config import ADMIN, PREFIX
import json
import os
import re
import threading
import time

# --- 🎯 BỘ TỪ KHÓA FF CHUẨN ---
FF_KEYWORDS = [
    "ff", "free fire", "mod", "hack", "menu", "skin", "ob4", "ob3",
    "ios", "ipa", "apk", "tweak", "cheat", "ghim", "hành", "v4", "v5",
    "v6", "v7", "v8", "v9", "tool", "bản", "file", "đồ chơi"
]

des = {
    'version': "1.6.0",
    'credits': "HOANG LAM",
    'description': "Autojoin FF - Fix triệt để lỗi không join"
}

joined_cache = set()
cache_lock = threading.Lock()

# ✅ FILE CẤU HÌNH TỰ ĐỘNG JOIN
AUTOJOIN_CONFIG = "data/autojoin_global.json"

def load_autojoin_state():
    try:
        if os.path.exists(AUTOJOIN_CONFIG):
            with open(AUTOJOIN_CONFIG, "r") as f:
                return json.load(f).get("enabled", False)
    except: pass
    return False

def save_autojoin_state(state):
    os.makedirs("data", exist_ok=True)
    try:
        with open(AUTOJOIN_CONFIG, "w") as f:
            json.dump({"enabled": state}, f)
    except: pass

def process_message_for_autojoin(client, message_object, thread_id, thread_type, author_id, message_text, mid, logger_obj):
    if not load_autojoin_state():
        return

    handler = getattr(client, 'autojoin_handler', None)
    if not handler:
        from modules.autojoin import AutoJoinHandler
        handler = AutoJoinHandler(client)
        client.autojoin_handler = handler
    handler.check_and_join_group(message_text, thread_id)

class AutoJoinHandler:
    def __init__(self, client):
        self.client = client

    def check_and_join_group(self, message_text, thread_id):
        if not message_text: return
        text_low = message_text.lower()

        # 1. KIỂM TRA TỪ KHÓA FF (BỎ QUA NẾU MUỐN JOIN TẤT CẢ)
        # Nếu huynh muốn bot join TẤT CẢ các link Zalo tìm thấy, hãy comment phần kiểm tra any() này lại.
        # if not any(kw in text_low for kw in FF_KEYWORDS):
        #     return

        # 2. XỬ LÝ LINK ZALO
        zalo_matches = re.findall(r"https://zalo\.me/g/[a-zA-Z0-9]+", message_text)
        for link in zalo_matches:
            with cache_lock:
                if link in joined_cache: continue
                joined_cache.add(link)

            try:
                # Dùng full link cho joinGroup theo API chuẩn
                res = self.client.joinGroup(link)
                # In chi tiết phản hồi để debug nếu cần
                print(f"🚀 [AUTOJOIN] Zalo: {link} -> {res}", flush=True)
            except Exception as e:
                print(f"❌ [AUTOJOIN] Lỗi Zalo: {e}")

        # 3. XỬ LÝ LINK TELEGRAM
        tele_matches = re.findall(r"(?:https?://)?t\.me/(?:joinchat/|\+)?(?:[a-zA-Z0-9_]{5,})", message_text)
        for link in tele_matches:
            full_link = link if link.startswith("http") else f"https://{link}"

            with cache_lock:
                if full_link in joined_cache: continue
                joined_cache.add(full_link)

            try:
                from modules.tele_getfile import tele_join_queue
                tele_join_queue.put(full_link)
                print(f"🚀 [AUTOJOIN] Đã bế link Telegram: {full_link}", flush=True)
            except Exception as e:
                print(f"❌ [AUTOJOIN] Lỗi Telegram: {e}")

def _autojoin_wrapper(message, message_object, thread_id, thread_type, author_id, client):
    parts = message.lower().split()
    current_state = load_autojoin_state()

    if len(parts) > 1:
        action = parts[1]
        if action == "on":
            save_autojoin_state(True)
            msg = "✅ Đã BẬT Auto Join toàn hệ thống!"
        elif action == "off":
            save_autojoin_state(False)
            msg = "🚫 Đã TẮT Auto Join toàn hệ thống!"
        else:
            msg = f"❓ Trạng thái hiện tại: {'BẬT' if current_state else 'TẮT'}\n➜ Dùng: {PREFIX}autojoin on/off"
    else:
        msg = f"🚦 [ AUTOJOIN FF ]\n➜ Trạng thái: {'BẬT' if current_state else 'TẮT'}\n➜ Dùng: {PREFIX}autojoin on/off để điều chỉnh."

    client.replyMessage(Message(text=msg), message_object, thread_id, thread_type)

def PTA():
    return {'autojoin': _autojoin_wrapper}
