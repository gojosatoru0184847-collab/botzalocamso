# -*- coding: utf-8 -*-
import os, json, asyncio, threading, time, re, queue
from telethon import TelegramClient, events, functions

_tele_client = None
_tele_thread_running = False
TELE_TARGET_CHANNEL = "SHOPLIMINAL"
tele_join_queue = queue.Queue()

# Tắt log cảnh báo SSL gây rác log
import logging
logging.getLogger('telethon').setLevel(logging.ERROR)

def is_gold_content(message_obj):
    from core.collect_utils import STRICT_HOST_WHITELIST, DOMAIN_BLACKLIST, MOD_KEYWORDS, STRICT_EXT_WHITELIST
    text = str(message_obj.text or "").lower()
    if message_obj.file:
        name = (message_obj.file.name or "").lower()
        return any(name.endswith(ext) for ext in STRICT_EXT_WHITELIST)
    has_link = any(host in text for host in STRICT_HOST_WHITELIST)
    has_keyword = any(kw in text for kw in MOD_KEYWORDS)
    if any(domain in text for domain in DOMAIN_BLACKLIST): return False
    return has_link and (has_keyword or any(ext in text for ext in STRICT_EXT_WHITELIST))

async def worker_queue_handler():
    global _tele_client
    while True:
        try:
            if not tele_join_queue.empty() and _tele_client and await _tele_client.is_user_authorized():
                link = tele_join_queue.get()
                try:
                    if "joinchat/" in link or "+" in link:
                        hash_code = link.split('/')[-1].replace('+', '')
                        await _tele_client(functions.messages.ImportChatInviteRequest(hash_code))
                    else:
                        username = link.split('/')[-1]
                        await _tele_client(functions.channels.JoinChannelRequest(username))
                except: pass
                tele_join_queue.task_done()
        except: pass
        await asyncio.sleep(10)

async def start_tele_scrapper():
    global _tele_client
    try:
        with open("seting.json", "r", encoding='utf-8') as f:
            c = json.load(f).get("telegram", {})
        api_id, api_hash = c.get("api_id"), c.get("api_hash")
        if not api_id: return
    except: return

    # Chỉ dùng 1 session duy nhất đã login
    _tele_client = TelegramClient("data/tele_fixed", int(api_id), api_hash)

    try:
        await _tele_client.connect()
        if not await _tele_client.is_user_authorized():
            print("⚠️ Telegram chưa login. Hãy chạy 'python login_tele.py' trước!")
            return

        print(f"✅ Telegram ĐÃ KẾT NỐI (Hút & Join gộp chung)")

        @_tele_client.on(events.NewMessage)
        async def handler(event):
            try:
                chat = await event.get_chat()
                if getattr(chat, 'username', '').upper() == TELE_TARGET_CHANNEL.upper(): return
                if is_gold_content(event.message):
                    await _tele_client.forward_messages(TELE_TARGET_CHANNEL, event.message)
                    print(f"🚀 [TELE] Bế hàng: {getattr(chat, 'title', 'Kênh ẩn')}")
            except: pass

        asyncio.create_task(worker_queue_handler())
        await _tele_client.run_until_disconnected()
    except Exception as e:
        if "database is locked" in str(e).lower():
            print("❌ Lỗi: Session đang bị chiếm dụng bởi tiến trình khác!")
        else:
            print(f"❌ Telethon Error: {e}")
    finally:
        if _tele_client: await _tele_client.disconnect()

def run_tele_thread(zalo_client):
    global _tele_thread_running
    if _tele_thread_running: return
    _tele_thread_running = True
    def worker():
        while True:
            loop = asyncio.new_event_loop(); asyncio.set_event_loop(loop)
            try: loop.run_until_complete(start_tele_scrapper())
            except: pass
            finally: loop.close()
            time.sleep(30)
    threading.Thread(target=worker, daemon=True, name="TeleScraper").start()

def PTA(): return {}
des = {'version': "9.0.0", 'credits': "HOANG LAM", 'description': "Gộp chung & Fix triệt để lỗi Locked"}
