# -*- coding: utf-8 -*-
import json, os, time

BLACKLIST_FILE = "data/blacklist_groups.json"
_blacklist_cache = None
_last_load_time = 0

def load_blacklist():
    global _blacklist_cache, _last_load_time
    now = time.time()
    # Cache trong 10 giây để tránh đọc file liên tục
    if _blacklist_cache is not None and (now - _last_load_time < 10):
        return _blacklist_cache

    try:
        if os.path.exists(BLACKLIST_FILE):
            with open(BLACKLIST_FILE, "r", encoding='utf-8') as f:
                _blacklist_cache = set(str(gid) for gid in json.load(f))
        else:
            _blacklist_cache = set()
    except:
        _blacklist_cache = set()

    _last_load_time = now
    return _blacklist_cache

def add_to_blacklist(group_id):
    bl = load_blacklist()
    bl.add(str(group_id))
    try:
        with open(BLACKLIST_FILE, "w", encoding='utf-8') as f:
            json.dump(list(bl), f)
    except: pass

def remove_from_blacklist(group_id):
    bl = load_blacklist()
    gid = str(group_id)
    if gid in bl:
        bl.remove(gid)
        try:
            with open(BLACKLIST_FILE, "w", encoding='utf-8') as f:
                json.dump(list(bl), f)
        except: pass

def PTA():
    """Hàm giả để tránh lỗi load module của PTA.py"""
    return {}

des = {
    'version': "1.0.0",
    'credits': "HOANG LAM",
    'description': "Module quản lý danh sách đen (Đã gộp vào core)"
}
