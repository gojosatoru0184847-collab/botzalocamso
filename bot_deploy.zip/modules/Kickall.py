import random
import threading
import time
import json
import re
from zlapi import *
from zlapi.models import *
from config import ADMIN

des = {
    'version': "1.0.1",
    'credits': "HOANG LAM",
    'description': "Kick All",
    'power': "Admin"
}

def kickall(message, message_object, thread_id, thread_type, author_id, bot):
    if not bot.is_super_admin(author_id):
        bot.replyMessage(Message(text="•🚦Bạn không có quyền sử dụng lệnh này!"), message_object, thread_id, thread_type)
        return
        
    group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
    
    admin_ids = group.adminIds.copy()
    if group.creatorId not in admin_ids:
        admin_ids.append(group.creatorId)
    
    list_mem_group = set([member.split('_')[0] for member in group["memVerList"]])

    list_mem_group_to_kick = list_mem_group - set(admin_ids)

    for uid in list_mem_group_to_kick:
        bot.blockUsersInGroup(uid, thread_id)
        bot.kickUsersInGroup(uid, thread_id)
        
def PTA():
    return {
        'kickall': kickall
    }