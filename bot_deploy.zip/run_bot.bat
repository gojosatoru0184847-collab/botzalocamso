@echo off
title ULTRA BOT SYSTEM - STARTING...
color 0b

echo ======================================================
echo           ULTRA BOT SYSTEM - STARTUP SCRIPT
echo ======================================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python and try again.
    pause
    exit /b
)

:: Install requirements if needed
if exist requirements.txt (
    echo [INFO] Checking dependencies...
    pip install -r requirements.txt --quiet
)

echo.
echo [SUCCESS] Starting Ultra Bot...
echo ======================================================
echo.

:: Run the bot
python main.py

echo.
echo ======================================================
echo [INFO] Bot has stopped.
pause
