# -*- coding: UTF-8 -*-
import uuid
import base64
import re
import random
import websockets
import requests, json
import os

from .models import *
from ._package import *
from . import _util, _state
from .logging import Logging
from websockets.sync.client import connect
from concurrent.futures import ThreadPoolExecutor

pool = ThreadPoolExecutor(max_workers=9999)
logger = Logging(theme="catppuccin-mocha", log_text_color="black")

class ZaloAPI(object):
    def __init__(self, phone, password, imei, session_cookies=None, user_agent=None, auto_login=True):
        """Initialize and log in the client.
        
        Args:
            imei (str): The device imei is logged into Zalo
            phone (str): Zalo account phone number
            password (str): Zalo account password
            auto_login (bool): Automatically log in when initializing ZaloAPI (Default: True)
            user_agent (str): Custom user agent to use when sending requests. If `None`, user agent will be chosen from a premade list
            session_cookies (dict): Cookies from a previous session (Required if logging in with cookies)
            
        Raises:
            ZaloLoginError: On failed login
            LoginMethodNotSupport: If method login not support
        """
        self._ws = None
        self._state = _state.State()
        self._condition = threading.Event()
        self._listening = False
        self._start_fix = False
        
        
    
        if auto_login:
            if (
                not session_cookies 
                or not self.setSession(session_cookies) 
                or not self.isLoggedIn()
            ):
                self.login(phone, password, imei, user_agent)
        
    def loginWithQR(self, user_agent=None, qr_path="zalo_qr.png", on_qr_generated=None):
        """Khởi tạo quá trình đăng nhập bằng mã QR.

        Tham số:
            user_agent (str, tùy chọn): User agent tùy chỉnh cho phiên đăng nhập.
            qr_path (str, tùy chọn): Đường dẫn tệp để lưu ảnh mã QR được tạo.
            on_qr_generated (callable, tùy chọn): Một hàm callback sẽ được thực thi
                                                 ngay sau khi mã QR được lưu.
                                                 Hàm này nhận 'qr_path' làm tham số duy nhất.
        Lỗi có thể xảy ra:
            ZaloLoginError: Nếu bất kỳ bước nào của quá trình đăng nhập QR thất bại.
        """
        logger.info("Bắt đầu đăng nhập bằng mã QR...")
        
        session = self._state._session
        
        _user_agent = user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        self._state._headers["User-Agent"] = _user_agent

        try:
            login_version = self._qr_load_login_page(session, _user_agent)
            if not login_version:
                raise ZaloLoginError("Không thể xác định phiên bản đăng nhập Zalo.")
            logger.info(f"Đã lấy phiên bản đăng nhập: {login_version}")

            self._qr_get_login_info(session, _user_agent, login_version)
            self._qr_verify_client(session, _user_agent, login_version)

            qr_data = self._qr_generate(session, _user_agent, login_version)
            qr_code = qr_data.get("code")
            qr_image_b64 = qr_data.get("image", "").replace("data:image/png;base64,", "")

            if not (qr_code and qr_image_b64):
                raise ZaloLoginError(f"Tạo mã QR thất bại. Phản hồi: {qr_data}")

            with open(qr_path, "wb") as f:
                f.write(base64.b64decode(qr_image_b64))
            
            if on_qr_generated:
                try:
                    on_qr_generated(qr_path)
                except Exception as cb_exc:
                    logger.error(f"Lỗi khi thực thi callback 'on_qr_generated': {cb_exc}")

            scan_info = self._qr_wait_for_scan(session, _user_agent, login_version, qr_code)
            display_name = scan_info.get("display_name", "Người dùng không xác định")
            logger.info(f"Mã QR đã được quét bởi: {display_name}. Vui lòng xác nhận đăng nhập trên điện thoại của bạn.")

            confirm_result = self._qr_wait_for_confirm(session, _user_agent, login_version, qr_code)
            if confirm_result.get("error_code") == -13:
                raise ZaloLoginError("Đăng nhập đã bị từ chối trên điện thoại.")
            elif confirm_result.get("error_code") != 0:
                 raise ZaloLoginError(f"Xác nhận đăng nhập thất bại. Phản hồi: {confirm_result}")

            self._qr_check_session(session, _user_agent)
            
            user_info = self._qr_get_user_info(session, _user_agent)
            if not user_info.get("data", {}).get("logged"):
                raise ZaloLoginError("Kiểm tra phiên đăng nhập cuối cùng thất bại. Phiên không hợp lệ.")
            
            logger.login(f"Đăng nhập thành công với tư cách {user_info['data']['info']['name']}")
            
            self._finalize_login_session(session.cookies.get_dict(), _user_agent)
            
            self.onLoggedIn(self._state._config.get("phone_number"))

            return {"status": "success", "userInfo": user_info['data']['info']}

        except requests.exceptions.RequestException as e:
            raise ZaloLoginError(f"Đã xảy ra lỗi mạng trong quá trình đăng nhập QR: {e}")
        except ZaloLoginError as e:
            logger.error(f"Lỗi Đăng nhập QR: {e}")
            raise e
        except Exception as e:
            logger.error(f"Đã xảy ra lỗi không mong muốn trong quá trình đăng nhập QR: {e}")
            traceback.print_exc()
            raise ZaloLoginError(f"Đã xảy ra một lỗi không mong muốn: {e}")


    def _qr_load_login_page(self, session, user_agent):
        url = "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F"
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Referer": "https://chat.zalo.me/",
            "User-Agent": user_agent,
        }
        response = session.get(url, headers=headers)
        response.raise_for_status()
        
        html = response.text
        match = re.search(r"https:\/\/stc-zlogin\.zdn\.vn\/main-([\d.]+)\.js", html)
        return match.group(1) if match else None

    def _qr_get_login_info(self, session, user_agent, version):
        url = "https://id.zalo.me/account/logininfo"
        headers = self._get_qr_post_headers(user_agent)
        data = {"continue": "https://zalo.me/pc", "v": version}
        response = session.post(url, headers=headers, data=data)
        response.raise_for_status()
        return response.json()

    def _qr_verify_client(self, session, user_agent, version):
        url = "https://id.zalo.me/account/verify-client"
        headers = self._get_qr_post_headers(user_agent)
        data = {"type": "device", "continue": "https://zalo.me/pc", "v": version}
        response = session.post(url, headers=headers, data=data)
        response.raise_for_status()
        return response.json()

    def _qr_generate(self, session, user_agent, version):
        url = "https://id.zalo.me/account/authen/qr/generate"
        headers = self._get_qr_post_headers(user_agent)
        data = {"continue": "https://zalo.me/pc", "v": version}
        response = session.post(url, headers=headers, data=data)
        response.raise_for_status()
        result = response.json()
        if result.get("error_code") != 0:
            raise ZaloLoginError(f"Tạo QR thất bại: {result.get('error_message')}")
        return result.get("data")

    def _qr_wait_for_scan(self, session, user_agent, version, code, timeout=100):
        url = "https://id.zalo.me/account/authen/qr/waiting-scan"
        headers = self._get_qr_post_headers(user_agent)
        data = {"code": code, "continue": "https://chat.zalo.me/", "v": version}
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            response = session.post(url, headers=headers, data=data)
            response.raise_for_status()
            result = response.json()
            
            if result.get("error_code") == 0 and result.get("data"):
                return result["data"]
            elif result.get("error_code") != 8:
                raise ZaloLoginError(f"Lỗi trong khi chờ quét mã: {result.get('error_message')}")
            
            time.sleep(1)
        
        raise ZaloLoginError("Hết thời gian chờ quét mã QR.")

    def _qr_wait_for_confirm(self, session, user_agent, version, code, timeout=100):
        url = "https://id.zalo.me/account/authen/qr/waiting-confirm"
        headers = self._get_qr_post_headers(user_agent)
        data = {
            "code": code, "gToken": "", "gAction": "CONFIRM_QR", 
            "continue": "https://chat.zalo.me/", "v": version
        }
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            response = session.post(url, headers=headers, data=data)
            response.raise_for_status()
            result = response.json()
            
            if result.get("error_code") != 8:
                return result
            
            time.sleep(1)
        
        raise ZaloLoginError("Hết thời gian chờ xác nhận đăng nhập.")

    def _qr_check_session(self, session, user_agent):
        url = "https://id.zalo.me/account/checksession?continue=https%3A%2F%2Fchat.zalo.me%2Findex.html"
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F",
            "User-Agent": user_agent,
        }
        response = session.get(url, headers=headers)
        response.raise_for_status()
        return response

    def _qr_get_user_info(self, session, user_agent):
        url = "https://jr.chat.zalo.me/jr/userinfo"
        headers = {
            "Accept": "*/*",
            "Referer": "https://chat.zalo.me/",
            "User-Agent": user_agent,
        }
        response = session.get(url, headers=headers)
        response.raise_for_status()
        return response.json()

    def _finalize_login_session(self, session_cookies, user_agent):
        self._state.set_cookies(session_cookies)
        
        imei_uuid = str(uuid.uuid4())
        imei_hash = hashlib.md5(user_agent.encode()).hexdigest()
        imei = f"{imei_uuid}-{imei_hash}"

        self._imei = imei
        self._state.user_imei = imei

        url = f"https://wpa.chat.zalo.me/api/login/getLoginInfo?imei={imei}&type=30&client_version=650&ts={_util.now()}"
        
        response = self._state._get(url)
        response.raise_for_status()
        data = response.json()

        if data.get("error_code") == 0 and "data" in data:
            login_data = data["data"]
            self._state._config = {
                "phone_number": login_data.get("phone_number"),
                "secret_key": login_data.get("zpw_enk"),
                "send2me_id": str(login_data.get("uid")),
                "zpw_ws": login_data.get("zpw_ws"),
            }
            self.uid = self._state._config.get("send2me_id")
            self._state.user_id = self.uid
            self._state._loggedin = True
        else:
            raise ZaloLoginError(f"Không thể lấy thông tin phiên cuối cùng: {data.get('error_message')}")
            
    def _get_qr_post_headers(self, user_agent):
        return {
            "Accept": "*/*",
            "Content-Type": "application/x-www-form-urlencoded",
            "Referer": "https://id.zalo.me/account?continue=https%3A%2F%2Fzalo.me%2Fpc",
            "User-Agent": user_agent,
        }
        
    def uid(self):
        """The ID of the client."""
        return self.uid
    
    """
    INTERNAL REQUEST METHODS
    """
    
    def _get(self, *args, **kwargs):
        return self._state._get(*args, **kwargs)
        
    def _post(self, *args, **kwargs):
        return self._state._post(*args, **kwargs)
    
    """
    END INTERNAL REQUEST METHODS
    """
    
    """
    EXTENSIONS METHODS
    """
    
    def _encode(self, params):
        return _util.zalo_encode(params, self._state._config.get("secret_key"))
        
    def _decode(self, params):
        return _util.zalo_decode(params, self._state._config.get("secret_key")) 
        
    """
    END EXTENSIONS METHODS
    """
    
    """
    LOGIN METHODS
    """
    
    def isLoggedIn(self):
        """Get data from config to check the login status.

        Returns:
            bool: True if the client is still logged in
        """
        return self._state.is_logged_in()
        
    def getSession(self):
        """Retrieve session cookies.
            
        Returns:
            dict: A dictionary containing session cookies
        """
        return self._state.get_cookies()
        
    def setSession(self, session_cookies):
        """Load session cookies.
        
        Warning:
            Error sending requests if session cookie is wrong
            
        Args:
            session_cookies (dict): A dictionary containing session cookies
            
        Returns:
            Bool: False if ``session_cookies`` does not contain proper cookies
        """
        try:
            if not isinstance(session_cookies, dict):
                return False
            # Load cookies into current session
            self._state.set_cookies(session_cookies)
            self.uid = self._state.user_id
        except Exception as e:
            print("Failed loading session")
            return False
        return True
    
    def getSecretKey(self):
        """Retrieve secret key to encode/decode payload.
            
        Returns:
            str: A secret key string with base64 encode
        """
        return self._state.get_secret_key()
        
    def setSecretKey(self, secret_key):
        """Load secret key.
        
        Warning:
            Error (enc/de)code payload if secret key is wrong
            
        Args:
            secret_key (str): A secret key string with base64 encode
            
        Returns:
            bool: False if ``secret_key`` not correct to (en/de)code the payload
        """
        try:
            self._state.set_secret_key(secret_key)
            
            return True
        except:
            return False
    
    def login(self, phone, password, imei, user_agent=None):
        """Login the user, using ``phone`` and ``password``.
            
        If the user is already logged in, this will do a re-login.
                
        Args:
            imei (str): The device imei is logged into Zalo
            phone (str): Zalo account phone number
            password (str): Zalo account password
            user_agent (str): Custom user agent to use when sending requests. If `None`, user agent will be chosen from a premade list
            
        Raises:
            ZaloLoginError: On failed login
            LoginMethodNotSupport: If method login not support
        """
        if not (phone and password):
            raise ZaloUserError("Phone and password not set")
        
        self.onLoggingIn()
        
        self._state.login(
            phone,
            password,
            imei,
            user_agent=user_agent
        )
        try:
            self._imei = self._state.user_imei
            self.uid = self.fetchAccountInfo().profile.get("userId", self._state.user_id)
        except:
            self._imei = None
            self.uid = self._state.user_id
        
        self.onLoggedIn(self._state._config.get("phone_number"))
        
    """
    END LOGIN METHODS
    """
    
    """
    ATTACHMENTS METHODS
    """
    
    def _uploadFile(self, filePath, thread_id, thread_type):
        """Upload files to Zalo."""
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")

        with open(filePath, "rb") as f:
            file_data = f.read()
            fileSize = len(file_data)
            fileName = os.path.basename(filePath)
            files = [("chunkContent", (fileName, file_data))]

        params = {
            "params": {
                "totalChunk": 1,
                "fileName": fileName,
                "clientId": _util.now(),
                "totalSize": fileSize,
                "imei": self._imei,
                "chunkId": 1
            },
            "zpw_ver": 645,
            "zpw_type": 30,
        }

        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/file/upload"
            params["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/file/upload"
            params["params"]["grid"] = str(thread_id)

        params["params"] = self._encode(params["params"])
        response = self._post(url, params=params, files=files, timeout=25)
        try:
            data = response.json()
            if data.get("error_code") == 0:
                results = self._decode(data["data"])
                return results.get("data") if isinstance(results, dict) and results.get("error_code") == 0 else results
            return data
        except:
            return {"error_code": -1, "error_message": "Invalid JSON response from server"}

    def sendLocalVoice(self, filePath, thread_id, thread_type, ttl=0):
        """Send local voice file (.aac)."""
        upload = self._uploadFile(filePath, thread_id, thread_type)
        if not isinstance(upload, dict): return upload

        voice_url = upload.get('url') or upload.get('hdUrl')
        if voice_url:
            return self.sendRemoteVoice(voice_url, thread_id, thread_type, fileSize=upload.get('totalSize'), ttl=ttl)
        return upload

    def sendLocalFile(self, filePath, thread_id, thread_type, message=None, ttl=0):
        """Send local file to Zalo."""
        upload = self._uploadFile(filePath, thread_id, thread_type)
        if not isinstance(upload, dict): return upload

        fileUrl = upload.get('url') or upload.get('hdUrl')
        if not fileUrl: return upload

        fileName = os.path.basename(filePath)
        fileSize = upload.get('totalSize', 0)
        extension = fileName.split('.')[-1] if '.' in fileName else "bin"

        return self.sendRemoteFile(fileUrl, thread_id, thread_type, fileName=fileName, fileSize=fileSize, extension=extension, ttl=ttl)

    def sendFile(self, filePath, thread_id, thread_type, message=None, ttl=0):
        """Alias for sendLocalFile."""
        return self.sendLocalFile(filePath, thread_id, thread_type, message=message, ttl=ttl)

    def forwardFile(self, file_data, thread_id, thread_type, ttl=0):
        """Forward any Zalo attachment (File, Image, Video) to another thread (0 MB)."""
        params = {"zpw_ver": 645, "zpw_type": 30, "nretry": 0}

        # TỰ ĐỘNG NHẬN DIỆN LOẠI TIN NHẮN ĐỂ FORWARD
        # Type 2: File, Type 3: Image, Type 5: Video
        msg_type = 2 # Mặc định là file
        att_type = file_data.get('type')
        if att_type == 'image': msg_type = 3
        elif att_type == 'video': msg_type = 5

        payload = {
            "params": {
                "ttl": ttl,
                "msgType": msg_type,
                "clientId": str(_util.now()),
                "msgInfo": json.dumps(file_data)
            }
        }
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toid"] = str(thread_id)
            payload["params"]["imei"] = self._imei
        else:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)

        payload["params"] = self._encode(payload["params"])
        return self._post(url, params=params, data=payload)

    def _uploadImage(self, filePath, thread_id, thread_type):
        """Upload images to Zalo."""
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
            
        with open(filePath, "rb") as f:
            file_data = f.read()
            fileSize = len(file_data)
            fileName = os.path.basename(filePath)
            files = [("chunkContent", (fileName, file_data))]
        
        params = {
            "params": {
                "totalChunk": 1,
                "fileName": fileName,
                "clientId": _util.now(),
                "totalSize": fileSize,
                "imei": self._imei,
                "isE2EE": 0,
                "jxl": 0,
                "chunkId": 1
            },
            "zpw_ver": 645,
            "zpw_type": 30,
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/upload"
            params["type"] = 2
            params["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/upload"
            params["type"] = 11
            params["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        params["params"] = self._encode(params["params"])
        
        response = self._post(url, params=params, files=files, timeout=25)
        try:
            data = response.json()
            if data.get("error_code") != 0:
                return data

            results = self._decode(data["data"])
            if results and results.get("error_code") == 0:
                return results.get("data")
            return results
        except:
            return {"error_code": -1, "error_message": "Invalid JSON response from server"}

    """
    END ATTACHMENTS METHODS
    """
    
    """
    FETCH METHODS
    """
    
    def fetchAccountInfo(self):
        """fetch account information of the client 
        
        Returns:
            object: `User` client info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "avatar_size": 120,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30,
            "os": 8,
            "browser": 0
        }
        
        response = self._get("https://tt-profile-wpa.chat.zalo.me/api/social/profile/me-v2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm (V19.2)."""
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei,
                "src": 1 # Tham số quan trọng
            }),
            "zpw_ver": 650,
            "zpw_type": 30
        }

        try:
            response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
            if not response or not response.text:
                return None
            data = response.json()
        except:
            return None

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            return results.get("data") if isinstance(results, dict) else results

        return None
    
    def fetchPhoneNumber(self, phoneNumber, language="vi"):
        """Fetch user info by Phone Number.
        
        Not available with hidden phone numbers
        
        Args:
            phoneNumber (int | str): Phone number to fetch information
            language (str): Language for response (not sure | Default: vi)
        
        Returns:
            object: `User` user(s) info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        
        phone = "84" + str(phoneNumber) if str(phoneNumber)[:1] != "0" else "84" + str(phoneNumber)[1:]
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "params": self._encode({
                "phone": phone,
                "avatar_size": 240,
                "language": language,
                "imei": self._imei,
                "reqSrc": 85
            })
        }
        
        response = self._get("https://tt-friend-wpa.chat.zalo.me/api/friend/profile/get", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def fetchUserInfo(self, userId):
        """Fetch user info by ID.
        
        Args:
            userId (int | str | list): User(s) ID to get info
        
        Returns:
            object: `User` user(s) info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 641,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "phonebook_version": int(_util.now() / 1000),
                "friend_pversion_map": [],
                "avatar_size": 120,
                "language": "vi",
                "show_online_status": 1,
                "imei": self._imei
            }
        }
        
        if isinstance(userId, list):
            for i in range(len(userId)):
                userId[i] = str(userId[i]) + "_0"
            payload["params"]["friend_pversion_map"] = userId
            
        else:
            payload["params"]["friend_pversion_map"].append(str(userId) + "_0")
            
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/social/friend/getprofiles/v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def fetchGroupInfo(self, groupId):
        """Fetch group info by ID.
        
        Args:
            groupId (int | str | dict): Group(s) ID to get info
        
        Returns:
            object: `Group` group info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "gridVerMap": {}
            }
        }
        
        if isinstance(groupId, dict):
            for i in groupId:
                payload["params"]["gridVerMap"][str(i)] = 0
        else:
            payload["params"]["gridVerMap"][str(groupId)] = 0
            
        payload["params"]["gridVerMap"] = json.dumps(payload["params"]["gridVerMap"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/getmg-v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def fetchAllFriends(self):
        """Fetch all users the client is currently chatting with (only friends).
        
        Returns:
            object: `User` all friend IDs
            any: If response is not list friends
            
        Raises:
            ZaloAPIException: If request failed
        """
        
        params = {
            "params": self._encode({
                "incInvalid": 0,
                "page": 1,
                "count": 20000,
                "avatar_size": 120,
                "actiontime": 0
            }),
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        response = self._get("https://profile-wpa.chat.zalo.me/api/social/friend/getfriends", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            datas = []
            if results.get("data"):
                for data in results.get("data"):
                    datas.append(User(**data))
            
            return datas
                    
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def setMute(self, threadId, threadType, action=1):
        """Mute/Unmute a thread (Group or User).

        Args:
            threadId (str): User or Group ID
            threadType (ThreadType): ThreadType.USER or ThreadType.GROUP
            action (int): 1 to mute, 0 to unmute
        """
        params = {"zpw_ver": 664, "zpw_type": 30}
        payload = {"params": self._encode({
            "toid": str(threadId), "duration": -1, "action": action,
            "startTime": int(time.time()), "muteType": 2 if threadType == ThreadType.GROUP else 1,
            "imei": self._imei
        })}

        try:
            response = self._post("https://tt-profile-wpa.chat.zalo.me/api/social/profile/setmute", params=params, data=payload)
            data = response.json()
            return data.get("error_code") == 0
        except:
            return False

    def setNotifyGroup(self, groupId, action=1):
        return self.setMute(groupId, ThreadType.GROUP, action)

    def updateCategory(self, threadId, category=1):
        """Move a thread to Priority (0) or Other (1) tab.
        """
        params = {"zpw_ver": 664, "zpw_type": 30}
        payload = {
            "params": self._encode({
                "conversId": str(threadId),
                "category": category,
                "imei": self._imei
            })
        }

        try:
            response = self._post("https://tt-convers-wpa.chat.zalo.me/api/convers/update-category", params=params, data=payload)
            return response.json()
        except Exception as e:
            return {"error_code": -1, "error_message": str(e)}

    def fetchAllGroups(self):
        """Fetch all group IDs are joining and chatting.
        
        Returns:
            object: `Group` all group IDs
            any: If response is not all group IDs
        
        Raises:
            ZaloAPIException: If request failed
        """
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/getlg/v4", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    """
    END FETCH METHODS
    """
    
    """
    GET METHODS
    """
    
    def getLastMsgs(self):
        """Get last message the client's friends/group chat room.
            
        Returns:
            object: `User` last msg data
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": "645",
            "zpw_type": "30",
            "params": self._encode({
                "threadIdLocalMsgId": json.dumps({}),
                "imei": self._imei
            })
        }
        
        response = self._get("https://tt-convers-wpa.chat.zalo.me/api/preloadconvers/get-last-msgs", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def getRecentGroup(self, groupId, count=50, lastMsgId=None):
        """Lấy tin nhắn nhóm hỗ trợ lùi về quá khứ (V19.8 - Phục hồi chuẩn gốc)."""
        try:
            # Ưu tiên dùng lastMsgId dạng số, nếu không có dùng mốc Thần Tài dạng số
            g_id = int(lastMsgId) if (lastMsgId and str(lastMsgId) != "0") else 110560011931056001193
        except:
            g_id = 110560011931056001193

        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "globalMsgId": g_id,
                "count": int(count),
                "msgIds": [],
                "imei": self._imei,
                "src": 1
            }),
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0,
        }
        
        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/getrecentv2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Đảm bảo trả về đúng định dạng Group object
            if isinstance(results, dict) and "data" in results:
                try:
                    results = json.loads(results["data"])
                except: pass
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def _getGroupBoardList(self, board_type, page, count, last_id, last_type, groupId):
        params = {
            "params": self._encode({
                "group_id": str(groupId),
                "board_type": board_type,
                "page": page,
                "count": count,
                "last_id": last_id,
                "last_type": last_type,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://groupboard-wpa.chat.zalo.me/api/board/list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = Group.fromDict(results.get("data"), None)
            
            return results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def getGroupBoardList(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group board list (pinmsg, note, poll) by ID.
            
        Args:
            groupId (int | str): Group ID to get board list
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 poll, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` board data in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(0, page, count, last_id, last_type, groupId)
        
        return response
    
    def getGroupPinMsg(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group pinned messages by ID.
            
        Args:
            groupId (int | str): Group ID to get pinned messages
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 message, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` pinned messages in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(2, page, count, last_id, last_type, groupId)
        
        return response
    
    def getGroupNote(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group notes by ID.
            
        Args:
            groupId (int | str): Group ID to get notes
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 notes, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` notes in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(1, page, count, last_id, last_type, groupId)
        
        return response
    
    def getGroupPoll(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group polls by ID.
            
        Args:
            groupId (int | str): Group ID to get polls
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 poll, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` polls in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(3, page, count, last_id, last_type, groupId)
        
        return response
    
    """
    END GET METHODS
    """
    
    """
    ACCOUNT ACTION METHODS
    """
    
    def changeAccountSetting(self, name, dob, gender, biz={}, language="vi"):
        """Change account information.
        
        Args:
            name (str): The new account name
            dob (str): Date of birth wants to change (format: year-month-day)
            gender (int | str): Gender wants to change (0 = Male, 1 = Female)
            biz (unknown): idk this
            language (str): Zalo language wants to change (default = vn)
        
        Returns:
            object: `User` change account setting status
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "profile": json.dumps({
                    "name": name,
                    "dob": dob,
                    "gender": int(gender)
                }),
                "biz": json.dumps(biz),
                "language": language
            })
        }
        
        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/social/profile/update", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeAccountAvatar(self, filePath, width=500, height=500, language="vn", size=None):
        """Upload/Change account avatar.
        
        Args:
            filePath (str): A path to the image to upload/change avatar
            size (int): Avatar image size (default = auto)
            width (int): Width of avatar image
            height (int): height of avatar image
            language (int | str): Zalo Website language ? (idk)
            
        Returns:
            object: `User` Account avatar change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
        
        size = os.stat(filePath).st_size if not size else size
        files = [("fileContent", open(filePath, "rb"))]
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "params": self._encode({
                "avatarSize": 120,
                "clientId": str(self.uid) + _util.formatTime("%H:%M %d/%m/%Y"),
                "language": language,
                "metaData": json.dumps({
                    "origin": {
                        "width": width,
                        "height": height
                    },
                    "processed": {
                        "width": width,
                        "height": height,
                        "size": size
                    }
                })
            })
        }
        
        response = self._post("https://tt-files-wpa.chat.zalo.me/api/profile/upavatar", params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    """
    END ACCOUNT ACTION METHODS
    """
    
    """
    USER ACTION METHODS
    """
    
    def sendFriendRequest(self, userId, msg, language="vi"):
        """Send friend request to a user by ID.
            
        Args:
            userId (int | str): User ID to send friend request
            msg (str): Friend request message
            language (str): Response language or Zalo interface language

        Returns:
            object: `User` Friend requet response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "toid": str(userId),
                "msg": msg,
                "reqsrc": 30,
                "imei": self._imei,
                "language": language,
                "srcParams": json.dumps({
                    "uidTo": str(userId)
                })
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/sendreq", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def acceptFriendRequest(self, userId, language="vi"):
        """Accept friend request from user by ID.
            
        Args:
            userId (int | str): User ID to accept friend request
            language (str): Response language or Zalo interface language

        Returns:
            object: `User` Friend accept requet response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "language": language
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/accept", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def blockViewFeed(self, userId, isBlockFeed):
        """Block/Unblock friend view feed by ID.
            
        Args:
            userId (int | str): User ID to block/unblock view feed
            isBlockFeed (int): Block/Unblock friend view feed (1 = True | 0 = False)
        
        Returns:
            object: `User` Friend requet response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "isBlockFeed": isBlockFeed,
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/feed/block", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def blockUser(self, userId):
        """Block user by ID.
            
        Args:
            userId (int | str): User ID to block
        
        Returns:
            object: `User` Block response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/block", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def unblockUser(self, userId):
        """Unblock user by ID.
            
        Args:
            userId (int | str): User ID to unblock
        
        Returns:
            object: `User` Unblock response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/unblock", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    """
    END USER ACTION METHODS
    """
    
    """
    GROUP ACTION METHODS
    """
    
    def createGroup(self, name=None, description=None, members=[], nameChanged=1, createLink=1):
        """Create a new group.
            
        Args:
            name (str): The new group name
            description (str): Description of the new group
            members (str | list): List/String member IDs add to new group
            nameChanged (int - auto): Will use default name if disabled (0), else (1)
            createLink (int - default): Create a group link? Default = 1 (True)
            
        Returns:
            object: `Group` new group response
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        memberTypes = []
        nameChanged = 1 if name else 0
        name = name or "Default Group Name"
        
        if members and isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        if members:
            for i in members:
                memberTypes.append(-1)
            
        params = {
            "params": self._encode({
                "clientId": _util.now(),
                "gname": name,
                "gdesc": description,
                "members": members,
                "memberTypes": memberTypes,
                "nameChanged": nameChanged,
                "createLink": createLink,
                "clientLang": "vi",
                "imei": self._imei,
                "zsource": 601
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/create/v2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupAvatar(self, filePath, groupId):
        """Upload/Change group avatar by ID.
        
        Client must be the Owner of the group
        (If the group does not allow members to upload/change)
            
        Args:
            filePath (str): A path to the image to upload/change avatar
            groupId (int | str): Group ID to upload/change avatar
            
        Returns:
            object: `Group` Group avatar change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
            
            
        files = [("fileContent", open(filePath, "rb"))]
        
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "avatarSize": 120,
                "clientId": "g" + str(groupId) + _util.formatTime("%H:%M %d/%m/%Y"),
                "originWidth": 640,
                "originHeight": 640,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._post("https://tt-files-wpa.chat.zalo.me/api/group/upavatar", params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupName(self, groupName, groupId):
        """Set/Change group name by ID.
        
        Client must be the Owner of the group
        (If the group does not allow members to change group name)
            
        Args:
            groupName (str): Group name to change
            groupId (int | str): Group ID to change name
            
        Returns:
            object: `Group` Group name change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "gname": groupName,
                "grid": str(groupId)
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/updateinfo", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupDesc(self, groupDesc, groupId):
        """Not Available Yet"""
    
    def changeGroupSetting(self, groupId, defaultMode="default", **kwargs):
        """Update group settings by ID.
        
        Client must be the Owner/Admin of the group.
        
        Warning:
            Other settings will default value if not set. See `defaultMode`
        
        Args:
            groupId (int | str): Group ID to update settings
            defaultMode (str): Default mode of settings
            
                default: Group default settings
                anti-raid: Group default settings for anti-raid
            
            **kwargs: Group settings kwargs, Value: (1 = True, 0 = False)
            
                blockName: Không cho phép user đổi tên & ảnh đại diện nhóm
                signAdminMsg: Đánh dấu tin nhắn từ chủ/phó nhóm
                addMemberOnly: Chỉ thêm members (Khi tắt link tham gia nhóm)
                setTopicOnly: Cho phép members ghim (tin nhắn, ghi chú, bình chọn)
                enableMsgHistory: Cho phép new members đọc tin nhắn gần nhất
                lockCreatePost: Không cho phép members tạo ghi chú, nhắc hẹn
                lockCreatePoll: Không cho phép members tạo bình chọn
                joinAppr: Chế độ phê duyệt thành viên
                bannFeature: Default (No description)
                dirtyMedia: Default (No description)
                banDuration: Default (No description)
                lockSendMsg: Không cho phép members gửi tin nhắn
                lockViewMember: Không cho phép members xem thành viên nhóm
                blocked_members: Danh sách members bị chặn
        
        Returns:
            object: `Group` Group settings change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if defaultMode == "anti-raid":
            defSetting = {
                "blockName": 1,
                "signAdminMsg": 1,
                "addMemberOnly": 0,
                "setTopicOnly": 1,
                "enableMsgHistory": 1,
                "lockCreatePost": 1,
                "lockCreatePoll": 1,
                "joinAppr": 1,
                "bannFeature": 0,
                "dirtyMedia": 0,
                "banDuration": 0,
                "lockSendMsg": 0,
                "lockViewMember": 0,
            }
        else:
            defSetting = self.fetchGroupInfo(groupId).gridInfoMap
            defSetting = defSetting[str(groupId)]["setting"]
            
        blockName = kwargs.get("blockName", defSetting.get("blockName", 1))
        signAdminMsg = kwargs.get("signAdminMsg", defSetting.get("signAdminMsg", 1))
        addMemberOnly = kwargs.get("addMemberOnly", defSetting.get("addMemberOnly", 0))
        setTopicOnly = kwargs.get("setTopicOnly", defSetting.get("setTopicOnly", 1))
        enableMsgHistory = kwargs.get("enableMsgHistory", defSetting.get("enableMsgHistory", 1))
        lockCreatePost = kwargs.get("lockCreatePost", defSetting.get("lockCreatePost", 1))
        lockCreatePoll = kwargs.get("lockCreatePoll", defSetting.get("lockCreatePoll", 1))
        joinAppr = kwargs.get("joinAppr", defSetting.get("joinAppr", 1))
        bannFeature = kwargs.get("bannFeature", defSetting.get("bannFeature", 0))
        dirtyMedia = kwargs.get("dirtyMedia", defSetting.get("dirtyMedia", 0))
        banDuration = kwargs.get("banDuration", defSetting.get("banDuration", 0))
        lockSendMsg = kwargs.get("lockSendMsg", defSetting.get("lockSendMsg", 0))
        lockViewMember = kwargs.get("lockViewMember", defSetting.get("lockViewMember", 0))
        blocked_members = kwargs.get("blocked_members", [])
        
        params = {
            "params": self._encode({
                "blockName": blockName,
                "signAdminMsg": signAdminMsg,
                "addMemberOnly": addMemberOnly,
                "setTopicOnly": setTopicOnly,
                "enableMsgHistory": enableMsgHistory,
                "lockCreatePost": lockCreatePost,
                "lockCreatePoll": lockCreatePoll,
                "joinAppr": joinAppr,
                "bannFeature": bannFeature,
                "dirtyMedia": dirtyMedia,
                "banDuration": banDuration,
                "lockSendMsg": lockSendMsg,
                "lockViewMember": lockViewMember,
                "blocked_members": blocked_members,
                "grid": str(groupId),
                "imei":self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/setting/update", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupOwner(self, newAdminId, groupId):
        """Change group owner (yellow key) by ID.
        
        Client must be the Owner of the group.
            
        Args:
            newAdminId (int | str): members ID to changer owner
            groupId (int | str): ID of the group to changer owner
            
        Returns:
            object: `Group` Group owner change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "newAdminId": str(newAdminId),
                "imei": self._imei,
                "language": "vi"
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/change-owner", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def addUsersToGroup(self, user_ids, groupId):
        """Add friends/users to a group.
            
        Args:
            user_ids (str | list): One or more friend/user IDs to add
            groupId (int | str): Group ID to add friend/user to
        
        Returns:
            object: `Group` add friend/user data
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        memberTypes = []
        
        if user_ids and isinstance(user_ids, list):
            members = [str(user) for user in user_ids]
        else:
            members = [str(user_ids)]
            
        if members:
            for i in members:
                memberTypes.append(-1)
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "memberTypes": memberTypes,
                "imei": self._imei,
                "clientLang": "vi"
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/invite/v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def kickUsersInGroup(self, members, groupId):
        """Kickout members in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to kickout
            groupId (int | str): Group ID to kick member from
            
        Returns:
            object: `Group` kick data
            dict: A dictionary/object containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/kickout", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def blockUsersInGroup(self, members, groupId):
        """Blocked members in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to block
            groupId (int | str): Group ID to block member from
            
        Returns:
            object: `Group` block members response
            dict: A dictionary/object containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "params": self._encode({
                "grid": str(groupId),
                "members": members
            })
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/add", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def unblockUsersInGroup(self, members, groupId):
        """unblock members in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to unblock
            groupId (int | str): Group ID to unblock member from
            
        Returns:
            object: `Group` unblock members response
            dict: A dictionary/object containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "params": self._encode({
                "grid": str(groupId),
                "members": members
            })
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/remove", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def addGroupAdmins(self, members, groupId):
        """Add admins to the group (white key).
        
        Client must be the Owner of the group.
            
        Args:
            members (str | list): One or More member IDs to add
            groupId (int | str): Group ID to add admins
            
        Returns:
            object: `Group` Group admins add status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/admins/add", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def removeGroupAdmins(self, members, groupId):
        """Remove admins in the group (white key) by ID.
        
        Client must be the Owner of the group.
            
        Args:
            members (str | list): One or More admin IDs to remove
            groupId (int | str): Group ID to remove admins
            
        Returns:
            object: `Group` Group admins remove status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/admins/remove", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def pinGroupMsg(self, pinMsg, groupId):
        """Pin message in group by ID.
        
        Args:
            pinMsg (Message): Message Object to pin
            groupId (int | str): Group ID to pin message
        
        Returns:
            object: `Group` pin message status
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "grid": str(groupId),
                "type": 2,
                "color": -14540254,
                "emoji": "📌",
                "startTime": -1,
                "duration": -1,
                "repeat": 0,
                "src": -1,
                "imei": self._imei,
                "pinAct": 1
            }
        }
        
        if pinMsg.msgType == "webchat":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "title": pinMsg.content,
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.voice":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType in ["chat.photo", "chat.video.msg"]:
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "thumb": pinMsg.content.thumb,
                "title": pinMsg.content.description,
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.sticker":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "extra": json.dumps({
                    "id": pinMsg.content.id,
                    "catId": pinMsg.content.catId,
                    "type": pinMsg.content.type
                }),
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType in ["chat.recommended", "chat.link"]:
            
            extra = json.loads(pinMsg.content.params)
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "href": pinMsg.content.href,
                "thumb": pinMsg.content.thumb or "",
                "title": pinMsg.content.title,
                "linkCaption": "https://vrxx1337.vercel.app",
                "redirect_url": extra.get("redirect_url", ""),
                "streamUrl": extra.get("streamUrl", ""),
                "artist": extra.get("artist", ""),
                "stream_icon": extra.get("stream_icon", ""),
                "type": 2,
                "extra": json.dumps({
                    "action": pinMsg.content.action,
                    "params": json.dumps({
                        "mediaTitle": extra.get("mediaTitle", ""),
                        "artist": extra.get("artist", ""),
                        "src": extra.get("src", ""),
                        "stream_icon": extra.get("stream_icon", ""),
                        "streamUrl": extra.get("streamUrl", ""),
                        "type": 2
                    })
                }),
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.location.new":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "msg_type": _util.getClientMessageType(pinMsg.msgType),
                "title": pinMsg.content.title or pinMsg.content.description
            })
        
        elif pinMsg.msgType == "share.file":
            
            extra = json.loads(pinMsg.content.params)
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "title": pinMsg.content.title,
                "extra": json.dumps({
                    "fileSize": "7295",
                    "checksum": extra.get("checksum", ""),
                    "fileExt": extra.get("fileExt", ""),
                    "tWidth": extra.get("tWidth", 0),
                    "tHeight": extra.get("tHeight", 0),
                    "duration": extra.get("duration", 0),
                    "fType": extra.get("fType", 0),
                    "fdata": extra.get("fdata", ""),
                }),
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.gif":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "thumb": pinMsg.content.thumb,
                "msg_type": _util.getClientMessageType(pinMsg.msgType)
            })
        
        payload["params"] = self._encode(payload["params"])
        response = self._post("https://groupboard-wpa.chat.zalo.me/api/board/topic/createv2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def unpinGroupMsg(self, pinId, pinTime, groupId):
        """Unpin message in group by ID.
        
        Args:
            pinId (int | str): Pin ID to unpin
            pinTime (int): Pin start time
            groupId (int | str): Group ID to unpin message
        
        Returns:
            object: `Group` unpin message status
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "params": self._encode({
                "grid": str(groupId),
                "imei": self._imei,
                "topic": {
                    "topicId": str(pinId),
                    "topicType": 2
                },
                "boardVersion": int(pinTime)
            })
        }
        
        response = self._get("https://groupboard-wpa.chat.zalo.me/api/board/unpinv2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def deleteGroupMsg(self, msgId, ownerId, clientMsgId, groupId):
        """Delete message in group by ID.
        
        Args:
            groupId (int | str): Group ID to delete message
            msgId (int | str): Message ID to delete
            ownerId (int | str): Owner ID of the message to delete
            clientMsgId (int | str): Client message ID to delete message
        
        Returns:
            object: `Group` delete message status
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "cliMsgId": _util.now(),
                "msgs": [{
                    "cliMsgId": str(clientMsgId),
                    "globalMsgId": str(msgId),
                    "ownerId": str(ownerId),
                    "destId": str(groupId)
                }],
                "onlyMe": 0
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/deletemsg", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def viewGroupPending(self, groupId):
        """See list of people pending approval in group by ID.
        
        Args:
            groupId (int | str): Group ID to view pending members
            
        Returns:
            object: `Group` pending responses
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/pending-mems/list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def handleGroupPending(self, members, groupId, isApprove=True):
        """Approve/Deny pending users to the group from the group's approval.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to handle
            groupId (int | str): ID of the group to handle pending members
            isApprove (bool): Approve/Reject pending members (True | False)
            
        Returns:
            object: `Group` handle pending responses
            dict: A dictionary/object containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
        
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "isApprove": 1 if isApprove else 0
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/pending-mems/review", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
                
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def viewPollDetail(self, pollId):
        """View poll data by ID.
        
        Args:
            pollId (int | str): Poll ID to view detail
            
        Returns:
            object: `Group` poll data
            dict: A dictionary containing error_code & response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "poll_id": int(pollId),
                "imei":self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/poll/detail", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def createPoll(
        self,
        question,
        options,
        groupId,
        expiredTime=0,
        pinAct=False,
        multiChoices=True,
        allowAddNewOption=True,
        hideVotePreview=False,
        isAnonymous=False
    ):
        """Create poll in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            question (str): Question for poll
            options (str | list): List options for poll
            groupId (int | str): Group ID to create poll from
            expiredTime (int): Poll expiration time (0 = no expiration)
            pinAct (bool): Pin action (pin poll)
            multiChoices (bool): Allows multiple poll choices
            allowAddNewOption (bool): Allow members to add new options
            hideVotePreview (bool): Hide voting results when haven't voted
            isAnonymous (bool): Hide poll voters
            
        Returns:
            object: `Group` poll create data
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "group_id": str(groupId),
                "question": question,
                "options": [],
                "expired_time": expiredTime,
                "pinAct": pinAct,
                "allow_multi_choices": multiChoices,
                "allow_add_new_option": allowAddNewOption,
                "is_hide_vote_preview": hideVotePreview,
                "is_anonymous": isAnonymous,
                "poll_type": 0,
                "src": 1,
                "imei": self._imei
            }
        }
        
        if isinstance(options, list):
            payload["params"]["options"] = options
        else:
            payload["params"]["options"].append(str(options))
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/poll/create", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def lockPoll(self, pollId):
        """Lock/end poll in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            pollId (int | str): Poll ID to lock
            
        Returns:
            None: If requet success
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "poll_id": int(pollId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/poll/end", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def is_super_admin(self, user_id):
        """Kiểm tra xem user có phải là chủ sở hữu tối cao không."""
        # Lấy danh sách admin từ settings đã load trong main.py
        admin_id = getattr(self, 'ADMIN', None)
        adm_list = getattr(self, 'ADM', [])

        user_id_str = str(user_id)
        if user_id_str == str(admin_id):
            return True
        if user_id_str in [str(uid) for uid in adm_list]:
            return True
        return False

    def is_group_admin(self, group_id, user_id):
        try:
            group_details = self.fetchGroupInfo(group_id)
            if not group_details or not hasattr(group_details, 'gridInfoMap'):
                logger.warning(f"Không thể lấy thông tin chi tiết cho nhóm {group_id} để kiểm tra admin.")
                return False

            group_info = group_details.gridInfoMap.get(str(group_id))
            if not group_info:
                logger.warning(f"Không tìm thấy dữ liệu cho nhóm {group_id} trong response.")
                return False

            creator_id = group_info.get('creatorId')
            admin_ids = group_info.get('adminIds', [])

            user_id_str = str(user_id)
            
            if user_id_str == str(creator_id):
                return True
            
            if user_id_str in [str(admin) for admin in admin_ids]:
                return True
            
            return False
        except Exception as e:
            logger.error(f"Lỗi khi kiểm tra quyền admin của user {user_id} trong nhóm {group_id}: {e}")
            return False

    def leaveReadOnlyGroups(self, dry_run=False, whitelist_ids=None):
        if whitelist_ids is None:
            whitelist_ids = []
            
        summary = {
            "left_groups": [],
            "kept_groups": [],
            "failed_to_leave": [],
            "whitelisted_groups": [],
            "bot_is_admin_groups": []
        }
        action_prefix = "[DRY RUN] " if dry_run else ""

        logger.info(f"{action_prefix}Starting process to find and leave read-only groups...")

        try:
            all_groups_obj = self.fetchAllGroups()
            if not all_groups_obj or not hasattr(all_groups_obj, 'gridInfoMap') or all_groups_obj.gridVerMap is None:
                logger.info("Account is not a member of any groups. Process finished.")
                return summary
            
            group_ids = list(all_groups_obj.gridVerMap.keys())
            if not group_ids:
                logger.info("Account has no groups to process. Process finished.")
                return summary
            logger.info(f"Found {len(group_ids)} total groups. Checking permissions...")

        except ZaloAPIException as e:
            logger.error(f"Fatal error: Could not fetch the group list. Aborting. Error: {e}")
            return summary

        bot_uid = self.uid

        for group_id in group_ids:
            try:
                group_details = self.fetchGroupInfo(group_id)
                if not group_details or not hasattr(group_details, 'gridInfoMap'):
                    logger.warning(f"Could not retrieve valid details for group ID {group_id}. Skipping.")
                    continue
                    
                group_info = group_details.gridInfoMap.get(str(group_id))
                if not group_info:
                    logger.warning(f"Details for group ID {group_id} not found in response. Skipping.")
                    continue

                group_name = group_info.get("name", f"Unknown Group (ID: {group_id})")
                settings = group_info.get("setting", {})
                is_read_only = settings.get("lockSendMsg") == 1

                if str(group_id) in whitelist_ids:
                    logger.info(f"Skipping group '{group_name}' as it is in the whitelist.")
                    summary["whitelisted_groups"].append({"id": group_id, "name": group_name})
                    summary["kept_groups"].append({"id": group_id, "name": group_name})
                    continue

                if is_read_only:
                    creator_id = group_info.get('creatorId')
                    admin_ids = group_info.get('adminIds', [])
                    bot_is_admin_or_creator = (str(bot_uid) == str(creator_id)) or (str(bot_uid) in [str(admin) for admin in admin_ids])

                    if bot_is_admin_or_creator:
                        logger.info(f"Skipping read-only group '{group_name}' because bot is an admin/creator.")
                        summary["bot_is_admin_groups"].append({"id": group_id, "name": group_name})
                        summary["kept_groups"].append({"id": group_id, "name": group_name})
                        continue

                    logger.warning(f"{action_prefix}Group '{group_name}' is read-only and bot is not admin. Preparing to leave.")
                    if not dry_run:
                        try:
                            self.leaveGroup(grid=group_id, imei=self._imei)
                            logger.info(f"Successfully left group '{group_name}'.")
                            summary["left_groups"].append({"id": group_id, "name": group_name})
                        except ZaloAPIException as leave_error:
                            logger.error(f"Failed to leave group '{group_name}': {leave_error}")
                            summary["failed_to_leave"].append({"id": group_id, "name": group_name, "error": str(leave_error)})
                    else:
                        summary["left_groups"].append({"id": group_id, "name": group_name})
                else:
                    summary["kept_groups"].append({"id": group_id, "name": group_name})
                
                time.sleep(0.2)

            except ZaloAPIException as e:
                logger.error(f"An error occurred while processing group {group_id}: {e}")
                summary["failed_to_leave"].append({"id": group_id, "name": "Unknown (fetch failed)", "error": str(e)})

        logger.info("--- Process Complete ---")
        return summary
        
    def disperseGroup(self, groupId):
        """Disperse group by ID.
        
        Client must be the Owner of the group.
            
        Args:
            groupId (int | str): Group ID to disperse
            
        Returns:
            None: If requet success
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/disperse", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    """
    END GROUP ACTION METHODS
    """
    
    """
    SEND METHODS
    """
    
    def send(self, message, thread_id, thread_type=ThreadType.USER, mark_message=None, ttl=0):
        """Send message to a thread.
            
        Args:
            message (Message): Message to send
            thread_id (int | str): User/Group ID to send to
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        thread_id = str(int(thread_id) or self.uid)
        if message.mention:
            return self.sendMentionMessage(message, thread_id, ttl)
        else:
            return self.sendMessage(message, thread_id, thread_type, mark_message, ttl)
    
    def sendMessage(self, message, thread_id, thread_type, mark_message=None, ttl=0):
        """Send message to a thread (user/group).
            
        Args:
            message (Message): Message to send
            thread_id (int | str): User/Group ID to send to
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            mark_message (str): Send messages as `Urgent` or `Important` mark
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "message": message.text,
                "clientId": _util.now() * 60,
                "imei": self._imei,
                "ttl": ttl
            }
        }
        
        if mark_message and mark_message.lower() in ["important", "urgent"]:
            markType = 1 if mark_message.lower() == "important" else 2
            payload["params"]["metaData"] = {"urgency": markType}
        
        if message.style:
            payload["params"]["textProperties"] = message.style
            
        if thread_type == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sms"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendmsg"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendbug(self, message, thread_id, thread_type, mark_message=None, ttl=0):
        """Send message to a thread (user/group).
            
        Args:
            message (Message): Message to send
            thread_id (int | str): User/Group ID to send to
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            mark_message (str): Send messages as `Urgent` or `Important` mark
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "message": message.text,
                "clientId": _util.now() * 60,
                "imei": self._imei,
                "ttl": ttl
            }
        }
        
        if mark_message and mark_message.lower() in ["important", "urgent"]:
            markType = 1 if mark_message.lower() == "important" else 2
            payload["params"]["metaData"] = {"urgency": markType}
        
        if message.style:
            payload["params"]["textProperties"] = message.style
            
        if thread_type == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sms"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendmsg"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def replyMessage(self, message, replyMsg, thread_id, thread_type, ttl=0):
        """Reply message in group by ID.
            
        Args:
            message (Message): Message Object to send
            replyMsg (Message): Message Object to reply
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "message": message.text,
                "clientId": _util.now(),
                "qmsgOwner": str(int(replyMsg.uidFrom) or self.uid),
                "qmsgId": replyMsg.msgId,
                "qmsgCliId": replyMsg.cliMsgId,
                "qmsgType": _util.getClientMessageType(replyMsg.msgType),
                "qmsg": replyMsg.content,
                "qmsgTs": replyMsg.ts,
                "qmsgAttach": json.dumps({}),
                "qmsgTTL": 0,
                "ttl": ttl,
            }
        }
        
        if not isinstance(replyMsg.content, str):
            payload["params"]["qmsg"] = ""
            payload["params"]["qmsgAttach"] = json.dumps(replyMsg.content.toDict())
        
        if message.style:
            payload["params"]["textProperties"] = message.style
            
        if message.mention:
            payload["params"]["mentionInfo"] = message.mention
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/quote"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/quote"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendMentionMessage(self, message, groupId, ttl=0):
        """Send message to a group with mention by ID.
            
        Args:
            mention (str): Mention format data to send
            message (Message): Message to send
            groupId: Group ID to send to.
            
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "grid": str(groupId),
                "message": message.text,
                "mentionInfo": message.mention,
                "clientId": _util.now() * 60,
                "visibility": 0,
                "ttl": ttl
            }
        }
        
        if message.style:
            payload["params"]["textProperties"] = message.style
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/mention", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def undoMessage(self, msgId, cliMsgId, thread_id, thread_type):
        """Undo message from the client by ID.
            
        Args:
            msgId (int | str): Message ID to undo
            cliMsgId (int | str): Client Msg ID to undo
            thread_id (int | str): User/Group ID to undo message
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` undo message status
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "msgId": str(msgId),
                "cliMsgIdUndo": str(cliMsgId),
                "clientId": _util.now()
            } 
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat3-wpa.chat.zalo.me/api/message/undo"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/undomsg"
            payload["params"]["grid"] = str(thread_id)
            payload["params"]["visibility"] = 0
            payload["params"]["imei"] = self._imei
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendReaction(self, messageObject, reactionIcon, thread_id, thread_type, reactionType=75):
        """Reaction message by ID.
            
        Args:
            messageObject (Message): Message Object to reaction
            reactionIcon (str): Icon/Text to reaction
            thread_id (int | str): Group/User ID contain message to reaction
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` message reaction data
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "react_list": [{
                    "message": json.dumps({
                        "rMsg": [{
                            "gMsgID": int(messageObject.msgId),
                            "cMsgID": int(messageObject.cliMsgId),
                            "msgType": _util.getClientMessageType(messageObject.msgType)
                        }],
                        "rIcon": reactionIcon,
                        "rType": reactionType,
                        "source": 6
                    }),
                    "clientId": _util.now()
                }],
                "imei": self._imei
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://reaction.chat.zalo.me/api/message/reaction"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://reaction.chat.zalo.me/api/group/reaction"
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendMultiReaction(self, reactionObj, reactionIcon, thread_id, thread_type, reactionType=75):
        """Reaction message by ID.
            
        Args:
            reactionObj (MessageReaction): Message(s) data to reaction
            reactionIcon (str): Icon/Text to reaction
            thread_id (int | str): Group/User ID contain message to reaction
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` message reaction data
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "react_list": [{
                    "message": {
                        "rMsg": [],        
                        "rIcon": reactionIcon,
                        "rType": reactionType,
                        "source": 6
                    },
                    "clientId": _util.now()
                }],
                "imei": self._imei
            }
        }
        
        if isinstance(reactionObj, dict):
            payload["params"]["react_list"][0]["message"]["rMsg"].append(reactionObj)
        elif isinstance(reactionObj, list):
            payload["params"]["react_list"][0]["message"]["rMsg"] = reactionObj
        else:
            raise ZaloUserError("Reaction type is invalid")
        
        if thread_type == ThreadType.USER:
            url = "https://reaction.chat.zalo.me/api/message/reaction"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://reaction.chat.zalo.me/api/group/reaction"
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"]["react_list"][0]["message"] = json.dumps(payload["params"]["react_list"][0]["message"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendRemoteFile(self, fileUrl, thread_id, thread_type, fileName="default", fileSize=None, extension="vrxx", ttl=0, checksum=None):
        """Send File to a User/Group with url.
            
        Args:
            fileUrl (str): File url to send
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            fileName (str): File name to send
            fileSize (int): File size to send
            extension (str): type of file to send (py, txt, mp4, ...)
            checksum (str): File MD5 checksum (if available)

        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        fileChecksum = checksum
        if not fileSize or not fileChecksum:
            try:
                # Chỉ tải về nếu thiếu fileSize hoặc checksum
                with self._state._session.get(fileUrl, stream=True) as response:
                    if response.status_code == 200:
                        if not fileSize:
                            fileSize = int(response.headers.get("Content-Length", 0))

                        if not fileChecksum:
                            # Tải toàn bộ để tính checksum (Zalo bắt buộc MD5)
                            content = response.content
                            if not fileSize: fileSize = len(content)
                            fileChecksum = hashlib.md5(content).hexdigest()
                    else:
                        if not fileSize: fileSize = 0
                        if not fileChecksum: fileChecksum = ""
            except:
                if not fileSize: fileSize = 0
                if not fileChecksum: fileChecksum = ""

        has_extension = fileName.rsplit(".")
        extension = has_extension[-1:][0] if len(has_extension) >= 2 else extension
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "fileId": str(int(_util.now() * 2)),
                "checksum": fileChecksum,
                "checksumSha": "",
                "extension": extension,
                "totalSize": fileSize,
                "fileName": fileName,
                "clientId": _util.now(),
                "fType": 1,
                "fileCount": 0,
                "fdata": "{}",
                "fileUrl": fileUrl,
                "zsource": 401,
                "ttl": ttl
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/asyncfile/msg"
            payload["params"]["toid"] = str(thread_id)
            payload["params"]["imei"] = self._imei
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/asyncfile/msg"
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendRemoteVideo(self, videoUrl, thumbnailUrl, duration, thread_id, thread_type, width=1280, height=720, message=None, ttl=0):
        """Send (Forward) video to a User/Group with url.
        
        Warning:
            This is a feature created through the forward function.
            Because Zalo Web does not allow viewing videos.
        
        Args:
            videoUrl (str): Video link to send
            thumbnailUrl (str): Thumbnail link for video
            duration (int | str): Time for video (ms)
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            width (int): Width of the video
            height (int): Height of the video
            message (Message): Message to send with video
        
        Returns:
            object: `User/Group` (Returns msg ID just sent)
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        try:
            with self._state._session.head(videoUrl) as response:
                if response.status_code == 200:
                    fileSize = int(response.headers.get("Content-Length", len(response.content)))
                else:
                    fileSize = 0
                
        except Exception as e:
            raise ZaloAPIException(f"Unable to get url content: {e}")
            
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "clientId": str(_util.now()),
                "ttl": ttl,
                "zsource": 704,
                "msgType": 5,
                "msgInfo": json.dumps({
                    "videoUrl": str(videoUrl),
                    "thumbUrl": str(thumbnailUrl),
                    "duration": int(duration),
                    "width": int(width),
                    "height": int(height),
                    "fileSize": fileSize,
                    "properties": {
                        "color": -1,
                        "size": -1,
                        "type": 1003,
                        "subType": 0,
                        "ext": {
                            "sSrcType": -1,
                            "sSrcStr": "",
                            "msg_warning_type": 0
                        }
                    },
                    "title": message.text or "" if message else ""
                })
            }
        }
        
        if message and message.mention:
            payload["params"]["mentionInfo"] = message.mention
        
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toId"] = str(thread_id)
            payload["params"]["imei"] = self._imei
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendRemoteVoice(self, voiceUrl, thread_id, thread_type, fileSize=None, ttl=0, duration=None):
        """Send voice by url.
            
        Args:
            voiceUrl (str): Voice link to send
            thread_id (int | str): User/Group ID to change status in
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            fileSize (int | str): Voice content length (size) to send
            duration (int): Audio duration in milliseconds (optional)

        Returns:
            object: `User/Group` response
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not fileSize or not duration:
            try:
                with self._state._session.get(voiceUrl, timeout=10) as response:
                    if response.status_code == 200:
                        fileSize = fileSize or int(response.headers.get("Content-Length", 0))
            except:
                pass

        fileSize = fileSize or 0
        duration = duration or 5000 # Default 5s if unknown
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "ttl": ttl,
                "zsource": -1,
                "msgType": 3,
                "isE2EE": 0,
                "clientId": str(_util.now()),
                "msgInfo": json.dumps({
                    "voiceUrl": str(voiceUrl),
                    "m4aUrl": str(voiceUrl),
                    "fileSize": int(fileSize),
                    "duration": int(duration),
                    "type": "audio"
                })
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toid"] = str(thread_id)
            payload["params"]["imei"] = self._imei
        else:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            if response.status_code == 200:
                return {"error_code": 0, "status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        if data.get("error_code") == 0:
            results = data.get("data")
            if not results:
                return {"error_code": 0, "status": "success"}

            results = self._decode(results)
            results = results.get("data") if isinstance(results, dict) and results.get("data") else results

            if results == None:
                return {"error_code": 0, "status": "success"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    pass
            
            try:
                return (
                    Group.fromDict(results, None)
                    if thread_type == ThreadType.GROUP else
                    User.fromDict(results, None)
                )
            except:
                return {"error_code": 0, "data": results}

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendLocalImage(self, imagePath, thread_id, thread_type, width=2560, height=2560, message=None, custom_payload=None, ttl=0):
        """Send Image to a User/Group with local file.
            
        Args:
            imagePath (str): Image directory to send
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            width (int): Image width to send
            height (int): Image height to send
            message (Message): Message to send with image
            
        Returns:
            object: `User/Group` objects response
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        if custom_payload:
            if thread_type == ThreadType.USER:
                url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/send"
            elif thread_type == ThreadType.GROUP:
                url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/send"
            else:
                raise ZaloUserError("Thread type is invalid")
            
            payload = custom_payload
        
        else:
            uploadImage = self._uploadImage(imagePath, thread_id, thread_type)
            if not isinstance(uploadImage, dict) or "normalUrl" not in uploadImage:
                return uploadImage # Trả về lỗi thay vì crash

            payload = {
                "params": {
                    "photoId": uploadImage.get("photoId", int(_util.now() * 2)),
                    "clientId": uploadImage.get("clientFileId", int(_util.now() - 1000)) * 60,
                    "desc": message.text if message else "" or "",
                    "width": width,
                    "height": height,
                    "rawUrl": uploadImage.get("normalUrl"),
                    "thumbUrl": uploadImage.get("thumbUrl"),
                    "hdUrl": uploadImage.get("hdUrl"),
                    "thumbSize": "53932",
                    "fileSize": "247671",
                    "hdSize": "344622",
                    "zsource": -1,
                    "jcp": json.dumps({"sendSource": 1, "convertible": "jxl"}),
                    "ttl": ttl,
                    "imei": self._imei
                }
            }
        
            if message and message.mention:
                payload["params"]["mentionInfo"] = message.mention
            
            if thread_type == ThreadType.USER:
                url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_original/send"
                payload["params"]["toid"] = str(thread_id)
                payload["params"]["normalUrl"] = uploadImage["normalUrl"]
            elif thread_type == ThreadType.GROUP:
                url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_original/send"
                payload["params"]["grid"] = str(thread_id)
                payload["params"]["oriUrl"] = uploadImage["normalUrl"]
            else:
                raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendMultiLocalImage(self, imagePathList, thread_id, thread_type, width=2560, height=2560, message=None, ttl=0):
        """Send Multiple Image to a User/Group with local file.
            
        Args:
            imagePathList (list): List image directory to send
            width (int): Image width to send
            height (int): Image height to send
            message (Message): Message to send with image
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        uploadData = []
        
        if not isinstance(imagePathList, list) or len(imagePathList) < 1:
            raise ZaloUserError("image path must be a list to be able to send multiple at once.")
        
        groupLayoutId = str(_util.now())
        
        for i, imagePath in enumerate(imagePathList):
            uploadImage = self._uploadImage(imagePath, thread_id, thread_type)
        
            payload = {
                "params": {
                    "photoId": uploadImage.get("photoId", int(_util.now() * 2)),
                    "clientId": uploadImage.get("clientFileId", int(_util.now() - 1000)),
                    "desc": message.text if message else "" or "",
                    "width": width,
                    "height": height,
                    "groupLayoutId": groupLayoutId,
                    "totalItemInGroup": len(imagePathList),
                    "isGroupLayout": 1,
                    "idInGroup": i,
                    "rawUrl": uploadImage["normalUrl"],
                    "thumbUrl": uploadImage["thumbUrl"],
                    "hdUrl": uploadImage["hdUrl"],
                    "thumbSize": "53932",
                    "fileSize": "247671",
                    "hdSize": "344622",
                    "zsource": -1,
                    "jcp": json.dumps({"sendSource": 1, "convertible": "jxl"}),
                    "ttl": ttl,
                    "imei": self._imei
                }
            }
        
            if message and message.mention:
                payload["params"]["mentionInfo"] = message.mention
            
            if thread_type == ThreadType.USER:
                payload["params"]["toid"] = str(thread_id)
                payload["params"]["normalUrl"] = uploadImage["normalUrl"]
            elif thread_type == ThreadType.GROUP:
                payload["params"]["grid"] = str(thread_id)
                payload["params"]["oriUrl"] = uploadImage["normalUrl"]
            else:
                raise ZaloUserError("Thread type is invalid")
            
            data = self.sendLocalImage(imagePath, thread_id, thread_type, width, height, message, custom_payload=payload)
            uploadData.append(data.toDict())
        
        return (
            Group.fromDict(uploadData, None) 
            if thread_type == ThreadType.GROUP else 
            User.fromDict(uploadData, None)
        )
    
    def sendLocalGif(self, gifPath, thumbnailUrl, thread_id, thread_type, gifName="vrxx.gif", width=500, height=500, ttl=0):
        """Send Gif to a User/Group with local file.
            
        Args:
            gifPath (str): Gif path to send
            thumbnailUrl (str): Thumbnail of gif to send
            gifName (str): Gif name to send
            width (int): Gif width to send
            height (int): Gif height to send
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(gifPath):
            raise ZaloUserError(f"{gifPath} not found")
            
        files = [("chunkContent", open(gifPath, "rb"))]
        gifSize = len(open(gifPath, "rb").read())
        gifName = gifName if gifName else gifPath if "/" not in gifPath else gifPath.rstrip("/")[1]
        fileChecksum = hashlib.md5(open(gifPath, "rb").read()).hexdigest()
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "type": 1,
            "params": {
                "clientId": str(_util.now()),
                "fileName": gifName,
                "totalSize": gifSize,
                "width": width,
                "height": height,
                "msg": "",
                "type": 1,
                "ttl": ttl,
                "thumb": thumbnailUrl,
                "checksum": fileChecksum,
                "totalChunk": 1,
                "chunkId": 1
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/gif"
            params["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/gif"
            params["params"]["visibility"] = 0
            params["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        params["params"] = self._encode(params["params"])
        
        response = self._post(url, params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendSticker(self, stickerType, stickerId, cateId, thread_id, thread_type, ttl=0):
        """Send Sticker to a User/Group.
            
        Args:
            stickerType (int | str): Sticker type to send
            stickerId (int | str): Sticker id to send
            cateId (int | str): Sticker category id to send
            thread_id (int | str): User/Group ID to send to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            object: `User/Group` objects
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "stickerId": int(stickerId),
                "cateId": int(cateId),
                "type": int(stickerType),
                "clientId": _util.now(),
                "imei": self._imei,
                "ttl": ttl,
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat2-wpa.chat.zalo.me/api/message/sticker"
            payload["params"]["zsource"] = 106
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sticker"
            payload["params"]["zsource"] = 103
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def sendCustomSticker(
        self,
        staticImgUrl,
        animationImgUrl,
        thread_id,
        thread_type,
        reply=None,
        width=None,
        height=None,
        ttl=0
    ):
        """Send custom (static/animation) sticker to a User/Group with url.
            
        Args:
            staticImgUrl (str): Image url (png, jpg, jpeg) format to create sticker
            animationImgUrl (str): Static/Animation image url (webp) format to create sticker
            thread_id (int | str): User/Group ID to send sticker to.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            reply (int | str): Message ID to send stickers with quote
            width (int | str): Width of photo/sticker
            height (int | str): Height of photo/sticker
            
        Returns:
            object: `User/Group` sticker data
            dict: A dictionary containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        width = int(width) if width else 0
        height = int(height) if height else 0
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "clientId": _util.now(),
                "title": "",
                "oriUrl": staticImgUrl,
                "thumbUrl": staticImgUrl,
                "hdUrl": staticImgUrl,
                "width": width,
                "height": height,
                "properties": json.dumps({
                    "subType": 0,
                    "color": -1,
                    "size": -1,
                    "type": 3,
                    "ext": json.dumps({
                        "sSrcStr": "@STICKER",
                        "sSrcType": 0
                    })
                }),
                "contentId": _util.now(),
                "thumb_height": width,
                "thumb_width": height,
                "webp": json.dumps({
                    "width": width,
                    "height": height,
                    "url": animationImgUrl
                }),
                "zsource": -1,
                "ttl": ttl
            }
        }
        
        if reply:
            payload["params"]["refMessage"] = str(reply)
            
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/photo_url"
            payload["params"]["toId"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/photo_url"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendLink(self, linkUrl, title, thread_id, thread_type, thumbnailUrl=None, domainUrl=None, desc=None, message=None, ttl=0):
        """Send link to a User/Group with url.
            
        Args:
            linkUrl (str): Link url to send
            domainUrl (str): Main domain of Link to send (eg: github.com)
            thread_id (int | str): User/Group ID to send link to
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            thumbnailUrl (str): Thumbnail link url for card to send
            title (str): Title for card to send
            desc (str): Description for card to send
            message (Message): Message object to send with the link
            
        Returns:
            object: `User/Group` message id response
            dict: A dictionary containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "msg": message.text if message else "" or "",
                "href": linkUrl,
                "src": domainUrl or "",
                "title": str(title),
                "desc": desc or "",
                "thumb": thumbnailUrl or "",
                "type": 0,
                "media": json.dumps({
                    "type": 0,
                    "count": 0,
                    "mediaTitle": "",
                    "artist": "",
                    "streamUrl": "",
                    "stream_icon": ""
                }),
                "ttl": ttl,
                "clientId": _util.now()
            }
        }
        
        if message and message.mention:
            payload["params"]["mentionInfo"] = message.mention
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat4-wpa.chat.zalo.me/api/message/link"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendlink"
            payload["params"]["imei"] = self._imei
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def makeCall(self,uid):
            callId=int(time.time()) 
            params = {
                "params": self._encode({
                    'calleeId': str(uid),
                    'callId': callId,
                    'codec': '[]\n',
                    'typeRequest': 1,
                    'imei': self._imei
                }),
                "zpw_ver": 650,
                "zpw_type": 24
            }
            response = self._get("https://voicecall-wpa.chat.zalo.me/api/voicecall/requestcall", params=params)
            data = response.json()
            if data.get("error_code") == 0:
                decoded_data = self._decode(data.get("data"))
                data_fainal = decoded_data.get("data", {})
                data_fainal["callId"] = callId
                return data_fainal
            return None


    def makeCallRequest(self,uid, data_call):
            params = {
                "params": self._encode({
                    'calleeId': str(uid),
                    'rtcpAddress': data_call['rtpIP'],
                    'rtpAddress': data_call['rtpIP'],
                    'codec': json.dumps([{
                        'dynamicFptime': 0,
                        'frmPtime': 20,
                        'name': f"opus/{data_call['zrtc_config']['audioSampleRate']}/{data_call['zrtc_config']['audioChannel']}",
                        'payload': 112
                    }]),
                    'session': data_call['sessId'],
                    'callId': data_call['callId'],
                    'imei': self._imei,
                    'extendData': json.dumps({
                        'supportCallBusy': data_call['settings']['supportCallBusy'],
                        'tpType': 0,
                        "video":json.dumps({"codec":[{"name":"h264","payload":97}]})
                    }),
                    'subCommand': 3
                }),
                "zpw_ver": 650,
                "zpw_type": 24
            }
            response = self._get("https://voicecall-wpa.chat.zalo.me/api/voicecall/request", params=params)
            data = response.json()
            if data.get("error_code") == 0:
                decoded_data = self._decode(data.get("data"))
                return decoded_data.get("data")
            return None
    
    def newlink(self, grid):
            params_data = {
                "grid": grid
            }

            params = {
                "zpw_ver": 650,
                "zpw_type": 30,
                "params": self._encode(params_data)
            }

            response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/link/new", data=params)
            data = response.json()

            if data.get("error_code") == 0:
                new_link_info = self._decode(data.get("data"))
                if new_link_info and new_link_info.get("link"):
                    return {"success": True, "new_link": new_link_info.get("link")}
                else:
                    return {"success": False, "error_code": 1337, "error_message": "Không tìm thấy liên kết mới."}
            else:
                error_code = data.get("error_code")
                error_message = data.get("error_message", "Lỗi không xác định từ API.")
                return {"success": False, "error_code": error_code, "error_message": error_message}

    def dislink(self, grid):
            params_data = {
                "grid": grid
            }

            params = {
                "zpw_ver": 650,
                "zpw_type": 30,
                "params": self._encode(params_data)
            }

            response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/link/disable", data=params)
            data = response.json()

            if data.get("error_code") == 0:
                return {"success": True, "message": "Đã vô hiệu hóa liên kết nhóm thành công."}
            else:
                error_code = data.get("error_code")
                error_message = data.get("error_message", "Lỗi không xác định từ API.")
                return {"success": False, "error_code": error_code, "error_message": error_message}

    def getQRLink(self, userId):
            """Lấy Link QR của người dùng.
            
            Args:
                userId (int | str): ID người dùng cần lấy QR code
                
            Returns:
                dict: Dictionary chứa QR code URL của người dùng
                dict: Dictionary chứa error_code và response nếu thất bại
                
            Raises:
                ZaloAPIException: Nếu request thất bại
            """
            params = {
                "zpw_ver": 641,
                "zpw_type": 30
            }
            
            payload = {
                "params": self._encode({
                    "fids": [str(userId)]
                })
            }
            
            response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/mget-qr", params=params, data=payload)
            data = response.json()
            results = data.get("data") if data.get("error_code") == 0 else None
            if results:
                results = self._decode(results)
                results = results.get("data") if results.get("data") else results
                if results == None:
                    results = {"error_code": 1337, "error_message": "Data is None"}
                
                if isinstance(results, str):
                    try:
                        results = json.loads(results)
                    except:
                        results = {"error_code": 1337, "error_message": results}
                
                return results
                
            error_code = data.get("error_code")
            error_message = data.get("error_message") or data.get("data")
            raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def remove_blocked_member(self, grid, member_ids):
        params_data = {
            "grid": grid,
            "members": member_ids
        }

        params = {
            "zpw_ver": 650,
            "zpw_type": 30,
            "params": self._encode(params_data)
        }

        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/remove", params=params)
        data = response.json()

        if data.get("error_code") == 0:
            return {"success": True, "message": "Xóa thành viên bị chặn thành công."}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message", "Lỗi không xác định từ API.")
            return {"success": False, "error_code": error_code, "error_message": error_message}

    def TaoIDCall(self):
        return ''.join([str(random.randint(0, 9)) for _ in range(9)])
    def sendCall(self, target_id, callid_random):
        payload = {
            "params": {
                "calleeId": target_id,
                "callId": callid_random,
                "codec": "[]\n",
                "typeRequest": 1,
                "imei": self._imei
            }
        }
        payload["params"] = self._encode(payload["params"])
        call_url1 = 'https://voicecall-wpa.chat.zalo.me/api/voicecall/requestcall?zpw_ver=646&zpw_type=24'
        response = self._post(call_url1, params=payload["params"], data=payload)
        json_data = json.loads(response.text)
        call_payload = {
                "params": {
                    'calleeId': target_id,
                    'rtcpAddress': "171.244.25.88:4601",
                    'rtpAddress': "171.244.25.88:4601",
                    'codec': '[{"dynamicFptime":0,"frmPtime":20,"name":"opus/16000/1","payload":112}]\n',
                    'session': callid_random,
                    'callId': callid_random,
                    'imei': self._imei,
                    'subCommand': 3
                }
        }
        call_payload["params"] = self._encode(call_payload["params"])
        call_url2 = 'https://voicecall-wpa.chat.zalo.me/api/voicecall/request?zpw_ver=646&zpw_type=24'
        response = self._post(call_url2, params=call_payload["params"], data=call_payload)

    def get_blocked_members(self, grid, page=1, count=50):
        params_data = {
            "grid": grid,
            "page": page,
            "count": count
        }

        params = {
            "zpw_ver": 650,
            "zpw_type": 30,
            "params": self._encode(params_data)
        }

        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/list", params=params)
        data = response.json()

        if data.get("error_code") == 0:
            blocked_list = self._decode(data.get("data"))
            return {"success": True, "blocked_members": blocked_list}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message", "Lỗi không xác định từ API.")
            return {"success": False, "error_code": error_code, "error_message": error_message}

    def checkGroup(self, link):
        params = {
        "params": self._encode({
        "link": link,
        "avatar_size": 120,
        "member_avatar_size": 120,
        "mpage": 1
        }),
        "zpw_ver": 650,
        "zpw_type": 30
        }

        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/link/ginfo", params=params)
        data = response.json()

        if data.get("error_code") == 0:
            decoded_data = self._decode(data.get("data"))
            if decoded_data and decoded_data.get("data"):
                return decoded_data.get("data")
            else:
                return {"error_code": 1337, "error_message": "Không tìm thấy dữ liệu nhóm."}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message", "Lỗi không xác định từ API.")
        return {"error_code": error_code, "error_message": error_message}

    def unfriendUser(self, userId, language="vi"):
        """Unfriend a user by ID.
        
        Args:
            userId (int | str): User ID to unfriend.
            language (str): Response language or Zalo interface language.

        Returns:
            dict: A dictionary containing the unfriend status information.
        
        Raises:
            ZaloAPIException: If request failed.
        """
        params = {
            "zpw_ver": 641,
            "zpw_type": 30
        }
        
        payload = {
            "params": self._encode({
                "fid": str(userId),
                "language": language
            })
        }
        
        response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/remove", 
                            params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            return {"status": "success", "message": "Unfriended successfully."}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message") or data.get("data")
            raise ZaloAPIException(f"Error #{error_code} when unfriending: {error_message}")
        
    def joinGroup(self, groupLink):
        payload = {
            "link": groupLink,
            "clientLang": "vi"
        }
        
        params = {
            "params": self._encode(payload),
            "zpw_ver": 647,
            "zpw_type": 30
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/link/join", params=params)
        
        data = response.json()
        if data.get("error_code") == 0:
            decoded_data = self._decode(data.get("data"))
            return decoded_data

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def getIDsGroup(self, url):
        params = {
            "zpw_ver": 648,
            "zpw_type": 30
        }
        payload = {
            "params": self._encode({
                "link": str(url),
                "clientLang": "vi"
            })
        }

        try:
            response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/link/ginfo",
                                    params=params,
                                    data=payload)

            data = response.json()
            results = data.get("data") if data.get("error_code") == 0 else None

            if results:
                results = self._decode(results)
                results = results.get("data") if results.get("data") else results

                if results is None:
                    results = {"error_code": 1337, "error_message": "Data is None"}

                if isinstance(results, str):
                    try:
                        results = json.loads(results)
                    except:
                        results = {"error_code": 1337, "error_message": results}

                return results

            error_code = data.get("error_code")
            error_message = data.get("error_message") or data.get("data")
            raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

        except ZaloAPIException as e:
            raise e
        except Exception as e:
            raise ZaloAPIException(f"An unexpected error occurred: {e}")
                       
    def leaveGroup(self, grid, imei, silent=1, language="vi"):
        payload = {
            "grids": [grid],
            "imei": imei,
            "silent": silent,
            "language": language
        }
        params = {
            "params": self._encode(payload),
            "zpw_ver": 647,
            "zpw_type": 30
        }
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/leave", params=params)
        data = response.json()
        if data.get("error_code") == 0:
            decoded_data = self._decode(data.get("data"))
            return decoded_data
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error {error_code} when sending requests: {error_message}")
    
    def sendToDo(self, message_object, content, assignees, thread_id, thread_type, due_date=-1, description=""):
        """Gửi một todo đến người dùng hoặc nhóm.
        
        Args:
            message_object (Message): Message object gốc
            content (str): Nội dung todo
            assignees (list): Danh sách ID người nhận
            thread_id (str): ID của thread 
            thread_type (ThreadType): Loại thread (USER/GROUP)
            due_date (int): Thời hạn (-1 nếu không có)
            description (str): Mô tả (có thể trống)
            
        Returns:
            object: Kết quả từ API
            
        Raises:
            ZaloAPIException: Nếu request thất bại
        """
        if not content:
            raise ZaloAPIException("Missing todo content")
        if not assignees:
            raise ZaloAPIException("Missing assignees")

        params = {
            "zpw_ver": 641,
            "zpw_type": 30
        }

        is_group = thread_type == ThreadType.GROUP

        payload = {
            "params": {
                "assignees": json.dumps(assignees),
                "dueDate": due_date,
                "content": content,
                "description": description,
                "extra": json.dumps({
                    "msgId": message_object.msgId,
                    "toUid": thread_id,
                    "isGroup": is_group,
                    "cliMsgId": message_object.cliMsgId,
                    "msgType": 1,
                    "mention": [],
                    "ownerMsgUId": self.uid,
                    "message": content
                }),
                "dateDefaultType": 0,
                "status": -1, 
                "watchers": "[]",
                "schedule": None,
                "src": 5,
                "imei": self._imei
            }
        }

        payload["params"] = self._encode(payload["params"])

        response = self._post("https://board-wpa.chat.zalo.me/api/board/personal/todo/create", 
                            params=params, 
                            data=payload)
        
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            
            if results is None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return results

        error_code = data.get("error_code") 
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    def sendProduct(
        self,
        product_id,
        product_name,
        product_price,
        thumbnail_url,
        thread_id,
        thread_type,
        thumbnail_width=500,
        thumbnail_height=500,
        message=None,
        ttl=0
    ):
        """Send a product from a Zalo Catalog.

        This is a specialized version of sendLink for sending product cards.

        Args:
            product_id (str): The unique ID of the product from your Zalo Catalog.
                              (e.g., '514a456f512ab874e13b')
            product_name (str): The name of the product to display on the card.
            product_price (str or int): The price to display (e.g., "50,000 VND" or 50000).
            thumbnail_url (str): A direct URL to the product's image thumbnail.
            thread_id (int | str): User/Group ID to send the product to.
            thread_type (ThreadType): The type of thread (USER or GROUP).
            thumbnail_width (int): The width of the thumbnail. Defaults to 500.
            thumbnail_height (int): The height of the thumbnail. Defaults to 500.
            message (Message): An optional Message object to send along with the product card.
            ttl (int): Time-to-live for the message in seconds (0 for permanent).

        Returns:
            object: `User/Group` object with the message ID response.
            dict: A dictionary containing error responses.

        Raises:
            ZaloAPIException: If the request fails.
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }

        # The payload is similar to sendLink, but with specific types and a media object for products.
        payload = {
            "params": {
                "msg": message.text if message and message.text else "",
                "href": f"https://catalog.zalo.me/?pid={product_id}",
                "src": "catalog.zalo.me",
                "title": str(product_name),  # Product name is the main title
                "desc": str(product_price), # Product price is the description
                "thumb": thumbnail_url,
                "type": 7,  # Type 7 indicates a special link, likely for products/catalogs
                "media": json.dumps({
                    "type": 7,
                    "linkType": 7,
                    "mediaTitle": str(product_name),
                    "tWidth": thumbnail_width,
                    "tHeight": thumbnail_height,
                    # These fields are from the generic link structure and can be empty
                    "artist": "",
                    "streamUrl": "",
                    "stream_icon": ""
                }),
                "ttl": ttl,
                "clientId": _util.now()
            }
        }

        if message and message.mention:
            payload["params"]["mentionInfo"] = message.mention

        if thread_type == ThreadType.USER:
            url = "https://tt-chat4-wpa.chat.zalo.me/api/message/link"
            payload["params"]["toid"] = str(thread_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/sendlink"
            payload["params"]["imei"] = self._imei
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")

        payload["params"] = self._encode(payload["params"])

        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results is None:
                results = {"error_code": 1337, "error_message": "Data is None"}

            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}

            return (
                Group.fromDict(results, None)
                if thread_type == ThreadType.GROUP else
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def sendReport(self, user_id, reason=0, content=None):
        """Send report to Zalo.
        
        Args:
            reason (int): Reason for reporting
                1 = Nội dung nhạy cảm
                2 = Làm phiền
                3 = Lừa đảo
                0 = custom
            content (str): Report content (work if reason = custom)
            user_id (int | str): User ID to report
        
        Returns:
            object: `User` send report response
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "idTo": str(user_id),
                "objId": "person.profile"
            }
        }
        
        content = content if content and not reason else "" if not content and not reason else ""
        if content:
            payload["params"]["content"] = content
        
        payload["params"]["reason"] = str( random.randint(1, 3) if not content else reason )
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/report/abuse-v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def sendBusinessCard(self, userId, qrCodeUrl, thread_id, thread_type, phone=None, ttl=0):
        """Send business card by user ID.
            
        Args:
            userId (int | str): Business card user ID
            qrCodeUrl (str): QR Code link with business card profile information
            phone (int | str): Send business card with phone number
            thread_id (int | str): User/Group ID to change status in
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
        
        Returns:
            object: `User/Group` send business card response
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "ttl": ttl,
                "msgType": 6,
                "clientId": str(_util.now() *60),
                "msgInfo": {
                    "contactUid": str(userId),
                    "qrCodeUrl": str(qrCodeUrl)
                }
            }
        }
        
        if phone:
            payload["params"]["msgInfo"]["phone"] = str(phone)
        
        if thread_type == ThreadType.USER:
            url = "https://tt-files-wpa.chat.zalo.me/api/message/forward"
            payload["params"]["toId"] = str(thread_id)
            payload["params"]["imei"] = self._imei
        else:
            url = "https://tt-files-wpa.chat.zalo.me/api/group/forward"
            payload["params"]["visibility"] = 0
            payload["params"]["grid"] = str(thread_id)
        
        payload["params"]["msgInfo"] = json.dumps(payload["params"]["msgInfo"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return (
                Group.fromDict(results, None) 
                if thread_type == ThreadType.GROUP else 
                User.fromDict(results, None)
            )

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    """
    END SEND METHODS
    """
    
    def setTyping(self, thread_id, thread_type):
        """Set users typing status.
            
        Args:
            thread_id: User/Group ID to change status in.
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "imei": self._imei
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat1-wpa.chat.zalo.me/api/message/typing"
            payload["params"]["toid"] = str(thread_id)
            payload["params"]["destType"] = 3
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/typing"
            payload["params"]["grid"] = str(thread_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        try:
            data = response.json()
        except:
            # Nếu không phải JSON, thử decode và kiểm tra trạng thái
            if response.status_code == 200:
                return {"status": "success", "message": "Manual Success"}
            raise ZaloAPIException(f"Invalid response from server: {response.text[:100]}")

        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            return True

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def markAsDelivered(
        self,
        msgId,
        cliMsgId,
        senderId,
        thread_id,
        thread_type,
        seen=0,
        method="webchat"
    ):
        """Mark a message as delivered.
        
        Args:
            cliMsgId (int | str): Client message ID
            msgId (int | str): Message ID to set as delivered
            senderId (int | str): Message sender Id
            thread_id (int | str): User/Group ID to mark as delivered
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            bool: True
            
        Raises:
            ZaloAPIException: If request failed
        """
        destination_id = "0" if thread_type == ThreadType.USER else thread_id
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30
        }
        
        payload = {
            "params": {
                "msgInfos": {
                    "seen": 0,
                    "data": [{
                        "cmi": str(cliMsgId),
                        "gmi": str(msgId),
                        "si": str(senderId),
                        "di": str(destination_id),
                        "mt": method,
                        "st": 3,
                        "at": 0,
                        "ts": str(_util.now())
                    }]
                }
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat3-wpa.chat.zalo.me/api/message/deliveredv2"
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 501
        else:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/deliveredv2"
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 521
            payload["params"]["msgInfos"]["grid"] = str(destination_id)
            payload["params"]["imei"] = self._imei
        
        payload["params"]["msgInfos"] = json.dumps(payload["params"]["msgInfos"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            self.onMessageDelivered(msgId, thread_id, thread_type, _util.now())
            return True

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def markAsRead(
        self,
        msgId,
        cliMsgId,
        senderId,
        thread_id,
        thread_type,
        method="webchat"
    ):
        """Mark a message as read.
        
        Args:
            cliMsgId (int | str): Client message ID
            msgId (int | str): Message ID to set as delivered
            senderId (int | str): Message sender Id
            thread_id (int | str): User/Group ID to mark as read
            thread_type (ThreadType): ThreadType.USER, ThreadType.GROUP
            
        Returns:
            bool: True
            
        Raises:
            ZaloAPIException: If request failed
        """
        destination_id = "0" if thread_type == ThreadType.USER else thread_id
        
        params = {
            "zpw_ver": 645,
            "zpw_type": 30,
            "nretry": 0
        }
        
        payload = {
            "params": {
                "msgInfos": {
                    "data": [{
                        "cmi": str(cliMsgId),
                        "gmi": str(msgId),
                        "si": str(senderId),
                        "di": str(destination_id),
                        "mt": method,
                        "st": 3,
                        "ts": str(_util.now())
                    }]
                },
                "imei": self._imei
            }
        }
        
        if thread_type == ThreadType.USER:
            url = "https://tt-chat1-wpa.chat.zalo.me/api/message/seenv2"
            payload["params"]["msgInfos"]["data"][0]["at"] = 7
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 501
            payload["params"]["senderId"] = str(destination_id)
        elif thread_type == ThreadType.GROUP:
            url = "https://tt-group-wpa.chat.zalo.me/api/group/seenv2"
            payload["params"]["msgInfos"]["data"][0]["at"] = 0
            payload["params"]["msgInfos"]["data"][0]["cmd"] = 511
            payload["params"]["grid"] = str(destination_id)
        else:
            raise ZaloUserError("Thread type is invalid")
        
        payload["params"]["msgInfos"] = json.dumps(payload["params"]["msgInfos"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post(url, params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            self.onMarkedSeen(msgId, thread_id, thread_type, _util.now())
            return True

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupMediaList(self, groupId, mediaType=2, count=50, lastId=None, lastTime=None):
        """Lấy danh sách Media (Ảnh, Video, File, Link) của nhóm.

        Args:
            groupId (str): ID nhóm.
            mediaType (int): Loại media (1: Ảnh/Video, 2: File, 3: Link).
            count (int): Số lượng.
            lastId (str): ID cuối cùng để phân trang.
            lastTime (int): Thời gian cuối cùng để phân trang.
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "type": int(mediaType),
                "count": int(count),
                "lastId": str(lastId) if lastId else "0",
                "lastTime": int(lastTime) if lastTime else 0,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": 30
        }

        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/media/get-list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except: pass

            # Trả về danh sách media và thông tin phân trang
            return results.get("data") if isinstance(results, dict) else results

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    """
    LISTEN METHODS
    """
    
    def _listen_req(self, delay=1, thread=False, reconnect=5):
        self._condition.clear()
        HasRead = set()
        
        try:
            self.onListening()
            self._listening = True
            
            while not self._condition.is_set():
                ListenTime = int((time.time() - 10) * 1000)
                
                if len(HasRead) > 10000000:
                    HasRead.clear()
                
                messages = self.getLastMsgs()
                groupmsg = messages.groupMsgs
                messages = messages.msgs
                
                for message in messages + groupmsg:
                    if int(message["ts"]) >= ListenTime and message["msgId"] not in HasRead:
                        HasRead.add(message["msgId"])
                        msgObj = MessageObject.fromDict(message, None)
                        if message in messages:
                            
                            [
                                pool.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                                if thread else
                                self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                            ]
                        
                        else:
                            
                            [
                                pool.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                                if thread else
                                self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                            ]
                
                time.sleep(delay)
        
        except KeyboardInterrupt:
            self._condition.set()
            print("\x1b[1K")
            logger.warning("Stop Listen Because KeyboardInterrupt Exception!")
            pid = os.getpid()
            os.kill(pid, signal.SIGTERM)
        
        except Exception as e:
            self._condition.set()
            self._listening = False
            self.onErrorCallBack(e)
            if self.run_forever:
                while not self._listening:
                    try:
                        logger.debug("Run forever mode is enabled, trying to reconnect...")
                        self._listen_req(delay, thread, reconnect)
                    except:
                        pass
                    
                    time.sleep(reconnect)
        
        finally:
            self._listening = False
    
    def _fix_recv(self):
        old_timestamp = int(time.time())
        time.sleep(50 * 60)
        self._start_fix = True
        self._condition.set()
    
    def _listen_ws(self, thread=False, reconnect=5):
        self._condition.clear()
        params = {"zpw_ver": 645, "zpw_type": 30, "t": _util.now()}
        url = self._state._config["zpw_ws"][0] + "?" + urllib.parse.urlencode(params)
        
        user_agent = self._state._headers.get("User-Agent") or _util.HEADERS["User-Agent"]
        raw_cookies = _util.dict_to_raw_cookies(self._state.get_cookies())
        
        if not raw_cookies:
            raise ZaloUserError("Unable to load cookies! Probably due to incorrect cookie format (cookies must be dict)")
        
        headers = {
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Connection": "Upgrade",
            "Host": urllib.parse.urlparse(url).netloc,
            "Origin": "https://chat.zalo.me",
            "Pargma": "no-cache",
            "Sec-Websocket-Extensions": "permessage-deflate; client_max_window_bits",
            "Sec-Websocket-Version": "13",
            "Upgrade": "websocket",
            "User-Agent": user_agent,
            "Cookie": raw_cookies
        }
        
        with connect(url, additional_headers=headers) as ws:
            pool.submit(self._fix_recv)
            self.onListening()
            self._listening = True
            while not self._condition.is_set():
                try:
                    data = ws.recv()
                    if not isinstance(data, bytes):
                        continue
                    
                    encodedHeader = data[:4]
                    n, cmd, s = _util.getHeader(encodedHeader)
                    
                    dataToDecode = data[4:]
                    decodedData = dataToDecode.decode("utf-8")
                    if not decodedData:
                        continue
                    
                    parsed = json.loads(decodedData)
                    if n == 1 and cmd == 1 and s == 1 and "key" in parsed:
                        self.ws_key = parsed["key"]
                        continue
                    
                    if not hasattr(self, "ws_key"):
                        logger.error("Unable to decrypt data because key not found")
                        continue
                    
                    parsedData = _util.zws_decode(parsed, self.ws_key)
                    if n == 1 and cmd == 3000 and s == 0:
                        logger.warning("Another connection is opened, closing this one")
                        ws.close()
                    
                    elif n == 1 and cmd == 501 and s == 0:
                        parsedData = _util.zws_decode(parsed, self.ws_key)
                        userMsgs = parsedData["data"]["msgs"]
                        
                        for message in userMsgs:
                            msgObj = MessageObject.fromDict(message, None)
                            [
                                pool.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                                if thread else
                                self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                            ]
                    
                    elif n == 1 and cmd == 521 and s == 0:
                        groupMsgs = parsedData["data"]["groupMsgs"]
                        
                        try:
                            for message in groupMsgs:
                                messages = self.getRecentGroup(message["idTo"])["groupMsgs"]
                                message = next((msg for msg in messages if msg["msgId"] == message["msgId"]), message)
                        except:
                            pass
                            
                        msgObj = MessageObject.fromDict(message, None)
                        [
                            pool.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                            if thread else
                            self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                        ]
                    
                    elif n == 1 and cmd in [502, 522, 504, 524] and s == 0:
                        # Delivereds, Seen, Clear Unread, ...
                        continue
                    
                    elif n == 1 and cmd == 602 and s == 0:
                        # Typing Event
                        continue
                    
                    elif n == 1 and cmd == 601 and s == 0:
                        controls = parsedData["data"].get("controls", [])
                        for control in controls:
                            if control["content"]["act_type"] == "group":
                                
                                if control["content"]["act"] == "join_reject":
                                    continue
                                
                                groupEventData = json.loads(control["content"]["data"]) if isinstance(control["content"]["data"], str) else control["content"]["data"]
                                groupEventType = _util.getGroupEventType(control["content"]["act"])
                                event_data = EventObject.fromDict(groupEventData)
                                event_type = groupEventType
                                [
                                    pool.submit(self.onEvent, event_data, event_type)
                                    if thread else
                                    self.onEvent(event_data, event_type)
                                ]
                        
                        continue
                    
                    elif cmd == 612:
                        reacts = parsedData["data"].get("reacts", [])
                        reactGroups = parsedData["data"].get("reactGroups", [])
                        
                        for react in reacts:
                            react["content"] = json.loads(react["content"])
                            msgObj = MessageObject.fromDict(react, None)
                            [
                                pool.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                                if thread else
                                self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.uidFrom) or msgObj.idTo), ThreadType.USER)
                            ]
                        
                        for reactGroup in reactGroups:
                            reactGroup["content"] = json.loads(reactGroup["content"])
                            msgObj = MessageObject.fromDict(reactGroup, None)
                            [
                                pool.submit(self.onMessage, msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                                if thread else
                                self.onMessage(msgObj.msgId, str(int(msgObj.uidFrom) or self.uid), msgObj.content, msgObj, str(int(msgObj.idTo) or self.uid), ThreadType.GROUP)
                            ]
                    
                    else:
                        continue
                
                except KeyboardInterrupt:
                    self._condition.set()
                    ws.close()
                    print("\x1b[1K")
                    logger.warning("Stop Listen Because KeyboardInterrupt Exception!")
                    pid = os.getpid()
                    os.kill(pid, signal.SIGTERM)
                
                except (websockets.ConnectionClosedOK, websockets.exceptions.ConnectionClosedOK):
                    self._condition.set()
                    ws.close()
                    break
                
                except (websockets.ConnectionClosedError, websockets.exceptions.ConnectionClosedError):
                    self._start_fix = True
                    self._condition.set()
                    ws.close()
                
                except Exception as e:
                    if str(e) == "sent 1000 (OK); then received 1000 (OK) NORMAL_CLOSURE":
                        pass
                    
                    else:
                        self._listening = False
                        self._start_fix = False
                        self._condition.set()
                        ws.close()
                        self.onErrorCallBack(e)
                        if self.run_forever:
                            while not self._listening:
                                try:
                                    logger.debug("Run forever mode is enabled, trying to reconnect...")
                                    self._listen_ws(thread, reconnect)
                                except:
                                    pass
                                
                                time.sleep(reconnect)
                
                finally:
                    self._listening = False
        
        if self._start_fix:
            logger.debug("Reconnecting websocket because of interruption...")
            self._start_fix = False
            self._listen_ws(thread, reconnect)
    
    def startListening(self, delay=1, thread=False, type="websocket", reconnect=5):
        """Start listening from an external event loop.
        
        Args:
            delay (int): Delay time each time fetching a message
            thread (bool): Handle messages within the thread (Default: False)
            type (str): Type of listening (Default: websocket)
            reconnect (int): Delay interval when reconnecting
        
        Raises:
            ZaloAPIException: If request failed
        """
        if str(type).lower() == "websocket":
            
            if self._state._config.get("zpw_ws"):
                self._listen_ws(thread, reconnect)
                
            else:
                logger.debug("WebSocket url not found. Listen will switch to `requests` mode")
                self._listen_req(delay, thread)
        
        elif str(type).lower() == "requests":
            self._listen_req(delay, thread)
        
        else:
            raise ZaloUserError("Invalid listen type, only `websocket` or `requests`")
    
    def stopListening(self):
        """Stop the listening loop in a thread-safe manner."""
        if not self.listening:
            logger.warning("Listener is not running.")
            return

        self.listening = False
        self._condition.set()

        if hasattr(self, "_ws") and self._ws:
            try:
                self._ws.close()
                logger.debug("WebSocket connection closed.")
            except Exception as e:
                logger.error(f"Error while closing WebSocket: {e}")

        if self._listen_thread and self._listen_thread.is_alive():
            self._listen_thread.join()
            self._listen_thread = None

        if hasattr(self, "_threads") and self._threads:
            for thread_name, thread in list(self._threads.items()):
                if thread.is_alive():
                    self._thread_events[thread_name].set()
                    thread.join()
                    logger.debug(f"Thread '{thread_name}' stopped.")
            self._threads.clear()
            self._thread_events.clear()

        logger.debug("Listening loop stopped.")
    
    def listen(self, delay=1, thread=False, type="websocket", run_forever=False, reconnect=5):
        """Initialize and runs the listening loop continually.
        
        Args:
            delay (int): Delay time for each message fetch (Default: 1)
            thread (bool): Handle messages within the thread (Default: False)
            type (str): Type of listening (Default: websocket)
            reconnect (int): Delay interval when reconnecting
        """
        self.run_forever = run_forever
        self.startListening(delay, thread, type, reconnect)
        
    """
    END LISTEN METHODS
    """
    
    """
    EVENTS
    """
    
    def onLoggingIn(self, phone=None):
        """Called when the client is logging in.
            
        Args:
            phone: The phone number of the client
        """
        logger.debug("Logging in {}...".format(phone))
        
    def onLoggedIn(self, phone=None):
        """Called when the client is successfully logged in.
            
        Args:
            phone: The phone number of the client
        """
        logger.login("Login of {} successful.".format(phone))
    
    def onListening(self):
        """Called when the client is listening."""
        logger.debug("Listening...")
    
    def onMessage(
        self,
        mid=None,
        author_id=None,
        message=None,
        message_object=None,
        thread_id=None,
        thread_type=ThreadType.USER
    ):
        """Called when the client is listening, and somebody sends a message.

        Args:
            mid: The message ID
            author_id: The ID of the author
            message: The message content of the author
            message_object: The message (As a `Message` object)
            thread_id: Thread ID that the message was sent to.
            thread_type (ThreadType): Type of thread that the message was sent to.
        """
        logger.info("{} from {} in {}".format(message, thread_id, thread_type.name))
    
    def onEvent(self, event_data, event_type):
        """Called when the client listening, and some events occurred.

        Args:
            event_data (EventObject): Event data (As a `EventObject` object)
            event_type (EventType/GroupEventType): Event Type
        """
    
    def onMessageDelivered(
        self,
        msg_ids=None,
        thread_id=None,
        thread_type=ThreadType.USER,
        ts=None
    ):
        """Called when the client is listening, and the client has successfully marked messages as delivered.
        
        Args:
            msg_ids: The messages that are marked as delivered
            thread_id: Thread ID that the action was sent to
            thread_type (ThreadType): Type of thread that the action was sent to
            ts: A timestamp of the action
        """
        logger.info(
            "Marked messages {} as delivered in [({}, {})] at {}.".format(
                msg_ids, thread_id, thread_type.name, int(ts / 1000)
            )
        )

    def onMarkedSeen(
        self,
        msg_ids=None,
        thread_id=None,
        thread_type=ThreadType.USER,
        ts=None
    ):
        """Called when the client is listening, and the client has successfully marked messages as read/seen.
        
        Args:
            msg_ids: The messages that are marked as read/seen
            thread_id: Thread ID that the action was sent to
            thread_type (ThreadType): Type of thread that the action was sent to
            ts: A timestamp of the action
        """
        logger.info(
            "Marked messages {} as seen in [({}, {})] at {}.".format(
                msg_ids, thread_id, thread_type.name, int(ts / 1000)
            )
        )
    
    def onErrorCallBack(self, error, ts=int(time.time())):
        """Called when the module has some error.
        
        Args:
            error: Description of the error
            ts: A timestamp of the error (Default: auto)
        """
        logger.error(f"An error occurred at {ts}: {error}")
        print(traceback.format_exc())
    
    """
    END EVENTS
    """